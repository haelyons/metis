// Accurate Timer

#pragma once

#ifdef _WIN32
// Windows version of timer
#include <windows.h>
#else
// Linux version of timer
#include <time.h>
#endif

class ATimer{
private:
	double total;
	#ifdef _WIN32
	LARGE_INTEGER start;
    LARGE_INTEGER stop;
	LARGE_INTEGER frequency;
	#else
	struct timespec start;
	struct timespec stop;
	#endif
public:
	ATimer();
	void startTimer();
	void stopTimer();
	double getElapsedTime(); // Elapsed time in seconds between last start/stop
	void addElapsedTime(); // Adds elapsed time in seconds between last start/stop to total time counter
	double getTotalTime(); // Total time in seconds
	void resetTotalTime(); // Reset total time counter
};