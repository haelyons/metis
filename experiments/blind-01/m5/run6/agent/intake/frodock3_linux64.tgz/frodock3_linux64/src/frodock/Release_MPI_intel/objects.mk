################################################################################
# Automatically-generated file. Do not edit!
################################################################################

USER_OBJS :=

LIBS := -lfrodockcluster -lfrodock_mpi -lprotprot_mpi -lfrm -lbessel -lpdb -lvolume -ltools

