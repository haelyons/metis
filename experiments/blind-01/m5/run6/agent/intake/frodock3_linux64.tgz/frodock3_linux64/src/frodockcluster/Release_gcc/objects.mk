################################################################################
# Automatically-generated file. Do not edit!
################################################################################

USER_OBJS :=

LIBS := -lfrodockcluster_gcc -lpdb2_gcc -ltools_gcc

