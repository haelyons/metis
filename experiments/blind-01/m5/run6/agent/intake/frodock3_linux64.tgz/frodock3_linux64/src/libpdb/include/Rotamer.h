// get rotamer frm chis
void rotamer_from_chi( float *chis, int aan , int **rot);

