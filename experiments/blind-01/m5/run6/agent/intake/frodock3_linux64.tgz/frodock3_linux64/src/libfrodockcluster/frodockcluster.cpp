#ifdef HAVE_CONFIG_H
  #include <config.h>
#endif

#include "frodockcluster.h"

/***********CLUSTERING********************/
typedef float Triple[3];

typedef struct tcluster {
  int num;
  Triple pos;
  Triple rot;
  float dist_avg;
  float dist_dev;
  float corr;
  float corr_avg;
  float deviation;
  float rmsd;
  float irmsd;
  float fnat;
  float fnnat;
  Macromolecule *pdb;
  int *elements; //NEW
} cluster;

void swap( float *buffer, int pos1, int pos2, int num_elem )
{
  int k;
  float temp;
  for(k=0;k<num_elem;k++)
	     {
	      temp = buffer[(pos1*num_elem)+k];

        buffer[(pos1*num_elem)+k] = buffer[(pos2*num_elem)+k];

        buffer[(pos2*num_elem)+k] = temp;

	     }
}

int particion( float *buffer, int pos,int izquierda, int derecha, int num_elem )
{
  int posicion = izquierda;
  while ( true )
  {
    while ( buffer[ (posicion*num_elem)+pos ] <= buffer[ (derecha*num_elem)+pos ] && posicion != derecha )
      --derecha;
    if ( posicion == derecha )
      return posicion;

    if ( buffer[ (posicion*num_elem)+pos ] > buffer[ (derecha*num_elem)+pos ])
    {
     swap( buffer, posicion , derecha, num_elem);
      posicion = derecha;
    }

    while ( buffer[ (izquierda*num_elem)+pos ] <= buffer[ (posicion*num_elem)+pos ] && izquierda != posicion )
      ++izquierda;

    if ( posicion == izquierda )
      return posicion;

    if ( buffer[ (izquierda*num_elem)+pos ] > buffer[ (posicion*num_elem)+pos ] )
    {
        swap( buffer, posicion ,  izquierda, num_elem );
      posicion = izquierda;
    }
  }
}

int particion2( float *buffer, int pos,int izquierda, int derecha,int num_elem )
{
  int posicion = izquierda;
  while ( true )
  {
    while ( buffer[ (posicion*num_elem)+pos ] >= buffer[ (derecha*num_elem)+pos ] && posicion != derecha )
      --derecha;
    if ( posicion == derecha )
      return posicion;

    if ( buffer[ (posicion*num_elem)+pos ] < buffer[ (derecha*num_elem)+pos ])
    {
 	     swap( buffer, posicion , derecha, num_elem );
      posicion = derecha;
    }

    while ( buffer[ (izquierda*num_elem)+pos ] >= buffer[ (posicion*num_elem)+pos ] && izquierda != posicion )
      ++izquierda;

    if ( posicion == izquierda )
      return posicion;

    if ( buffer[ (izquierda*num_elem)+pos ] < buffer[ (posicion*num_elem)+pos ] )
    {
       swap( buffer, posicion ,  izquierda, num_elem );
      posicion = izquierda;
    }
  }
}


void quicksort( float * buffer, int pos,int first, int last ,bool dec, int num_elem)
{
  int posicionActual;
  if ( first >= last )
    return;

  if(!dec)
  {
  		posicionActual = particion( buffer,pos, first, last, num_elem );
  }
  else
  {
  	posicionActual = particion2( buffer,pos, first, last, num_elem );
  }

  quicksort( buffer, pos,first, posicionActual - 1 ,dec,  num_elem);
  quicksort( buffer, pos,posicionActual + 1, last,dec, num_elem );
}

int calcule_cluster(float *buffer, int npeaksTotal,  char *in_pdb,
		  	  	float **output_buffer, float **output_buffer2, int rampi, float rampd,
		  	  	int in_num, int in_numc, float in_limit, float in_limit2,bool output2,
		  	  	int num_elem,bool is_sort,bool in_eval )
{
	int i,j,k;
	  cluster *clusters;


	  bool *ind_buffer;
	  int *in_cluster;
	  float *distance_cluster;
	  int num_clusters=0,sizecluster=100;
	  float distance,lastdistance;
	  Triple s_rot1,s_trans1, euler;
	  Tcoor original_center, invert_original_center;
	  float max_corr, limit, *ramp_limit, corr_i;



		clusters=(cluster*)malloc(sizecluster*sizeof(cluster));


		ind_buffer=(bool*)malloc(sizeof(bool)*npeaksTotal);
		memset(ind_buffer,0,npeaksTotal*sizeof(bool));

		in_cluster=(int*)malloc(sizeof(int)*npeaksTotal);
		distance_cluster=(float*)malloc(sizeof(float)*npeaksTotal);
		for(i=0;i<npeaksTotal;i++)
		{
				in_cluster[i]=-1;
				distance_cluster[i]=-1.0;
		}

		Macromolecule *pdb=new Macromolecule();
		pdb->readPDB(in_pdb);
		pdb->deleteHYDS();
		pdb->geoCenter( original_center );
		invert_original_center[0] = original_center[0] * ( -1.0 );
		invert_original_center[1] = original_center[1] * ( -1.0 );
		invert_original_center[2] = original_center[2] * ( -1.0 );
		pdb->moveAll( invert_original_center );

		Conditions *conds= new Conditions();
		Condition *cond= new Condition(-1,-1,-1,-1,-1,-1,-1,-1,-1,-1);
		cond->add(" CA ");
		conds->add(cond);


		Macromolecule *pdb_ca=pdb->select_cpy(conds);


		Macromolecule *pdb_ca_ref=new Macromolecule(pdb_ca);
		Macromolecule *pdb_ca2=new Macromolecule(pdb_ca);


	//SORT
		if(!is_sort)
		{
			printf("Sort process...\n");

			is_sort=true;
			for(i=1;i<npeaksTotal;i++)
	  	{
	  		if(buffer[6+(num_elem*i)]<buffer[6+(num_elem*(i-1))])
	  		{
	  			is_sort=false;
	  			i=npeaksTotal;
	  		}
	  	}

	  	if(!is_sort)
	  	{
	  		quicksort(buffer,6,0,npeaksTotal-1,true, num_elem);
	  	}
		}
		//END SORT

		//Claculo de limite
		max_corr=0;
		for ( i = 0; (i < npeaksTotal) && ((in_num==-1) || (i<in_num)) ; i++)
	  {
	  	if(max_corr<buffer[i*num_elem+6])
	  	{
	  		max_corr=buffer[i*num_elem+6];
	  	}
	  }

	  limit=max_corr*in_limit2;

	  // ramp new idea....
		ramp_limit=(float*)malloc(sizeof(float)*in_numc);


		for ( i = 0; i < in_numc; i++) {
			ramp_limit[i]=in_limit*in_limit;
			if (i>rampi) {
				ramp_limit[i]= (in_limit+(rampd-in_limit)/(in_numc-rampi)*((i+1)-rampi))*
						       (in_limit+(rampd-in_limit)/(in_numc-rampi)*((i+1)-rampi));
			}
			// printf("%d %f\n",i,ramp_limit[i]);

		}

	 	// printf("Maxima correlacion=%f\nLimite= %f\n",max_corr,limit);
		printf("Maximum correlation: %f \nClustering process...\n",max_corr);

		//PRIMERA PASADA
	  //in_limit_2=in_limit*in_limit;

	  for ( i = 0; (i < npeaksTotal) && ((in_num==-1) || (i<in_num)) ; i++)
	  {
			for(j=0;j<3;j++)
			{
				s_rot1[j]=buffer[i*num_elem+j];
				s_trans1[j]=buffer[i*num_elem+j+3];
			}
			corr_i=buffer[i*num_elem+6];

	  	euler[0]=s_rot1[0]*(3.1415297/180.0);
			euler[1]=s_rot1[1]*(3.1415297/180.0);
	 		euler[2]=s_rot1[2]*(3.1415297/180.0);
	  	M4Rot *m4rot =new M4Rot(euler, 0,s_trans1);
			pdb_ca->applyAtoms(m4rot,pdb_ca_ref);
			delete m4rot;

	  	lastdistance=100000000000.0;
	  	for(j=0;j<num_clusters;j++)
	  	{

	  		distance=(s_trans1[0]-clusters[j].pos[0])*(s_trans1[0]-clusters[j].pos[0])+(s_trans1[1]-clusters[j].pos[1])*(s_trans1[1]-clusters[j].pos[1])+(s_trans1[2]-clusters[j].pos[2])*(s_trans1[2]-clusters[j].pos[2]);
	  		if(distance < ramp_limit[j] && corr_i>(clusters[j].corr-limit))
	  		{
	  			    euler[0]=clusters[j].rot[0]*(3.1415297/180.0);
					euler[1]=clusters[j].rot[1]*(3.1415297/180.0);
	 				euler[2]=clusters[j].rot[2]*(3.1415297/180.0);
	  			    M4Rot *m4rot =new M4Rot(euler, 0, clusters[j].pos);
					pdb_ca2->applyAtoms(m4rot,pdb_ca_ref);
					delete m4rot;

	  			distance=pdb_ca->rmsd(pdb_ca2);

	  			if(distance<sqrt(ramp_limit[j]))
	  			{
	  				if(lastdistance>distance)
	  				{
	  						if(in_cluster[i]!=-1)
	  							clusters[in_cluster[i]].num--;
	  						lastdistance=distance;
	  						clusters[j].num++;
	  						in_cluster[i]=j;
								distance_cluster[i]=distance;
	  				}
	  			}
	  		}
	  	}


	  	if(in_cluster[i]==-1 && (num_clusters<in_numc || in_numc==-1) )
	  	{
	  		if((num_clusters+1)%100==0)
	  		{
	  			sizecluster+=100;
	  			clusters=(cluster*)realloc(clusters,sizecluster*sizeof(cluster));
	  		}

	  		in_cluster[i]=num_clusters;
	  		distance_cluster[i]=0;
	  		clusters[num_clusters].num=1;

	  		//clusters[num_clusters].pdb= new Macromolecule(pdb_ca);

	  		for(j=0;j<3;j++)
	  		{
	  			clusters[num_clusters].rot[j]=s_rot1[j];
	  			clusters[num_clusters].pos[j]=s_trans1[j];
	  		}

				clusters[num_clusters].corr=buffer[i*num_elem+6];

				if(in_eval)
				{
	  			clusters[num_clusters].rmsd=buffer[i*11+7];
	  			clusters[num_clusters].irmsd=buffer[i*11+8];
	  			clusters[num_clusters].fnat=buffer[i*11+9];
	  			clusters[num_clusters].fnnat=buffer[i*11+10];
				}

	  		ind_buffer[i]=true;
	  		num_clusters++;
	  	}
		fprintf(stderr,"Processing %d %d\r",i,num_clusters);
		if ((!output2)&& (num_clusters==in_numc) ) break;
	  }

	  *output_buffer=(float*)malloc(sizeof(float)*num_elem*num_clusters);
	  k=0;
	  for (i=0; i<npeaksTotal; i++)
	  {
		  if(ind_buffer[i] )
		  {
			for(j=0;j<num_elem;j++)
			{
				(*output_buffer)[k*num_elem+j]=buffer[i*num_elem+j];
			}
			k++;
		  }
	  }

	  if(output2)
	  {
		  *output_buffer2=(float*)malloc(sizeof(float)*num_elem*num_clusters);
		  k=0;
		  for (i=0; i<npeaksTotal; i++)
		  {
			  if(ind_buffer[i] )
			  {
				 buffer[i*num_elem+6]=clusters[in_cluster[i]].num;
				 for(j=0;j<num_elem;j++)
				 {
					(*output_buffer2)[k*num_elem+j]=buffer[i*num_elem+j];
				 }
				 k++;

			  }
		  }
	  }

	  free(clusters);
	  free(ind_buffer);
	  free(in_cluster);
	  free(distance_cluster);
	  delete pdb;
	  delete conds;
	  delete pdb_ca;
	  delete pdb_ca_ref;
	  delete pdb_ca2;
	  return num_clusters;
}

/***********END CLUSTERING***************/

