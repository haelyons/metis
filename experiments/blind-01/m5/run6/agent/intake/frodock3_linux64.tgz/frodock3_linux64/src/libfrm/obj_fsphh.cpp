/***************************************************************************
                          ftransform.cpp  -  description
                             -------------------
    begin                : Wed Dec 1 2004
    copyright            : (C) 2004 by Jose Ignacio Garzon
    email                :
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include "obj_aux.h"
#include "obj_fsphh.h"

#ifdef VOLUME_INCLUDED
namespace FOPS
{

//****************TRANSFORMACIONES***************************************************

  vlSpherical *volumetric_sampling_fast(vlVolume *vol, int *rmax, int bw, int maxext,float cx,
                                    float cy,float cz,float* buf_lambda,float* buf_theta ,vlSpherical *sph2)
  {
    /* performs the sampling in spherical coordinates */

    int i, j, r, size;
    float stsl, stcl, ct;
    float x, y, z;
    float aux=0.0;

    int bw_1,bw_12,index_stsl,index_stcl;
    vlPoint3ui pos;
    int g_extx, g_exty, g_extz;
    int g_extx1, g_exty1, g_extz1;
    vlSpherical *sph;


    //Valores predeterminados
    size=(bw<<1);
    bw_1=bw-1;
    bw_12=bw_1*bw_1;
    index_stsl=((bw_1)*(4*bw_12-1)/3);
    index_stcl=((bw_1)*(4*bw_12-1)/3);



    /* creacion del objeto que representa al volumen en coordenadas esfericas */

    if(sph2==NULL)
      sph= new vlSpherical(bw,maxext);
    else
      sph=sph2;

    g_extx=vol->dim().x(); g_extx1= g_extx -1;
    g_exty=vol->dim().y(); g_exty1= g_exty -1;
    g_extz=vol->dim().z(); g_extz1= g_extz -1;



    *rmax=0;
    for(i=0;i<size;i++) /* i represents latitude values */
    {

        ct=buf_theta[bw_12+i];

      for(j=0; j<size;j++)         /* j represents longitude values */
      {

          stsl=buf_lambda[(index_stsl + size*i +j)*2];
          stcl=buf_lambda[(index_stcl+ size*i +j)*2+1];

        for(r=0, x = cx, y=cy, z=cz;r<maxext;r++, x+=stcl, y+=stsl, z+=ct)
        {
         if(x<0.0 || x>=g_extx1 || y<0.0 || y>=g_exty1 || z<0.0 || z>=g_extz1) {
            for(;r<maxext;r++)
              sph->setP(r,i,j,0.0);
            break;
          }

          /* interpolation */
          vol->getVoxel(vlPoint3f(x,y,z),aux);
          sph->setP(r,i,j,aux);


          /* rmax: maximum distance from COM to starred hull of map */
          if(aux>0.0 && r> *rmax) *rmax=r;

        }
      }
    }

    return sph;
  }


vlSpherical *volumetric_sampling_slow(vlVolume *vol, int in[],int out[], int zero[], int bw, int maxext,float cx,
                                    float cy,float cz,float* buf_lambda,float *buf_theta,vlSpherical *sph2)
  {
    /* performs the sampling in spherical coordinates */

    int i, j, r, size;
    float stsl, stcl, ct;
    float x, y, z;
    float a, b, c;
    int x1, y1, z1;
    float f111, f112, f121, f122, f211, f212, f221, f222;
    float aux=0.0;
    int g_extx, g_exty, g_extz;
     int g_extx1, g_exty1, g_extz1;
    vlSpherical *sph;


    int bw_1,bw_12,index_stsl,index_stcl;

    //Valores predeterminados
    size=(bw<<1);
    bw_1=bw-1;
    bw_12=bw_1*bw_1;
    index_stsl=((bw_1)*(4*bw_12-1)/3);
    index_stcl=((bw_1)*(4*bw_12-1)/3);



    /* creacion del objeto que representa al volumen en coordenadas esfericas */
    if(sph2==NULL)
      sph= new vlSpherical(bw,maxext);
    else
      sph=sph2;

    g_extx=vol->dim().x(); g_extx1= g_extx -1;
    g_exty=vol->dim().y(); g_exty1= g_exty -1;
    g_extz=vol->dim().z(); g_extz1= g_extz -1;


    in[0]=maxext;
    in[1]=0;
    out[0]=maxext;
    out[1]=0;
    zero[0]=maxext;
    zero[1]=0;


    for(i=0;i<size;i++) /* i represents latitude values */
    {
      //theta= 0.5*M_PI*(i+0.5)/bw;
      //st=sin(theta); ct=cos(theta);
      ct=buf_theta[bw_12+i];
      for(j=0; j<size;j++)         /* j represents longitude values */
      {
        //stsl=st*sin(lambda);
        stsl=buf_lambda[(index_stsl + size*i +j)*2];

        //stcl=st*cos(lambda);
        stcl=buf_lambda[(index_stcl+ size*i +j)*2+1];
        for(r=0, x = cx, y=cy, z=cz;r<maxext;r++, x+=stcl, y+=stsl, z+=ct)
        {
         if(x<0.0 || x>=g_extx1 || y<0.0 || y>=g_exty1 || z<0.0 || z>=g_extz1) {
            for(;r<maxext;r++)
              sph->setP(r,i,j,0.0);
            break;
          }

          /* interpolation */
          x1=floor(x); y1=floor(y); z1=floor(z);
          a=x-x1; b=y-y1; c=z-z1;
          f111=vol->getVoxelSpecial(gidz_general(z1, y1, x1, g_exty, g_extx));
          f112=vol->getVoxelSpecial(gidz_general(z1+1, y1, x1,g_exty,g_extx));
          f121=vol->getVoxelSpecial(gidz_general(z1, y1+1, x1,g_exty,g_extx));
          f122=vol->getVoxelSpecial(gidz_general(z1+1, y1+1, x1,g_exty,g_extx));
          f211=vol->getVoxelSpecial(gidz_general(z1, y1, x1+1,g_exty,g_extx));
          f212=vol->getVoxelSpecial(gidz_general(z1+1, y1, x1+1,g_exty,g_extx));
          f221=vol->getVoxelSpecial(gidz_general(z1, y1+1, x1+1,g_exty,g_extx));
          f222=vol->getVoxelSpecial(gidz_general(z1+1, y1+1, x1+1,g_exty,g_extx));


          aux=((1-a)*((1-b)*((1-c)*f111+c*f112)+b*((1-c)*f121+c*f122))+
            a *((1-b)*((1-c)*f211+c*f212)+b*((1-c)*f221+c*f222)) );
          sph->setP(r,i,j,aux);


            if(aux==0.0)
            {
              if(r< zero[0]) zero[0]=r;
              if(r> zero[1]) zero[1]=r;
            }


        }
      }
    }



    for(i=0;i<size;i++){
      for(j=0;j<size;j++)
      {
        for(r=maxext-1;r>=0;r--)
          if(sph->getP(r,i,j)>0.0){
            if(r< out[0]) out[0]=r;
              if(r> out[1]) out[1]=r;
                break;
          }

        for(r=0;r<maxext;r++)
          if(sph->getP(r,i,j)>0.0){
            if(r< in[0]) in[0]=r;
              if(r> in[1]) in[1]=r;
                break;
            }

        for(r=0;r<maxext;r++)
          if(sph->getP(r,i,j)==0.0){
            if(r< zero[0]) zero[0]=r;
            if(r> zero[1]) zero[1]=r;
            break;
          }

      }
    }

    return sph;
  }


vlSpherical *volumetric_sampling_fast(vlVolume *vol, int *rmax, int bw, int maxext,float cx,
                                  float cy,float cz,float rho,vlSpherical *sph2)
{
  /* performs the sampling in spherical coordinates */

  int i, j, r, size;
  float lambda, theta, initlambda;          /* longitude and latitude */
  float stsl, stcl, st, ct;
  float x, y, z;

  float aux=0.0;
  int g_extx, g_exty, g_extz;
  int g_extx1, g_exty1, g_extz1;
  vlSpherical *sph;


  /* creacion del objeto que representa al volumen en coordenadas esfericas */
  if(sph2==NULL)
    sph= new vlSpherical(bw,maxext);
  else
    sph=sph2;

   g_extx=vol->dim().x(); g_extx1= g_extx -1;
   g_exty=vol->dim().y(); g_exty1= g_exty -1;
   g_extz=vol->dim().z(); g_extz1= g_extz -1;

  size=(bw<<1);
  initlambda=M_PI/bw;


  *rmax=0;
  for(i=0;i<size;i++) /* i represents latitude values */
  {
    theta= 0.5*M_PI*(i+0.5)/bw;
    st=sin(theta)*rho; ct=cos(theta)*rho;
    for(j=0,lambda=0; j<size;j++, lambda+=initlambda)         /* j represents longitude values */
    {
      stsl=st*sin(lambda); stcl=st*cos(lambda);
      for(r=0, x = cx, y=cy, z=cz;r<maxext;r++, x+=stcl, y+=stsl, z+=ct)
      {
        if(x<1.0 || x>g_extx1 || y<1.0 || y>g_exty1 || z<1.0 || z>g_extz1)
        {
          for(;r<maxext;r++)
            sph->setP(r,i,j,0.0);
          break;
        }

        /* interpolation */
        vol->getVoxel(vlPoint3f(x,y,z),aux);

        sph->setP(r,i,j,aux);

        /* rmax: maximum distance from COM to starred hull of map */
        if(aux>0.0 && r> *rmax) *rmax=r;

      }
    }
  }
  /* rmax: maximum distance from COM to starred hull of map */


  return sph;
}

vlSpherical *volumetric_sampling_fastL(vlVolume *vol, int *rmax, int bw, int maxext,float cx,
                                  float cy,float cz,float rho,vlSpherical *sph2)
{
  /* performs the sampling in spherical coordinates */

  int i, j, r, size;
  float lambda, theta, initlambda;          /* longitude and latitude */
  float stsl, stcl, st, ct;
  float x, y, z;
  float aux=0.0;
  int g_extx, g_exty, g_extz;
  int g_extx1, g_exty1, g_extz1;
  vlSpherical *sph;

  /* creacion del objeto que representa al volumen en coordenadas esfericas */
  if(sph2==NULL)
    sph= new vlSpherical(bw,maxext);
  else
    sph=sph2;

  g_extx=vol->dim().x(); g_extx1= g_extx -1;
  g_exty=vol->dim().y(); g_exty1= g_exty -1;
  g_extz=vol->dim().z(); g_extz1= g_extz -1;

  size=(bw<<1);
  initlambda=M_PI/bw;



  *rmax=0;
  for(i=0;i<size;i++) /* i represents latitude values */
  {
    theta= 0.5*M_PI*(i+0.5)/bw;
    st=sin(theta)*rho; ct=cos(theta)*rho;
    for(j=0,lambda=0; j<size;j++, lambda+=initlambda)         /* j represents longitude values */
    {
      stsl=st*sin(lambda); stcl=st*cos(lambda);
      for(r=0, x = cx, y=cy, z=cz;r<maxext;r++, x+=stcl, y+=stsl, z+=ct)
      {
         if(x<0.0 || x>=g_extx1 || y<0.0 || y>=g_exty1 || z<0.0 || z>=g_extz1) {
          for(;r<maxext;r++)
            sph->setP(r,i,j,0.0);
          break;
        }

        /* interpolation */
        vol->getVoxel(vlPoint3f(x,y,z),aux);
        sph->setP(r,i,j,aux);

        /* rmax: maximum distance from COM to starred hull of map */
        if(aux!=0.0 && r> *rmax) *rmax=r;

      }
    }
  }
  /* rmax: maximum distance from COM to starred hull of map */


  return sph;
}

vlSpherical *volumetric_sampling_slow(vlVolume *vol, int in[],int out[], int zero[], int bw, int maxext,float cx,
                                  float cy,float cz,float rho,vlSpherical *sph2)
{
  /* performs the sampling in spherical coordinates */

  int i, j, r, size;
  float lambda, theta, initlambda;          /* longitude and latitude */
  float stsl, stcl, st, ct;
  float x, y, z;
  float aux=0.0;
  int g_extx, g_exty, g_extz;
  int g_extx1, g_exty1, g_extz1;
  vlSpherical *sph;


  /* creacion del objeto que representa al volumen en coordenadas esfericas */
  if(sph2==NULL)
    sph= new vlSpherical(bw,maxext);
  else
    sph=sph2;

  g_extx=vol->dim().x(); g_extx1= g_extx -1;
  g_exty=vol->dim().y(); g_exty1= g_exty -1;
  g_extz=vol->dim().z(); g_extz1= g_extz -1;


  size=(bw<<1);
  initlambda=M_PI/bw;


  in[0]=maxext;
  in[1]=0;
  out[0]=maxext;
  out[1]=0;
  zero[0]=maxext;
  zero[1]=0;


  for(i=0;i<size;i++) /* i represents latitude values */
  {
    theta= 0.5*M_PI*(i+0.5)/bw;
    st=sin(theta)*rho; ct=cos(theta)*rho;
    for(j=0,lambda=0; j<size;j++, lambda+=initlambda)         /* j represents longitude values */
    {
      stsl=st*sin(lambda); stcl=st*cos(lambda);
      for(r=0, x = cx, y=cy, z=cz;r<maxext;r++, x+=stcl, y+=stsl, z+=ct)
      {
         if(x<0.0 || x>=g_extx1 || y<0.0 || y>=g_exty1 || z<0.0 || z>=g_extz1) {
          for(;r<maxext;r++)
            sph->setP(r,i,j,0.0);
          break;
        }

        /* interpolation */
        vol->getVoxel(vlPoint3f(x,y,z),aux);
        sph->setP(r,i,j,aux);

      }
    }
  }

 //rmax: maximum distance from COM to starred hull of map



  for(i=0;i<size;i++){
    for(j=0;j<size;j++)
    {
      for(r=maxext-1;r>=0;r--)
        if(sph->getP(r,i,j)>0.0){
          if(r< out[0]) out[0]=r;
          if(r> out[1]) out[1]=r;
          break;
        }

      for(r=0;r<maxext;r++)
        if(sph->getP(r,i,j)>0.0){
          if(r< in[0]) in[0]=r;
          if(r> in[1]) in[1]=r;
          break;
        }


      for(r=0;r<maxext;r++)
        if(sph->getP(r,i,j)==0.0){
          if(r< zero[0]) zero[0]=r;
          if(r> zero[1]) zero[1]=r;
          break;
        }

    }
  }

  return sph;
}


void volumetric_sampling_slow_Dim(vlVolume *vol, int in[],int out[], int zero[], int bw, int maxext,float cx,
                                  float cy,float cz,float rho)
{
  /* performs the sampling in spherical coordinates */

  int i, j, r, size;
  float lambda, theta, initlambda;          /* longitude and latitude */
  float stsl, stcl, st, ct;
  float x, y, z;
  float aux=0.0;
  int g_extx, g_exty, g_extz;
  int g_extx1, g_exty1, g_extz1;
  vlSpherical *sph;


  /* creacion del objeto que representa al volumen en coordenadas esfericas */
    sph= new vlSpherical(bw,maxext);


  g_extx=vol->dim().x(); g_extx1= g_extx -1;
  g_exty=vol->dim().y(); g_exty1= g_exty -1;
  g_extz=vol->dim().z(); g_extz1= g_extz -1;


  size=(bw<<1);
  initlambda=M_PI/bw;


  in[0]=maxext;
  in[1]=0;
  out[0]=maxext;
  out[1]=0;
  zero[0]=maxext;
  zero[1]=0;


  for(i=0;i<size;i++) /* i represents latitude values */
  {
    theta= 0.5*M_PI*(i+0.5)/bw;
    st=sin(theta)*rho; ct=cos(theta)*rho;
    for(j=0,lambda=0; j<size;j++, lambda+=initlambda)         /* j represents longitude values */
    {
      stsl=st*sin(lambda); stcl=st*cos(lambda);
      for(r=0, x = cx, y=cy, z=cz;r<maxext;r++, x+=stcl, y+=stsl, z+=ct)
      {
         if(x<0.0 || x>=g_extx1 || y<0.0 || y>=g_exty1 || z<0.0 || z>=g_extz1) {
          for(;r<maxext;r++)
            sph->setP(r,i,j,0.0);
          break;
        }

        /* interpolation */
        vol->getVoxel(vlPoint3f(x,y,z),aux);
        sph->setP(r,i,j,aux);

      }
    }
  }

 //rmax: maximum distance from COM to starred hull of map



  for(i=0;i<size;i++){
    for(j=0;j<size;j++)
    {
      for(r=maxext-1;r>=0;r--)
        if(sph->getP(r,i,j)>0.0){
          if(r< out[0]) out[0]=r;
          if(r> out[1]) out[1]=r;
          break;
        }

      for(r=0;r<maxext;r++)
        if(sph->getP(r,i,j)>0.0){
          if(r< in[0]) in[0]=r;
          if(r> in[1]) in[1]=r;
          break;
        }


      for(r=0;r<maxext;r++)
        if(sph->getP(r,i,j)==0.0){
          if(r< zero[0]) zero[0]=r;
          if(r> zero[1]) zero[1]=r;
          break;
        }

    }
  }

  delete sph;
}



vlSpherical *volumetric_sampling_fastL(vlVolume *vol, int *rmax, int bw, int maxext,float cx,
                                   float cy,float cz,float* buf_lambda,float* buf_theta ,vlSpherical *sph2)
 {
   /* performs the sampling in spherical coordinates */

   int i, j, r, size;
   float stsl, stcl, ct;
   float x, y, z;
   float aux=0.0;

   int bw_1,bw_12,index_stsl;
   vlPoint3ui pos;
   int g_extx, g_exty, g_extz;
   int g_extx1, g_exty1, g_extz1;
   vlSpherical *sph;
   int index;


   //Valores predeterminados
   size=(bw<<1);
   bw_1=bw-1;
   bw_12=bw_1*bw_1;
   index_stsl=((bw_1)*(4*bw_12-1)/3);



   /* creacion del objeto que representa al volumen en coordenadas esfericas */

   if(sph2==NULL)
     sph= new vlSpherical(bw,maxext);
   else
     sph=sph2;

   g_extx=vol->dim().x(); g_extx1= g_extx -1;
   g_exty=vol->dim().y(); g_exty1= g_exty -1;
   g_extz=vol->dim().z(); g_extz1= g_extz -1;



   *rmax=0;
   for(i=0;i<size;i++) /* i represents latitude values */
   {

       ct=buf_theta[bw_12+i];

     for(j=0; j<size;j++)         /* j represents longitude values */
     {
         index=(index_stsl + size*i +j)<<1;
         stsl=buf_lambda[index];
         stcl=buf_lambda[index+1];

      for(r=0, x = cx, y=cy, z=cz;r<maxext;r++, x+=stcl, y+=stsl, z+=ct)
       {
         if(x<0.0 || x>=g_extx1 || y<0.0 || y>=g_exty1 || z<0.0 || z>=g_extz1) {
           for(;r<maxext;r++)
             sph->setP(r,i,j,0.0);
           break;
         }

         /* interpolation */
         vol->getVoxel(vlPoint3f(x,y,z),aux);
         sph->setP(r,i,j,aux);


         /* rmax: maximum distance from COM to starred hull of map */
          if(aux!=0.0 && r> *rmax) *rmax=r;

       }
     }
   }

   return sph;
 }


//****************FIN TRANSFORMACIONES***************************************************


}
#endif

#ifdef PDB_INCLUDED


vlSpherical *pdb_atom_sampling(Macromolecule *pdb, int bw, int maxext,float cx,
                                  float cy,float cz,float width,vlSpherical *sph2)
{
  /* performs the sampling in spherical coordinates */

  int i;
  float initlambda,aux,rho,alpha,betha;
  Tcoor pos;
  vlSpherical *sph;
  Atom *at;
  double normDist;
  float sigma;


  Tipolar Entorno[500000];
  Tpolar punto;
  int numVecinos;
  int irho,ialpha,ibetha;

  initlambda=M_PI/bw;

   //Objeto esferico a crear
   if(sph2==NULL)
    sph= new vlSpherical(bw,maxext);
   else
     sph=sph2;

  //Se hace un recorrido por todos los atomos del PDB
   pdb->initAll();

  aux=0;
  do{


    at=pdb->getCurrentAtom();
    at->getPosition(pos);

    //CALCULO DE LAS COORDENADAS ESFERICAS DEL ATOMO
    //calculo de rho del punto
    rho=sqrt((cx-pos[0])*(cx-pos[0]) + (cy-pos[1])*(cy-pos[1]) + (cz-pos[2])*(cz-pos[2]));
    if(rho<(float)(maxext)*width-(at->getElement()->vdw))
    {
     //calculo de alpha
     alpha=acos((pos[2]-cz)/rho);

     //calculo de betha
     betha=asin((pos[1]-cy)/sqrt((cx-pos[0])*(cx-pos[0]) + (cy-pos[1])*(cy-pos[1]))  );
     if((pos[0]-cx)<=0)
      betha=M_PI-betha;

      punto.betha=polar_normal(betha);
      punto.alpha=polar_normal(alpha);
      punto.rho=rho;

      //CALCULO DE LOS PUNTOS DEL OBJETO ESFERICO BAJO LA "INFLUENCIA" DEL ATOMO
      numVecinos=entorno((at->getElement()->vdw)*1.2,punto,width,initlambda,bw, maxext,Entorno,&normDist);



      //Modificacion de los puntos del objeto esferico cercanos al atomo
      for(i=0;i<numVecinos;i++)
      {
        irho=Entorno[i].rho;
        ialpha=Entorno[i].alpha;
        ibetha=Entorno[i].betha;
        if(irho<0 || irho>=maxext || ibetha<0.0 || ibetha>=2*bw ||  ialpha<0.0 || ialpha>=2*bw)
        {
          fprintf(stderr,"ibetha=%d Entorno[i].betha=%d ialpha=%d vecino=%d\n",ibetha,Entorno[i].betha, ialpha,i);
          exit(1);
        }

        sigma=(at->getElement()->vdw)/sqrt(1.0);
        aux=sph->getP(irho,ialpha,ibetha);
        aux+=(1.0 * exp(Entorno[i].dist*Entorno[i].dist/(-2*sigma*sigma)));
        //aux+=(at->getElement())->weight * (1.0/Entorno[i].dist) * (1.0/normDist);
        //aux+=(at->getElement())->weight * exp(factor*Entorno[i].dist);
        //aux+=(at->getElement())->weight/64.0;
            //totalWeight+=(at->getElement())->weight/8.0;
        sph->setP(irho,ialpha,ibetha,aux);

      }
    }
  }while(pdb->nextAtom()!=false);

  return sph;
}

vlSpherical *pdb_gauss_sampling(Macromolecule *pdb, int bw, int maxext,float cx,
                                  float cy,float cz,float width,vlSpherical *sph2)
{
  /* performs the sampling in spherical coordinates */

  int i;
  float initlambda,aux,rho,alpha,betha;
  Tcoor pos;
  vlSpherical *sph;
  Atom *at;
  double normDist;
  float sigma;
  float radius;


  Tipolar Entorno[500000];
  Tpolar punto;
  int numVecinos;
  int irho,ialpha,ibetha;

  initlambda=M_PI/bw;

   //Objeto esferico a crear
   if(sph2==NULL)
    sph= new vlSpherical(bw,maxext);
   else
     sph=sph2;

  //Se hace un recorrido por todos los atomos del PDB
  pdb->initAll();
  aux=0;
  do{
    at=pdb->getCurrentAtom();

    radius=at->getPdbocc()*2.0;
    sigma=at->getPdbocc();
    at->getPosition(pos);

    //CALCULO DE LAS COORDENADAS ESFERICAS DEL ATOMO
    //calculo de rho del punto
    rho=sqrt((cx-pos[0])*(cx-pos[0]) + (cy-pos[1])*(cy-pos[1]) + (cz-pos[2])*(cz-pos[2]));
    if(rho<(float)(maxext)*width-radius)
    {
     //calculo de alpha
     alpha=acos((pos[2]-cz)/rho);

     //calculo de betha
     betha=asin((pos[1]-cy)/sqrt((cx-pos[0])*(cx-pos[0]) + (cy-pos[1])*(cy-pos[1]))  );
     if((pos[0]-cx)<=0)
      betha=M_PI-betha;

      punto.betha=polar_normal(betha);
      punto.alpha=polar_normal(alpha);
      punto.rho=rho;

      //CALCULO DE LOS PUNTOS DEL OBJETO ESFERICO BAJO LA "INFLUENCIA" DEL ATOMO
      numVecinos=entorno(radius,punto,width,initlambda,bw, maxext,Entorno,&normDist);
      if(numVecinos>=500000)
      {
        fprintf(stderr,"\nError\n");
        exit(1);
      }


      //Modificacion de los puntos del objeto esferico cercanos al atomo
      for(i=0;i<numVecinos;i++)
      {
        irho=Entorno[i].rho;
        ialpha=Entorno[i].alpha;
        ibetha=Entorno[i].betha;
        if(irho<0 || irho>=maxext || ibetha<0.0 || ibetha>=2*bw ||  ialpha<0.0 || ialpha>=2*bw)
        {
          fprintf(stderr,"ibetha=%d Entorno[i].betha=%d ialpha=%d vecino=%d\n",ibetha,Entorno[i].betha, ialpha,i);
          exit(1);
        }


        aux=sph->getP(irho,ialpha,ibetha);
        aux+=(1.0 * exp(Entorno[i].dist*Entorno[i].dist/(-2*sigma*sigma)));
        //aux+=(at->getElement())->weight * (1.0/Entorno[i].dist) * (1.0/normDist);
        //aux+=(at->getElement())->weight * exp(factor*Entorno[i].dist);
        //aux+=(at->getElement())->weight/64.0;
            //totalWeight+=(at->getElement())->weight/8.0;
        sph->setP(irho,ialpha,ibetha,aux);

      }
    }
  }while(pdb->nextAtom()!=false);

  return sph;
}





#endif

void writeSphVol(char* name, vlSpherical *sph, int bw,int rmax,float width, float cx,float cy,float cz)
{
  FILE *f=fopen(name,"wt");
  int i,j,r,size=2*bw,cont=0;
  float x,y,z;
  float theta,lambda,initlambda,stsl,stcl,st,ct,aux;
  initlambda=M_PI/bw;


  for(i=0;i<size;i++) /* i represents latitude values */
  {

    theta= 0.5*M_PI*(i+0.5)/bw;
    st=sin(theta)*width; ct=cos(theta)*width;
    for(j=0,lambda=0; j<size;j++,lambda+=initlambda)         /* j represents longitude values */
    {
      stsl=st*sin(lambda); stcl=st*cos(lambda);
      for(r=0, x = cx, y=cy, z=cz;r<rmax;r++, x+=stcl, y+=stsl, z+=ct)
      {
        aux=sph->getP(r,i,j);
        if(aux<0)
          fprintf(f,"ATOM%7d  N   GLY A 735    %8.2f%8.2f%8.2f  1.00 %6.3f           N\n",
          cont++,x,y,z,aux*1000);
      }
    }
  }

  fclose(f);
}
