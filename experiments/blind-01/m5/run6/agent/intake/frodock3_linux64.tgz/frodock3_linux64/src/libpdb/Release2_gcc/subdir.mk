################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CPP_SRCS += \
../Atomo.cpp \
../Chain.cpp \
../Condition.cpp \
../Fragment.cpp \
../MacroAccess.cpp \
../MacroConst.cpp \
../MacroInfo.cpp \
../MacroModif.cpp \
../MacroOI.cpp \
../MacroS.cpp \
../MacroV.cpp \
../Molecule.cpp \
../NAcid.cpp \
../Nucleotide.cpp \
../Protein.cpp \
../ResIni.cpp \
../Rotamer.cpp \
../SMol.cpp \
../Segment.cpp \
../atomoperator.cpp \
../container.cpp \
../pdbIter.cpp \
../residue.cpp 

OBJS += \
./Atomo.o \
./Chain.o \
./Condition.o \
./Fragment.o \
./MacroAccess.o \
./MacroConst.o \
./MacroInfo.o \
./MacroModif.o \
./MacroOI.o \
./MacroS.o \
./MacroV.o \
./Molecule.o \
./NAcid.o \
./Nucleotide.o \
./Protein.o \
./ResIni.o \
./Rotamer.o \
./SMol.o \
./Segment.o \
./atomoperator.o \
./container.o \
./pdbIter.o \
./residue.o 

CPP_DEPS += \
./Atomo.d \
./Chain.d \
./Condition.d \
./Fragment.d \
./MacroAccess.d \
./MacroConst.d \
./MacroInfo.d \
./MacroModif.d \
./MacroOI.d \
./MacroS.d \
./MacroV.d \
./Molecule.d \
./NAcid.d \
./Nucleotide.d \
./Protein.d \
./ResIni.d \
./Rotamer.d \
./SMol.d \
./Segment.d \
./atomoperator.d \
./container.d \
./pdbIter.d \
./residue.d 


# Each subdirectory must supply rules for building sources it contributes
%.o: ../%.cpp
	@echo 'Building file: $<'
	@echo 'Invoking: Cross G++ Compiler'
	g++ -I../include -I../../../src -O2 -U_FORTIFY_SOURCE -g -c -fmessage-length=0 -fpermissive -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


