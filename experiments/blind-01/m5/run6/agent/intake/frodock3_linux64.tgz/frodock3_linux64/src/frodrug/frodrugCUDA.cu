#include "frodrugCUDA.h"
#include <cuda_runtime.h>
#include <stdio.h>
#include <iostream>
using namespace std;
#define M_PI 3.14159265358979323846f

__device__ int dRhoDownIndex[128];
__device__ int dRhoUpIndex[128];
__device__ float dFDown[128];
__device__ float dFUp[128];
__device__ float dLi[128];

__global__ void createIntegralDrugK(float *integralr, float *integrali,int bw, int num_atoms,int grid_weight, int numLayers, int sizeLayer,float *dMcoefr,float *dMcoefi,float *dSolR,float *dSolI,	int *lDV, int *mDV, int *nDV, int sizeCoeff, int num){
	int index = blockIdx.x * blockDim.x + threadIdx.x;
	__shared__ int l[32];
	__shared__ int m[32];
	__shared__ int n[32];
	__shared__ int sRhoDownIndex[128];
	__shared__ int sRhoUpIndex[128];
	__shared__ float sFDown[128];
	__shared__ float sFUp[128];
	__shared__ float sLi[128];
	__shared__ float tempR[1056];
	__shared__ float tempI[1056];

	int flatIndex = threadIdx.y*blockDim.x+threadIdx.x;
	
	if(flatIndex<num_atoms){
		sLi[flatIndex] = dLi[flatIndex];
		sRhoDownIndex[flatIndex]=dRhoDownIndex[flatIndex]*sizeLayer;
		sRhoUpIndex[flatIndex]=dRhoUpIndex[flatIndex]*sizeLayer;
		sFUp[flatIndex]=dFUp[flatIndex];
		sFDown[flatIndex]=dFDown[flatIndex];
	}
	

	if(index < sizeCoeff && threadIdx.y==0){
		l[threadIdx.x] = lDV[index];
		m[threadIdx.x] = mDV[index];
		n[threadIdx.x] = nDV[index];
	}
	__syncthreads();
	// Compute integrals - First Half
	int integral = blockIdx.y*blockDim.y*2+threadIdx.y;
	if(integral<num && index < sizeCoeff){
		float r=0.0f,i=0.0f;
		int indexBase = integral*numLayers*sizeLayer + m[threadIdx.x];
		int indexLig = l[threadIdx.x]*bw + l[threadIdx.x]-abs(n[threadIdx.x]);

		for(int j=0;j<num_atoms;j++){
			float AA, BB, CC, DD,sphericalr,sphericali,e_weight, SH[2];
			e_weight=grid_weight*sLi[j];

			sphericalr = sFDown[j] * dMcoefr[indexBase + sRhoDownIndex[j]] + sFUp[j] * dMcoefr[indexBase + sRhoUpIndex[j]];
			sphericali = sFDown[j] * dMcoefi[indexBase + sRhoDownIndex[j]] + sFUp[j] * dMcoefi[indexBase + sRhoUpIndex[j]];

			SH[0]=dSolR[j*bw*bw + indexLig]*e_weight;
			SH[1]=dSolI[j*bw*bw + indexLig]*e_weight;

			AA=SH[0]*sphericalr;
			BB=SH[1]*sphericali;
			CC=SH[1]*sphericalr;
			DD=SH[0]*sphericali;
			int sign = ((n[threadIdx.x]<0) - (n[threadIdx.x]>=0));
			r += AA + BB * sign;
			i += DD - CC * sign;
		}
		if(n[threadIdx.x] < 0 && n[threadIdx.x]%2!=0){
			r = -r;
			i = -i;
		}
		tempR[threadIdx.y * 33 + threadIdx.x] = r;
		tempI[threadIdx.y * 33 + threadIdx.x] = i;
	}

	// Compute integrals - Second Half
	integral +=blockDim.y;
	if(integral<num && index < sizeCoeff){
		float r=0.0f,i=0.0f;
		int indexBase = integral*numLayers*sizeLayer + m[threadIdx.x];
		int indexLig = l[threadIdx.x]*bw + l[threadIdx.x]-abs(n[threadIdx.x]);

		for(int j=0;j<num_atoms;j++){
			float AA, BB, CC, DD,sphericalr,sphericali,e_weight, SH[2];
			e_weight=grid_weight*sLi[j];

			sphericalr = sFDown[j] * dMcoefr[indexBase + sRhoDownIndex[j]] + sFUp[j] * dMcoefr[indexBase + sRhoUpIndex[j]];
			sphericali = sFDown[j] * dMcoefi[indexBase + sRhoDownIndex[j]] + sFUp[j] * dMcoefi[indexBase + sRhoUpIndex[j]];

			SH[0]=dSolR[j*bw*bw + indexLig]*e_weight;
			SH[1]=dSolI[j*bw*bw + indexLig]*e_weight;

			AA=SH[0]*sphericalr;
			BB=SH[1]*sphericali;
			CC=SH[1]*sphericalr;
			DD=SH[0]*sphericali;
			int sign = ((n[threadIdx.x]<0) - (n[threadIdx.x]>=0));
			r += AA + BB * sign;
			i += DD - CC * sign;
		}
		if(n[threadIdx.x] < 0 && n[threadIdx.x]%2!=0){
			r = -r;
			i = -i;
		}
		tempR[(threadIdx.y+blockDim.y) * 33 + threadIdx.x] = r;
		tempI[(threadIdx.y+blockDim.y) * 33 + threadIdx.x] = i;
	}

	__syncthreads();

	// Write integrals - First Half
	int indexOut = blockIdx.x*blockDim.x*((num/32+1)*32) + blockIdx.y*blockDim.y*2 + threadIdx.y*((num/32+1)*32) + threadIdx.x;
	if(blockIdx.x == gridDim.x-1){
		if(flatIndex/warpSize < sizeCoeff % blockDim.x){
			integralr[indexOut] = tempR[threadIdx.x * 33 + threadIdx.y];
			integrali[indexOut] = tempI[threadIdx.x * 33 + threadIdx.y];
		}
	}else{
		integralr[indexOut] = tempR[threadIdx.x * 33 + threadIdx.y];
		integrali[indexOut] = tempI[threadIdx.x * 33 + threadIdx.y];
	}

	// Write integrals - Second Half
	indexOut += 16*((num/32+1)*32);
	if(blockIdx.x == gridDim.x-1){
		if((flatIndex+256)/warpSize < sizeCoeff % blockDim.x){
			integralr[indexOut] = tempR[threadIdx.x * 33 + threadIdx.y+blockDim.y];
			integrali[indexOut] = tempI[threadIdx.x * 33 + threadIdx.y+blockDim.y];
		}
	}else{
		integralr[indexOut] = tempR[threadIdx.x * 33 + threadIdx.y+blockDim.y];
		integrali[indexOut] = tempI[threadIdx.x * 33 + threadIdx.y+blockDim.y];
	}
}

__global__ void fourierCorrK(int bw, float* coeffr, float* coeffi, float* ddd, float* coefCorr){
	int ySize = 2*bw;
	int xSize = 2*(bw+1);
	int indexCoeff = blockIdx.x*blockDim.x + threadIdx.x;
	int baseCorr = 2*bw*2*bw*2*(bw+1) * indexCoeff;
	int numIntegrals = gridDim.x*warpSize;
	__shared__ float temp[1056];
	int z=blockIdx.z;
	int y=blockIdx.y;
	int index,lInit,m,mp,h,lEnd;
	int x=threadIdx.y; // Y index in block will be used for x indexing in each volume
	if(y<bw){
		// z < 16 && (0 < y < 16)
		h = y;
		m = z;
		lInit = (h>m)*h + (h<=m)*m;

		mp = -lInit+x;

		if(x > lInit){
			lInit = x;
		}

		if(mp>0){
			mp=0;
		}
		if(lInit==bw-1 && m==0){
			mp = x;
		}

		lEnd = bw;
		if(m>0 && h>0){
			lEnd=bw-1;
		}

		float r=0,i=0;
		for(int l=lInit; l<lEnd ;l++){
			int indMH =l*(4*l*l-1)/3+l*(2*l+1)+ m*(2*l+1) + l + h;
			int indHMP = l*(4*l*l-1)/3+l*(2*l+1)+ h*(2*l+1) + l + mp+l;
			int coeffInd = (l*(4*l*l-1)/3+l*l)/2 +  m*(2*l+1) + l + mp+l;
			if(l==bw-1 && m==0){
				coeffInd -= l;
				indHMP -= l;
			}
			coeffInd = coeffInd * numIntegrals + indexCoeff;
			float tempd = ddd[indMH]*ddd[indHMP];
			r += coeffr[coeffInd] * tempd;
			i += coeffi[coeffInd] * tempd;
			mp--;
			if(l==bw-2 && m==0){
				mp = x;
			}
		}
		temp[threadIdx.x*33+x*2]=r;
		temp[threadIdx.x*33+x*2+1]=i;
	}else{
		// y > 16 && z > 16
		int zAlt = z + bw; // Alternative Z
		int yAlt = y + 1; // Alternative Y

		h = 2*bw - yAlt;
		m = 2*bw - zAlt;
		mp = -x;

		lInit = (h>m)*h + (h<=m)*m;

		if(x > lInit){
			lInit = x;
		}

		lEnd = bw;

		float r=0,i=0;
		for(int l=lInit; l<lEnd ;l++){
			int indMH = l*(4*l*l-1)/3+l*(2*l+1)+ m*(2*l+1) + l + h;
			int indHMP = l*(4*l*l-1)/3+l*(2*l+1)+ h*(2*l+1) + l + mp;
			int coeffInd = ((l*(4*l*l-1)/3+l*l)/2 +  m*(2*l+1) + l + mp) * numIntegrals + indexCoeff;
			float tempd = ddd[indMH]*ddd[indHMP];
			r += coeffr[coeffInd] * tempd;
			i -= coeffi[coeffInd] * tempd;
		}
		temp[threadIdx.x*33+x*2]=r;
		temp[threadIdx.x*33+x*2+1]=i;
	}

	// Data writing
	__syncthreads();
	for(int volume=0;volume<32;volume+=bw){
		indexCoeff = blockIdx.x*blockDim.x + volume + threadIdx.y;
		baseCorr = 2*bw*2*bw*2*(bw+1) * indexCoeff;
		if(y<bw){
			// z < 16 && (0 < y < 16)
			index = z*ySize*xSize + y*xSize + threadIdx.x + baseCorr;
			coefCorr[index] = temp[(volume+threadIdx.y)*33+threadIdx.x];
			// Mirror a otro cuadrante
			if(y!=0){
				int indexMirror = z*ySize*xSize + (2*bw-y)*xSize + threadIdx.x + baseCorr;
				int sig = 1 - 2*(((threadIdx.x/2)%2!=0 && z%2==0) || ((threadIdx.x/2)%2==0 && z%2!=0));
				coefCorr[indexMirror] = temp[(volume+threadIdx.y)*33+threadIdx.x]*sig;
			}
		}else{
			// y > 16 && z > 16
			int zAlt = z + bw; // Alternative Z
			int yAlt = y + 1; // Alternative Y
			index = zAlt*ySize*xSize + yAlt*xSize + threadIdx.x + baseCorr;
			coefCorr[index] = temp[(volume+threadIdx.y)*33+threadIdx.x];
			int indexMirror = zAlt*ySize*xSize + (2*bw-yAlt)*xSize + threadIdx.x + baseCorr;
			int sig = 1 - 2*(((threadIdx.x/2)%2!=0 && z%2==0) || ((threadIdx.x/2)%2==0 && z%2!=0));
			coefCorr[indexMirror] = temp[(volume+threadIdx.y)*33+threadIdx.x]*sig;
		}
	}
	__syncthreads();

	// z > 15  && y == 0
	if(y==0){
		indexCoeff = blockIdx.x*blockDim.x + threadIdx.x;
		z+=bw;
		int index,lInit,m,mp,h,lEnd;
		int x=threadIdx.y;
		h = 0;
		m = 2*bw - z;
		mp = -x;

		lInit = m;
		if(x > lInit){
			lInit = x;
		}
		lEnd = bw;

		float r=0,i=0;
		for(int l=lInit; l<lEnd ;l++){
			int indMH = l*(4*l*l-1)/3+l*(2*l+1)+ m*(2*l+1) + l + h;
			int indHMP = l*(4*l*l-1)/3+l*(2*l+1)+ h*(2*l+1) + l + mp;
			int coeffInd = ((l*(4*l*l-1)/3+l*l)/2 +  m*(2*l+1) + l + mp) * numIntegrals + indexCoeff;
			float tempd = ddd[indMH]*ddd[indHMP];
			r += coeffr[coeffInd] * tempd;
			i -= coeffi[coeffInd] * tempd;
		}
		temp[threadIdx.x*33+x*2]=r;
		temp[threadIdx.x*33+x*2+1]=i;

		// Data writing
		__syncthreads();
		for(int volume=0;volume<32;volume+=bw){
			indexCoeff = blockIdx.x*blockDim.x + volume + threadIdx.y;
			baseCorr = 2*bw*2*bw*2*(bw+1) * indexCoeff;

			// z > 15  && y == 0
			index = z*ySize*xSize + threadIdx.x + baseCorr;
			coefCorr[index] = temp[(volume+threadIdx.y)*33+threadIdx.x];
		}
	}
}

__device__ void maxVal(float* interpolated,float* data000,float* data010,float* data020, int indexShared, int offset){
	if(interpolated[indexShared+offset]>interpolated[indexShared]){
		interpolated[indexShared] = interpolated[indexShared+offset];
		data000[indexShared] = data000[indexShared+offset];
		data010[indexShared] = data010[indexShared+offset];
		data020[indexShared] = data020[indexShared+offset];
	}
}

__device__ void maxValVolatile(volatile float* interpolated,volatile float* data000,volatile float* data010,volatile float* data020, int indexShared, int offset){
	if(interpolated[indexShared+offset]>interpolated[indexShared]){
		interpolated[indexShared] = interpolated[indexShared+offset];
		data000[indexShared] = data000[indexShared+offset];
		data010[indexShared] = data010[indexShared+offset];
		data020[indexShared] = data020[indexShared+offset];
	}
}

__device__ void performInterpolation(float* inf, float* base, float* sup, float* oldCorr, float* oldPsi,float* oldTh,float* oldPhi,int bw,int yIndex){
	float f000,f100, f200, f010, f020, f001, f002;
	int indexShared = blockDim.x * threadIdx.z + threadIdx.x;
	float maxCorr = 0, psi=0, th=0, phi=0;

	f000 = base[indexShared];
	if(threadIdx.z == 0){
		f100 = base[indexShared + 992]; // 992 = (2*bw-1)*2*bw
	}else{
		f100 = base[indexShared - 32]; // 32 = 2*bw
	}
	if(threadIdx.z == blockDim.z-1){
		f200 = base[indexShared - 992]; // 992 = (2*bw-1)*2*bw
	}else{
		f200 = base[indexShared + 32]; // 32 = 2*bw
	}
	f010 = inf[indexShared];
	f020 = sup[indexShared];
	if(threadIdx.x == 0){
		f001 = base[indexShared+31];
	}else{
		f001 = base[indexShared-1];
	}
	if(threadIdx.x == blockDim.x-1){
		f002 = base[indexShared-31];
	}else{
		f002 = base[indexShared+1];
	}
	if(f000>0 && f000>=f100 && f000>=f200 && f000>=f010 && f000>=f020 && f000>=f001 && f000>=f002){
		// compute correlation
		if(f100>f200){
			if(f200<(f100*0.25f)){
				f100 = f000;
				f200 = f000;
			}
		}else{
			if(f100<(f200*0.25f)){
				f100 = f000;
				f200 = f000;
			}
		}

		if(f010>f020){
			if(f020<(f010*0.25f)){
				f010 = f000;
				f020 = f000;
			}
		}else{
			if(f010<(f020*0.25f)){
				f010 = f000;
				f020 = f000;
			}
		}

		if(f001>f002){
			if(f002<(f001*0.25f)){
				f001 = f000;
				f002 = f000;
			}
		}else{
			if(f001<(f002*0.25f)){
				f001 = f000;
				f002 = f000;
			}
		}

		float tempi = 0.0f;
		float tempj = 0.0f;
		float tempk = 0.0f;
		float temp;

		if ( ( temp = f100 + f200 - 2.0f * f000 ) != 0.0f ){
			tempi = ( f100 - f200 ) / ( 2.0f * temp );
		}
		float phe = ( threadIdx.z + tempi ) * M_PI / bw;

		if ( yIndex != 0 ){
			if ( ( temp = f010 + f020 - 2.0f * f000 ) != 0 ){
				tempj = ( f010 - f020 ) / ( 2.0f * temp );
			}
		}
		float phc = ( yIndex + tempj ) * M_PI / bw;

		if(phc>M_PI){
			phc=M_PI;
			tempj=0.0f;
		}else{
			if(phc<0){
				phc=0.0f;
				tempj=0.0f;
			}
		}

		if ( ( temp = f001 + f002 - 2.0f * f000 ) != 0 ){
			tempk = ( f001 - f002 ) / ( 2.0f * temp );
		}
		float ohm = ( threadIdx.x + tempk ) * M_PI / bw;

		psi = -phe;
		psi = psi - 2.0f * M_PI * floor( psi / 2.0f / M_PI );
		th = M_PI - phc;
		phi = M_PI - ohm;
		phi = phi - 2.0f * M_PI * floor( phi / 2.0f / M_PI );

		maxCorr =( 0.5f * ( f100 + f200 ) - f000 ) * tempi * tempi + ( 0.5f * ( f010 + f020 ) - f000 ) * tempj
			* tempj + ( 0.5f * ( f001 + f002 ) - f000 ) * tempk * tempk + 0.5f * ( f200 - f100 ) * tempi + 0.5f
			* ( f020 - f010 ) * tempj + 0.5f * ( f002 - f001 ) * tempk + f000;
	}
	if(maxCorr>*oldCorr){
		*oldCorr = maxCorr; // Correlation
		*oldPsi = psi; // Psi
		*oldTh = th; // Th
		*oldPhi = phi; // Phi
	}
}

__global__ void searchCorrK(int bw, float *in,float *out,float* dPsi,float* dTh, float* dPhi){
	__shared__ float data010[1024]; // y-1
	__shared__ float data000[1024]; // y
	__shared__ float data020[1024]; // y+1
	__shared__ float dataTemp[1024]; // y+2

	float maxCorr = 0;
	float psi=0, th=0, phi=0;

	const int indexMem = 8*bw*bw*bw * blockIdx.x + threadIdx.z*4*bw*bw + threadIdx.x;
	const int indexShared = blockDim.x * threadIdx.z + threadIdx.x;

	// Loading main values (every 'z' and 'x' for slice 0)
	data000[indexShared] = in[indexMem];

	// Loading 'y+1' values for slice 0
	data020[indexShared] = in[indexMem+2*bw];

	__syncthreads(); // Base values are loaded here
	dataTemp[indexShared] = in[indexMem+2*2*bw]; // Loading 'y+1' values for slice 1
	performInterpolation(data000, data000, data020, &maxCorr, &psi,&th,&phi,bw,0); // Slice 0 interpolation
	__syncthreads(); // 'y+1' values for slice 1 are loaded here
	data010[indexShared] = in[indexMem+3*2*bw];  // Loading 'y+1' values for slice 2
	performInterpolation(data000, data020, dataTemp, &maxCorr, &psi,&th,&phi,bw,1); // Slice 1 interpolation
	__syncthreads(); // 'y+1' values for slice 2 are loaded here
	data000[indexShared] = in[indexMem+4*2*bw];  // Loading 'y+1' values for slice 3
	performInterpolation(data020, dataTemp, data010, &maxCorr, &psi,&th,&phi,bw,2); // Slice 2 interpolation
	__syncthreads(); // 'y+1' values for slice 3 are loaded here
	data020[indexShared] = in[indexMem+5*2*bw];  // Loading 'y+1' values for slice 4
	performInterpolation(dataTemp, data010, data000, &maxCorr, &psi,&th,&phi,bw,3); // Slice 3 interpolation
	__syncthreads(); // 'y+1' values for slice 4 are loaded here
	dataTemp[indexShared] = in[indexMem+6*2*bw]; // Loading 'y+1' values for slice 5
	performInterpolation(data010, data000, data020, &maxCorr, &psi,&th,&phi,bw,4); // Slice 4 interpolation
	__syncthreads(); // 'y+1' values for slice 5 are loaded here
	data010[indexShared] = in[indexMem+7*2*bw]; // Loading 'y+1' values for slice 6
	performInterpolation(data000, data020, dataTemp, &maxCorr, &psi,&th,&phi,bw,5); // Slice 5 interpolation
	__syncthreads(); // 'y+1' values for slice 6 are loaded here
	data000[indexShared] = in[indexMem+8*2*bw]; // Loading 'y+1' values for slice 7
	performInterpolation(data020, dataTemp, data010, &maxCorr, &psi,&th,&phi,bw,6); // Slice 6 interpolation
	__syncthreads(); // 'y+1' values for slice 7 are loaded here
	data020[indexShared] = in[indexMem+9*2*bw]; // Loading 'y+1' values for slice 8
	performInterpolation(dataTemp, data010, data000, &maxCorr, &psi,&th,&phi,bw,7); // Slice 7 interpolation
	__syncthreads(); // 'y+1' values for slice 8 are loaded here
	dataTemp[indexShared] = in[indexMem+10*2*bw]; // Loading 'y+1' values for slice 9
	performInterpolation(data010, data000, data020, &maxCorr, &psi,&th,&phi,bw,8); // Slice 8 interpolation
	__syncthreads(); // 'y+1' values for slice 9 are loaded here
	data010[indexShared] = in[indexMem+11*2*bw]; // Loading 'y+1' values for slice 10
	performInterpolation(data000, data020, dataTemp, &maxCorr, &psi,&th,&phi,bw,9); // Slice 9 interpolation
	__syncthreads(); // 'y+1' values for slice 10 are loaded here
	data000[indexShared] = in[indexMem+12*2*bw]; // Loading 'y+1' values for slice 11
	performInterpolation(data020, dataTemp, data010, &maxCorr, &psi,&th,&phi,bw,10); // Slice 10 interpolation
	__syncthreads(); // 'y+1' values for slice 11 are loaded here
	data020[indexShared] = in[indexMem+13*2*bw]; // Loading 'y+1' values for slice 12
	performInterpolation(dataTemp, data010, data000, &maxCorr, &psi,&th,&phi,bw,11); // Slice 11 interpolation
	__syncthreads(); // 'y+1' values for slice 12 are loaded here
	dataTemp[indexShared] = in[indexMem+14*2*bw]; // Loading 'y+1' values for slice 13
	performInterpolation(data010, data000, data020, &maxCorr, &psi,&th,&phi,bw,12); // Slice 12 interpolation
	__syncthreads(); // 'y+1' values for slice 13 are loaded here
	data010[indexShared] = in[indexMem+15*2*bw]; // Loading 'y+1' values for slice 14
	performInterpolation(data000, data020, dataTemp, &maxCorr, &psi,&th,&phi,bw,13); // Slice 13 interpolation
	__syncthreads(); // 'y+1' values for slice 14 are loaded here
	data000[indexShared] = in[indexMem+16*2*bw]; // Loading 'y+1' values for slice 15
	performInterpolation(data020, dataTemp, data010, &maxCorr, &psi,&th,&phi,bw,14); // Slice 14 interpolation
	__syncthreads(); // 'y+1' values for slice 15 are loaded here
	performInterpolation(dataTemp, data010, data000, &maxCorr, &psi,&th,&phi,bw,15); // Slice 15 interpolation
	performInterpolation(data010, data000, data000, &maxCorr, &psi,&th,&phi,bw,16); // Slice 16 interpolation


	dataTemp[indexShared] = maxCorr; // Correlation
	data000[indexShared] = psi; // Psi
	data010[indexShared] = th; // Th
	data020[indexShared] = phi; // Phi
	__syncthreads();
	if(indexShared<512){
		maxVal(dataTemp,data000,data010,data020,indexShared,512);
	}
	__syncthreads();
	if(indexShared<256){
		maxVal(dataTemp,data000,data010,data020,indexShared,256);
	}
	__syncthreads();
	if(indexShared<128){
		maxVal(dataTemp,data000,data010,data020,indexShared,128);
	}
	__syncthreads();
	if(indexShared<64){
		maxVal(dataTemp,data000,data010,data020,indexShared,64);
	}
	__syncthreads();
	if(indexShared<32){ // No sync from here, all threads belong to the same warp
		maxValVolatile(dataTemp,data000,data010,data020,indexShared,32);
		maxValVolatile(dataTemp,data000,data010,data020,indexShared,16);
		maxValVolatile(dataTemp,data000,data010,data020,indexShared,8);
		maxValVolatile(dataTemp,data000,data010,data020,indexShared,4);
		maxValVolatile(dataTemp,data000,data010,data020,indexShared,2);
		maxValVolatile(dataTemp,data000,data010,data020,indexShared,1);
	}

	if(indexShared==0){
		out[blockIdx.x] = dataTemp[0];
		dPsi[blockIdx.x] = data000[0];
		dTh[blockIdx.x] = data010[0];
		dPhi[blockIdx.x] = data020[0];
	}
}

void searchCorrCUDA(int bw, float *in,float *dCorr,float* dPsi,float* dTh, float* dPhi, int num){
	static dim3 searchCorrGrid;
	static dim3 searchCorrBlock;
	static bool init = true;
	if(init){
		init = false;
		searchCorrGrid.x = num;
		searchCorrGrid.y = 1;
		searchCorrGrid.z = 1;
		searchCorrBlock.x = 2*bw;
		searchCorrBlock.y = 1;
		searchCorrBlock.z = 2*bw;
		cudaFuncSetCacheConfig(searchCorrK,cudaFuncCachePreferEqual);
	}
	searchCorrK<<<searchCorrGrid,searchCorrBlock>>>(bw,in,dCorr,dPsi, dTh, dPhi);
}

void createIntegralDrugCUDA(float *dCoeffr, float *dCoeffi,int bw, int num_atoms,int grid_weight, int numLayers, int sizeLayer,float *dMcoefr,float *dMcoefi,float *dSolR,float *dSolI, int num){
	static int sizeCoeff;
	static dim3 createIntegralGrid;
	static dim3 createIntegralBlock;
	int *lHostVector, *mHostVector, *nHostVector;

	static int *lDV;
	static int *mDV;
	static int *nDV;
	static int index=0;
	if(index==0){
		sizeCoeff = ((((bw-1)*(4*(bw-1)*(bw-1)-1)/3+(bw-1)*(bw-1))/2)+(bw-1)*(2*(bw-1)+1))+(bw-1)+(bw-1)+1;
		createIntegralGrid.x = sizeCoeff/32+1;
		createIntegralGrid.y = num/32+1;
		createIntegralGrid.z = 1;
		createIntegralBlock.x = 32;
		createIntegralBlock.y = 16;
		createIntegralBlock.z = 1;
		lHostVector = new int[sizeCoeff];
		mHostVector = new int[sizeCoeff];
		nHostVector = new int[sizeCoeff];
		int indexProt=0;
		for(int l=0;l<bw;l++){
			for(int m=0;m<=l;m++){
				for(int n=-l;n<=l;n++){
					lHostVector[index]=l;
					mHostVector[index]=indexProt;
					nHostVector[index]=n;
					index++;
				}
				indexProt++;
			}
		}

		cudaMalloc(&lDV,sizeof(int)*sizeCoeff);
		cudaMalloc(&mDV,sizeof(int)*sizeCoeff);
		cudaMalloc(&nDV,sizeof(int)*sizeCoeff);
		cudaMemcpyAsync(lDV,lHostVector,sizeof(int)*sizeCoeff,cudaMemcpyHostToDevice);
		cudaMemcpyAsync(mDV,mHostVector,sizeof(int)*sizeCoeff,cudaMemcpyHostToDevice);
		cudaMemcpyAsync(nDV,nHostVector,sizeof(int)*sizeCoeff,cudaMemcpyHostToDevice);
		cudaFuncSetCacheConfig(createIntegralDrugK,cudaFuncCachePreferShared);
	}
	createIntegralDrugK<<<createIntegralGrid,createIntegralBlock>>>(dCoeffr,dCoeffi,bw,num_atoms,grid_weight, numLayers, sizeLayer,dMcoefr, dMcoefi,dSolR,dSolI,lDV,mDV,nDV, sizeCoeff,num);
}

void fourierCorrCUDA(int bw, float* dCoeffr, float* dCoeffi, float* dDdd, float* dCoefCorr, int num){
	static dim3 corrGrid;
	static dim3 corrBlock;
	static bool init = true;
	if(init){
		init = false;
		corrGrid.x = num/32+1;
		corrGrid.y = 2*bw-1;
		corrGrid.z = bw;
		corrBlock.x = 32;
		corrBlock.y = 16;
		corrBlock.z = 1;
		cudaFuncSetCacheConfig(fourierCorrK,cudaFuncCachePreferL1);
	}
	fourierCorrK<<<corrGrid,corrBlock>>>(bw,dCoeffr,dCoeffi,dDdd,dCoefCorr);
}

void ligToGPU(PreSH *preSH_data, int bw, float *dSolR, float *dSolI){
	static bool init=true;
	static float *hSolR=0;
	static float *hSolI=0;
	static float *hFDown=0;
	static float *hFUp=0;
	static float *hLi=0;
	static int *hRhoDownIndex=0;
	static int *hRhoUpIndex=0;
	
	if(init){
		init = false;
		cudaMallocHost(&hSolR,sizeof(float)*bw*bw*MAX_LIGAND_ATOMS);
		cudaMallocHost(&hSolI,sizeof(float)*bw*bw*MAX_LIGAND_ATOMS);
		cudaMallocHost(&hRhoDownIndex,MAX_LIGAND_ATOMS*sizeof(int));
		cudaMallocHost(&hRhoUpIndex,MAX_LIGAND_ATOMS*sizeof(int));
		cudaMallocHost(&hFDown,MAX_LIGAND_ATOMS*sizeof(float));
		cudaMallocHost(&hFUp,MAX_LIGAND_ATOMS*sizeof(float));
		cudaMallocHost(&hLi,MAX_LIGAND_ATOMS*sizeof(float));
	}
	
	for(int i=0;i<preSH_data->num_atoms;i++){
		for(int y=0;y<bw;y++){
			for(int x=0;x<=y;x++){
				hSolR[i*bw*bw + y*bw + x] = preSH_data->sol_r[i][y-x][x];
			}
		}
	}
	cudaMemcpyAsync(dSolR,hSolR,sizeof(float)*bw*bw*preSH_data->num_atoms,cudaMemcpyHostToDevice);
	
	for(int i=0;i<preSH_data->num_atoms;i++){
		for(int y=0;y<bw;y++){
			for(int x=0;x<=y;x++){
				hSolI[i*bw*bw + y*bw + x] = preSH_data->sol_i[i][y-x][x];
			}
		}
	}
	cudaMemcpyAsync(dSolI,hSolI,sizeof(float)*bw*bw*preSH_data->num_atoms,cudaMemcpyHostToDevice);
	
	memcpy(hRhoDownIndex,preSH_data->rho_down_index,preSH_data->num_atoms*sizeof(int));
	cudaMemcpyToSymbolAsync(dRhoDownIndex,hRhoDownIndex,preSH_data->num_atoms*sizeof(int));
	
	memcpy(hRhoUpIndex,preSH_data->rho_up_index,preSH_data->num_atoms*sizeof(int));
	cudaMemcpyToSymbolAsync(dRhoUpIndex,hRhoUpIndex,preSH_data->num_atoms*sizeof(int));
	
	memcpy(hFDown,preSH_data->fdown,preSH_data->num_atoms*sizeof(float));
	cudaMemcpyToSymbolAsync(dFDown,hFDown,preSH_data->num_atoms*sizeof(float));
	
	memcpy(hFUp,preSH_data->fup,preSH_data->num_atoms*sizeof(float));
	cudaMemcpyToSymbolAsync(dFUp,hFUp,preSH_data->num_atoms*sizeof(float));
	
	memcpy(hLi,preSH_data->li,preSH_data->num_atoms*sizeof(float));
	cudaMemcpyToSymbolAsync(dLi,hLi,preSH_data->num_atoms*sizeof(float));
}