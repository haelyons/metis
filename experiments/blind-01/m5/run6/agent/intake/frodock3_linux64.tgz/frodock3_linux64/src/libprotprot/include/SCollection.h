#ifndef SCOLLECTION_H_
#define SCOLLECTION_H_

#include "libpdb/include/CommonTypes.h"
#include "libvolume/include/floatops.h"
#include "libpdb/include/Macromolecule.h"
#
/**
 * Class to store the set of solutions in a protein-protein docking
 */
class SCollection {
public:
	/// Termporal buffer for solutions in a possition
	float * solutions_in_point[4]; //Buffer de almacenamiento de las mejores rotaciones en un punto
	///Auxiliar buffer containing rotational matrix
    float ***matrix;
	///solution Buffer. It stores the correlation , movement, rotation and evaluation
	float * best_solutions_found[7]; //Almacenamiento de las mejores correlaciones junto a los angulos y desplazamientos que las han producido
	///Number of solutions in temporal buffer
	int n_point;
	///Number of solutions in solution buffer
	int n_solutions;
	///Rotational cutoff
	float rcut;
	///Traslational cutoff
	float tcut;
	/// Grade of the spherical harmonic base
	int bw;
	///Voxsize used in the creation of the solutions
	float voxsize;
	///original center of the receptor protein. Reference center
	float origin[3];
	// original center of the ligand
	float Lorigin[3];
	///Auxiliar
	int totalPeaks;

	/**
	 * Constructor
	 *@param in_point: Number of solutions in temporal buffer
	 *@param in_total: Number of solutions in solution buffer
	 *@param in_rcut: rotational cutoff
	 *@param in_rcut: traslational cutoff
	 *@param in_bw: Grade of the spherical harmonic base
	 */
	SCollection(int in_point, int in_total, float in_rcut, float in_tcut,int in_bw, float in_voxsize, vlPoint3f in_origin);
	///Destructor
	~SCollection();

	/**
	 * Insertion of solutions in a point in a limited list
	 *@param correlation: auxiliar buffer
	 *@param point: Position of the ligand
	 */
	bool insert(float * correlation, Tcoor point);


	/**
	 * Insertion of solutions in a point in a unlimited
	 *@param correlation: auxiliar buffer
	 *@param point: Position of the ligand
	 *@param threshold: Low limiting correlation value admitted
	 */
	bool insert_all(float * correlation,Tcoor point, float threshold);

	//bool insert_all2(float * sp[],Tcoor point, int npeaks_found, float threshold);
	  bool insert_all2(float * sp[],Tcoor point, int npeaks_found, float threshold);
	/**
	 * Presentation of the solutions
	 * USELESS
	 */
	void show_solutions(int option,Macromolecule * ligand=NULL,char *in_ref=NULL);
	/**
	 * write the solutions in a file
	 *@param output: name of the output file
	 *@param append: writes a new file (false) or appends at the end of a new one (true)
	 */
	void write_solutions(char *output, bool append=false);
	void write_solutions_buffer(float **output);
	void write_solutions_frodrug(int prnumber, float *output);
	void clear_solutions();
	//void write(char *name);
	//void read(char *name);

	void convert_solutions(float *position);

#ifdef MPI_RELEASE
/**
 * MPI function. It sends the set of solution to thread 1
 * @param id_r: thread identifier
 */
void send_mpi(int id_r );
/**
 * MPI function. Used by thread 1 it receives the set of solution a given thread
 * @param id_r: thread sender identifier
 */
void recv_mpi(int id_s);
/**
 * Introduces new solutions in the solution buffer
 * @param buffer: Set of new solutions
 * @param count: number of new solutions
 */
void insert_solutions(float *buffer,int count);
#endif
};

#endif /*SCOLLECTION_H_*/
