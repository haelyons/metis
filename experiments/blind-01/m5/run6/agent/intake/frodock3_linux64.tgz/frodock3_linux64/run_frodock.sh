#!/bin/bash
#
# FRODOCK 3.0 RUN SCRIPT (December 8th, 2018)
# ----------------------------------
#
#
#
pre="../bin/"  # path to frodock binaries 
mympi="mpirun" 

comp="_gcc"  # COMPILER: for GNU 
#comp=""      # COMPILER: Intel

#    By default, the "mpirun" command is taken from PATH.
#    Note this "mpirun" command must match compiler choice and your 
#    system configuration. Typical "mpirun" locations are:
#       mympi="/usr/bin/mpirun.openmpi"
#       mympi="/usr/local/bin/mpirun" # My "mpirun" command for Intel
#       mympi="/etc/alternatives/mpirun" # My "mpirun" command for GNU
#       mympi="/usr/local/openmpi/bin/mpirun"
#       mympi="/opt/intel/composer_xe_2013.1.117/mpirt/bin/intel64/mpirun"

echo "Receptor file: $1"
echo "Ligand PDB file: $2"

fullfilename=$1
filename=$(basename "$fullfilename")
receptor="${filename%.*}"     # Receptor ID without .pdb extension

fullfilename=$2
filename=$(basename "$fullfilename")
ligand="${filename%.*}" # Ligand ID without .pdb extension

np=$3           # Number of processors (only for MPI test)

echo "Receptor file: $receptor"
echo "Ligand PDB file: $ligand"

if [ $np -ge 2 ]; then
mpi="_mpi"      # MPI: "" without MPI or "_mpi" with MPI
echo "Using mpi version with $np processors ($mympi command)"
else 
mpi="_mpi" # Without OpenMPI (sequential)
echo "Using single processor version"
fi

echo "PATH= $pre is the path to frodock binaries & data files"
echo "COMPILER= $comp -> \"_gcc\" for GNU or nothing for Intel"


# PLEASE, DO NOT TOUCH ANYTHING BELOW THIS LINE...
# ------------------------------------------------------------------------


suff=$mpi$comp
suff2=$comp

if [ "$mpi" = "_mpi" ]
then
 run="$mympi -np $np"
 echo RUNNING MPI TESTS
else
 run=""
 echo RUNNING NON-MPI TESTS
fi

 echo STAGE-1 Creation of receptor vdw potential map
 echo -e $run $pre'frodockgrid'$suff $receptor.pdb -o $receptor'_W'.mrc
 $run $pre'frodockgrid'$suff $receptor.pdb -o $receptor'_W'.mrc

 echo STAGE-2 Creation of the receptor electrostatic potential map
 echo -e $run $pre'frodockgrid'$suff $receptor.pdb -o $receptor'_E'.mrc -m 1 -t A
 $run $pre'frodockgrid'$suff $receptor.pdb -o $receptor'_E'.mrc -m 1 -t A

 echo STAGE-3 Creation of the receptor desolvation potential map
 echo -e  $run $pre'frodockgrid'$suff $receptor.pdb -o $receptor'_DS'.mrc -m 3
 $run $pre'frodockgrid'$suff $receptor.pdb -o $receptor'_DS'.mrc -m 3

 echo STAGE-4 Creation of the ligand desolvation potential map
 echo -e $run $pre'frodockgrid'$suff $ligand.pdb -o $ligand'_DS'.mrc -m 3
 $run $pre'frodockgrid'$suff $ligand.pdb -o $ligand'_DS'.mrc -m 3

 echo STAGE-5 Performing the docking
 echo -e $run $pre'frodock'$suff $receptor'_ASA'.pdb $ligand'_ASA'.pdb -w $receptor'_W'.mrc -e $receptor'_E'.mrc --th 10 -d $receptor'_DS'.mrc,$ligand'_DS'.mrc -t A -o dock.dat
 $run $pre'frodock'$suff $receptor'_ASA'.pdb $ligand'_ASA'.pdb -w $receptor'_W'.mrc -e $receptor'_E'.mrc --th 10 -d $receptor'_DS'.mrc,$ligand'_DS'.mrc -t A -o dock.dat  -s ../bin/soap.bin 

 echo STAGE-6 Clustering and visualization of predictions
 echo -e   $pre'frodockcluster'$suff2 dock.dat $ligand.pdb --nc 100 -o clust_dock.dat
 $pre'frodockcluster'$suff2 dock.dat $ligand.pdb --nc 100 -o clust_dock.dat

 echo STAGE-7 Visualize the first 20 solutions
 echo -e $pre'frodockview'$suff2 clust_dock.dat -r 1-20 
 $pre'frodockview'$suff2 clust_dock.dat -r 1-20 

 echo STAGE-8 Coordinate generation of the 10 best predicted solutions
 echo -e $pre'frodockview'$suff2 clust_dock.dat -r 1-10 -p $ligand.pdb 
 $pre'frodockview'$suff2 clust_dock.dat -r 1-10 -p $ligand.pdb 
 
 echo 
 echo -e "RUN FINISHED"
 echo 


