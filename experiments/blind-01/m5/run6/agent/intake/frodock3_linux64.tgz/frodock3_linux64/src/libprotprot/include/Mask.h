#ifndef MASK_H_
#define MASK_H_

#include "EVolumes.h"
#include "PCollection.h"
#include <libvolume/include/floatops.h>
#include <libfrm/include/Correlation.h>
#include <libpdb/include/Macromolecule.h>

/**
 * This class determines the points to translate a ligand
 * in a protein-protein docking around a receptor
 */
class Mask{

	public:
		///volume mask
		vlVolume *msk;
		///volume dimension padding
		int mask_offset[3];
		///Proportion of mask voxel size compared to that of the original maps
		float increase_voxel;
		///Maximum distance of the mask from the center
		float limitMax;
		///Center of the mask
		float cx_lo_aux,cy_lo_aux,cz_lo_aux;

	public:
		/**
		 * Constructor
		 *@param ligand: Ligand that will be traslated to the positions in the mask
		 *@param radiusMax_lig_amstrongs: maximum radius of the ligand in amstrongs
		 *@param bw: grade of spherical harmonics base
		 *@param evol: object that contains maps with the projected properties of the receptor
		 *@param limitMinMask: factor to reduce the inner limit of the mask
		 *@param limitMaxMask: factor to reduce the outer limit of the mask
		 */
		Mask(Macromolecule *ligand, float radiusMax_lig_amstrongs, int bw, EVolumes *evol,float limitMinMask,float limitMaxMask);
		/**
		 * Destructor
		 */
		~Mask();
		/**
		 * Returns a collection of positions to move the receptor (in amstrongs)
		 *@param stepsize_voxel: Search stepsize in voxels
		 *@param c_lo_voxel: center of the mask
		 */
		PCollection* find_points(float stepsize_voxel, float *c_lo_voxel);
		/**
		 * Clears an spheric area around a point in the mask
		 * @param pos: center position
		 * @param radius: radius of the area
		 */
		void around(float *pos, float radius);
};

#endif /*MASK_H_*/
