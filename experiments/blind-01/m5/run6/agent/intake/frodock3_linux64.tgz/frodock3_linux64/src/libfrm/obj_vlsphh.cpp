/***************************************************************************
                          vlFrm.cpp  -  description
                             -------------------
    begin                : Fri Oct 1 2004
    copyright            : (C) 2004 by Jose Ignacio Garzon
    email                : -D VOLUME_INCLUDED
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/


#include <stdlib.h>

#include <math.h>
#include <string.h>
#include "obj_vlsphh.h"


//***********Coeficientes d***********************
vlDCoef::vlDCoef(){
}

vlDCoef::vlDCoef(int bw2, float theta)
{

  ddd=(float*)malloc( (bw2*(4*bw2*bw2-1)/3) *sizeof(float));

  //ddd=(float*)malloc( ( ( (bw2*(4*bw2*bw2-1)/3) +(bw2*bw2) )/2  )*sizeof(float) );
  //ddds=(float*)malloc(sizeof(float)*((bw2*bw2)-1));

  if(ddd==NULL)
  {
    fprintf(stderr,"vldVoef ERROR> Memory allocation not possible 1\n");
    return;
  }

  float p, q, pc, qc, temp, *d, *dd;
  int size, index, i, j2, k, l, hdeg;
  unsigned long init;
  float fact1, fact2, fact3, fact4;

  bw=bw2;
  size=2*bw;

  d  = (float *) malloc(size*size*sizeof(float));
  dd = (float *) malloc(size*size*sizeof(float));

  if( (d == NULL) || (dd == NULL) ){
    fprintf(stderr,"vldVoef ERROR> Memory allocation not possible\n");
    return;
  }

  p=sin(theta/2.0); q=cos(theta/2.0);   /* Cayley-Klein parameters */
  pc=p; qc=q;

  *(ddd+0)=1.0;                     /* d-matrix of degree 0 */

  /* d-matrix of degree 1/2 */
  *(d+0)=q;
  *(d+1)=p;
  *(d+1*size+0)=-pc;
  *(d+1*size+1)=qc;

  for(l=1;l<bw;l++){       /* l is the degree of the next d-matrix to be saved in ddd */
    j2=(l<<1)-1;           /* j2 will be twice the degree of the d-matrix about to be computed */
    for(hdeg=0;hdeg<2;hdeg++){
      fact1=q/ ++j2;
      fact2=pc/j2;
      fact3=p/j2;
      fact4=qc/j2;
      for(i=0;i<=j2+1;i++)
        for(k=0;k<=j2+1;k++)
          *(dd+i*size+k)=0.0;
      for(i=0;i<j2;i++)
        for(k=0;k<j2;k++){
          index=i*size+k;
          temp=*(d+index);
          *(dd+index)        += sqrt((float)((j2-i)*(j2-k)))*temp*fact1;
          *(dd+index+size)   += -sqrt((float)((i+1)*(j2-k)))*temp*fact2;
          *(dd+index+1)      += sqrt((float)((j2-i)*(k+1))) *temp*fact3;
          *(dd+index+size+1) += sqrt((float)((i+1) *(k+1))) *temp*fact4;
        }

      for(i=0;i<=j2;i++)        /* move dd to d */
        for(k=0;k<=j2;k++)
          *(d+i*size+k)=*(dd+i*size+k);

      if(hdeg==0){              /* if degree is integer, copy d to the proper location in ddd */
        init=l*(4*l*l-1)/3;
        //init=( (l*(4*l*l-1)/3) +(l*l) )/2
        //init2=(l*l)-1;
        for(i=l;i<=j2;i++)
          for(k=0;k<=j2;k++)
           *(ddd+init+i*(j2+1)+k) = *(d+i*size+k);
          //for(k=0;k<=j2;k++)
          //*(ddd+init+i*(l+1)+k) = *(d+i*size+k);

      }


      if(l==bw-1) break;     /* for l=bw-1 do hdeg=0 only */
    }
  }
  free(d); free(dd);
  for(i=0;i<(bw2*(4*bw2*bw2-1)/3);i++)
    if(*(ddd+i)<0.00001 && *(ddd+i)>-0.00001)
     *(ddd+i)=0.0;


}


vlDCoef::~vlDCoef(){
  free(ddd);
}

/*float inline vlDCoef::get(unsigned long index)
{
  return ddd[index];
}*/

float vlDCoef::get(int l,int m,int n)
{
 int j2;
 unsigned long init;
 int m2,n2;

 j2= (l<<1);
 init=l*(4*l*l-1)/3;

 m2=m+(l);
 n2=n+(l);
 return *(ddd+init+m2*(j2+1)+n2);
}

bool vlDCoef::writef(char *out)
{
  FILE *f;

  f=fopen(out,"wb");
  if(f==NULL)
    return false;

  fwrite(&bw,sizeof(int),1,f);
  fwrite(ddd,sizeof(float),bw*(4*bw*bw-1)/3,f);

  fclose(f);
}

bool vlDCoef::readf(char *in)
{
  FILE *f;

  f=fopen(in,"rt");
  if(f==NULL)
    return false;
  if(fread(&bw,sizeof(int),1,f)==NULL)
    return false;

  ddd=(float*)malloc( (bw*(4*bw*bw-1)/3) *sizeof(float));

  if(fread(ddd,sizeof(float),bw*(4*bw*bw-1)/3,f)==NULL)
  {
    free(ddd);
    return false;
  }

  fclose(f);

}


//***********Coeficientes d0***********************
vlLegendre::vlLegendre()
{}

vlLegendre::vlLegendre(int bwp, int bxp)
{
  /* computes the d-functions d^l_{n,0}(theta_j),
     for l=0,...,bw-1; abs(n)<=l; j=0,...,2*bx.
     theta_j is defined by: cos(theta_j)=j/bx-1 */
  /* they are returned in the (3D) prism array dd0 */
  /* Reference: T. Risbo, Journal of Geodesy (1996) 70:383-396 */

  bw=bwp;
  bx=bxp;
  tlb=(int)(log((float)bw)/log((float)2.0))*2;

  float p, q, pc, qc, theta, temp, *d;
  int size, index, i, j, l, l2;
  unsigned long init1, init2, bw2;
  float fact1, fact2;

  size=2*bw; bw2=bw*bw;
  dd0=(float*)malloc((2*bx+1)*bw*bw*sizeof(float));
  d = (float *) malloc(3*size*sizeof(float));

  //memset(dd0,0,(2*bx+1)*bw*bw*sizeof(float));

  if( d == NULL ){
    perror("Error in allocating memory");
    exit(1);
  }

  for(j=0;j<=2*bx;j++){                 /* loop over argument theta */
    init1=j*bw2;
    theta=acos(((float) j)/bx-1.0);
    p=sin(theta/2.); q=cos(theta/2.);   /* Cayley-Klein parameters */
    pc=p; qc=q;

    *(dd0+init1)=1.0;                   /* d^0_{0,0}(theta) */

    /* d-functions of degree 1 */
    *(d+0  +1) =  SQRT2*q*p;
    *(d+1*3+1) = -p*pc+q*qc;
    *(d+2*3+1) = -SQRT2*pc*qc;

    /* copy the d^1 to the proper location in dd0 */
    *(dd0+init1+1) = *(d+1);
    *(dd0+init1+2) = *(d+4);
    *(dd0+init1+3) = *(d+7);

    for(l=2;l<bw;l++){                /* l = degree of d-functions to be computed next */
      l2=(l<<1);
      for(i=0;i<l2;i++){
        *(d+i*3+0)=0.0;
        *(d+i*3+2)=0.0;
      }
      for(i=0;i<l2-1;i++){            /* balanced Edmonds scheme */
        index=i*3;
        temp=*(d+index+1);
        fact1=sqrt((l2-1-i)/(float)l)*temp;
        fact2=sqrt((i+1)   /(float)l)*temp;
        *(d+index  ) +=  fact1*q;
        *(d+index+3) += -fact2*pc;
        *(d+index+2) +=  fact1*p;
        *(d+index+5) +=  fact2*qc;
      }
      for(i=0;i<=l2;i++)
        *(d+i*3+1)=0.0;
      for(i=0;i<l2;i++){             /* binomial recursion */
        index=i*3;
        fact1=sqrt((float)((l2-i)*l))/l2;
        fact2=sqrt((float)((i+1) *l))/l2;
        *(d+index+1) +=  fact1* *(d+index+2)*q;
        *(d+index+4) += -fact2* *(d+index+2)*pc;
        *(d+index+1) +=  fact1* *(d+index  )*p;
        *(d+index+4) +=  fact2* *(d+index  )*qc;
      }
      init2=l*l+init1;
      for(i=0;i<=l2;i++)           /* copy d to the proper location in dd0 */
        *(dd0+init2+i) = *(d+i*3+1);
    }
  }
  free(d);

}

vlLegendre::~vlLegendre()
{
free(dd0);
}









//***********Coeficientes esfericos***********************
vlSpherical::vlSpherical(int bw2,int r)
{
  bw=bw2;
  int size2= 4*bw*bw;
  size=2*bw;
  gr=r;
  is_complex=false;

  m=(Sphfloat**) malloc(r*sizeof(Sphfloat*));

  for(int i=0;i<r;i++)
  { m[i]=(Sphfloat*)malloc(size2*sizeof(Sphfloat));
    memset(m[i],0,size2*sizeof(Sphfloat));
  }

}


vlSpherical::~vlSpherical()
{
  for(int i=0;i<gr;i++)
    free(m[i]);

  free(m);

}

void vlSpherical::reset_vlSpherical(int bw2,int r)
{

  bw=bw2;
  int size2= 4*bw*bw;
  size=2*bw;

  for(int i=0;i<gr;i++)
    free(m[i]);
  free(m);


   gr=r;

   m=(Sphfloat**) malloc(r*sizeof(Sphfloat*));

   for(int i=0;i<r;i++)
   { m[i]=(Sphfloat*)malloc(size2*sizeof(Sphfloat));
     memset(m[i],0,size2*sizeof(Sphfloat));
   }

/*for(int i=0;i<size*size;i++)
{
*(idata+i)=0;
}*/



}



void vlSpherical::free_preComputation()
{
  if(!is_complex)
  {
  	free(idata[0]);

  }
  else
  {
  	for(int i=0;i<gr;i++)
  	{
    	free(idata[i]);
  	}
  }
  free(idata);
  free(workspace);
  free(tablespace);
  free(table);
  free(weights);
  fftwf_destroy_plan(dctPlan);
  fftwf_destroy_plan(fftPlan);
}



void vlSpherical::clear()
{
  int size2= 4*bw*bw;

  for(int i=0;i<gr;i++)
  {
    memset(m[i],0,size2*sizeof(Sphfloat));
  }

  if(!is_complex)
  {
  	memset(idata[0],0,size2*sizeof(Sphfloat));
  }
  else
  {
  	for(int i=0;i<gr;i++)
  	{
    	memset(idata[i],0,size2*sizeof(Sphfloat));
  	}
  }

}





void vlSpherical::preComputation(bool isComplex)
{
	is_complex=isComplex;

	if(!is_complex)
	{
  	idata=(Sphfloat**) malloc(sizeof(Sphfloat*) * 1);
  	idata[0]=(Sphfloat*) malloc(sizeof(Sphfloat) * (size*size));

  	for(int i=0;i<size*size;i++)
  	{
    	idata[0][i]=0;
  	}
	}
	else
	{
		idata=(Sphfloat**) malloc(sizeof(Sphfloat*) * gr);
  	for(int i=0;i<gr;i++)
  	{
  		idata[i]=(Sphfloat*) malloc(sizeof(Sphfloat) * (size*size));
			memset(idata[0],0,size*size*sizeof(Sphfloat));
		}
	}

  tablespace= (Sphfloat*) malloc(sizeof(Sphfloat)*
                          (Reduced_Naive_TableSize(bw,bw)+
                          Reduced_SpharmonicTableSize(bw,bw)));

  workspace= (Sphfloat*)malloc(sizeof(Sphfloat)* ((8 * (bw*bw)) + (16*bw)));

  weights= (Sphfloat*) malloc(sizeof(Sphfloat) * 4 * bw);

  if((idata==NULL) || (tablespace==NULL) || (workspace==NULL) || (weights==NULL))
  {
	  fprintf(stderr,"vlSpherical> Error: Memory allocation not possible\n");
    exit(1);
  }

  dims[0].n=2*bw;
  dims[0].is=1;
  dims[0].os=2*bw;
  howmany_dims[0].n=2*bw;
  howmany_dims[0].is=2*bw;
  howmany_dims[0].os=1;

  makeweights(bw,weights);

  table= SemiNaive_Naive_Pml_Table(bw,bw,tablespace,workspace);

  dctPlan=fftwf_plan_r2r_1d(2*bw,weights,m[1],FFTW_REDFT10,FFTW_ESTIMATE);

	fftPlan=fftwf_plan_guru_split_dft(1,dims,1,howmany_dims,NULL,NULL,workspace,
          workspace+(4*bw*bw), FFTW_ESTIMATE);

}


