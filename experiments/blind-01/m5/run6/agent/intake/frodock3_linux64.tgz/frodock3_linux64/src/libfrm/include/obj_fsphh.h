/***************************************************************************
                          fsphh.h  -  description
                             -------------------
    begin                : Thu Dec 2 2004
    copyright            : (C) 2004 by Jose Ignacio Garzon
    email                :
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
#ifndef _fsphh_hpp
#define _fsphh_hpp


#ifdef PDB_INCLUDED
#include <libpdb/include/Macromolecule.h>
#endif

#ifdef VOLUME_INCLUDED
#include <libvolume/include/vlvoliter_linear.h>
#endif


#include "obj_vlsphh.h"

#ifdef VOLUME_INCLUDED
namespace FOPS
{
  /**
  * Interpolates a volume in a spherical representation. The spherical
  * representation has the center in a given point
  * It is the fast version of the algorithm. It does not compute radius information
  *
  * @param vol: Volume to interpolate
  * @param rmax: Maximum Layer obtained in the spherical representation
  * @param bw: Bandwidth of the spherical representation
  * @param maxext: Maximum number of layers allowed
  * @param cx,cy,cz: Center of the spherical representation
  * @param sph2: Shperical object that stores the representation. If NULL the method creates a new object
  * @param rho: Distance between layers
  */
  vlSpherical *volumetric_sampling_fast(vlVolume *vol, int *rmax, int bw, int maxext,float cx,
                                    float cy,float cz,float rho,vlSpherical *sph2=NULL);

  /**
  * Interpolates a volume in a spherical representation. The spherical
  * representation has the center in a given point
  * It is the fast version of the algorithm. It does not compute radius information.
  * It employs precomputed coefficents to speed up the computation
  *
  * @param vol: Volume to interpolate
  * @param rmax: Maximum Layer obtained in the spherical representation
  * @param bw: Bandwidth of the spherical representation
  * @param maxext: Maximum number of layers allowed
  * @param cx,cy,cz: Center of the spherical representation
  * @param buf_lamda, buf_theta: Precomputed spherical coefficients.
  * @param sph2: Shperical object that stores the representation. If NULL the method creates a new object
  */
  vlSpherical *volumetric_sampling_fast(vlVolume *vol, int *rmax, int bw, int maxext,float cx,
                                    float cy,float cz,float* buf_lambda,float *buf_theta,vlSpherical *sph2=NULL );

  /**
  * Interpolates a volume in a spherical representation. The spherical
  * representation has the center in a given point
  * It is the slow version of the algorithm. It computes radius information about
  * the external maximum/minimum radius, the internal maximum/minimum radius and
  * maximum/minimum zero readius.
  *
  * @param vol: Volume to interpolate
  * @param in: external radius. Maximum and minimum radius of the external surface
  * @param out: external radius. Maximum and minimum radius of the internal surface (Has sense when the representation has a hole in the center. In other case both are 0)
  * @param zero: Maximum and minimum radius from center to position in the representation with 0 value
  * @param rmax: Maximum Layer obtained in the spherical representation
  * @param bw: Bandwidth of the spherical representation
  * @param maxext: Maximum number of layers allowed
  * @param cx,cy,cz: Center of the spherical representation
  * @param buf_lamda, buf_theta: Precomputed spherical coefficients.
  * @param sph2: Shperical object that stores the representation. If NULL the method creates a new object
  * @param rho: Distance between layers
  */
  vlSpherical *volumetric_sampling_slow(vlVolume *vol, int in[],int out[], int zero[], int bw, int maxext,float cx,
                                  float cy,float cz,float rho,vlSpherical *sph2=NULL);


  void volumetric_sampling_slow_Dim(vlVolume *vol, int in[],int out[], int zero[], int bw, int maxext,float cx,
                                float cy,float cz,float rho);


  /**
  * Interpolates a volume in a spherical representation. The spherical
  * representation has the center in a given point
  * It is the slow version of the algorithm. It computes radius information about
  * the external maximum/minimum radius, the internal maximum/minimum radius and
  * maximum/minimum zero readius.
  * It employs precomputed coefficents to speed up the computation
  *
  * @param vol: Volume to interpolate
  * @param in: external radius. Maximum and minimum radius of the external surface
  * @param out: external radius. Maximum and minimum radius of the internal surface (Has sense when the representation has a hole in the center. In other case both are 0)
  * @param zero: Maximum and minimum radius from center to position in the representation with 0 value
  * @param rmax: Maximum Layer obtained in the spherical representation
  * @param bw: Bandwidth of the spherical representation
  * @param maxext: Maximum number of layers allowed
  * @param cx,cy,cz: Center of the spherical representation
  * @param buf_lamda, buf_theta: Precomputed spherical coefficients.
  * @param sph2: Shperical object that stores the representation. If NULL the method creates a new object
  */
  vlSpherical *volumetric_sampling_slow(vlVolume *vol, int in[],int out[], int zero[], int bw, int maxext,float cx,
                                    float cy,float cz,float* buf_lambda,float *buf_theta,vlSpherical *sph2=NULL);

  /*Funcion que interpola un volumen esferico a partir de un volumen tridimensional
  empleando como centro del volumen un punto en el espacio pasado como argumento
  Esta funcion se emplea cuando los valores lambda y theta necesarios no son conocidos
  El calculo del radio maximo esta hecho para el caso de que el mapa este pasado por un
  filtro Laplaciano
  */

  /**
  * Interpolates a volume thats has been Laplacian filtered in a spherical
  * representation. The spherical representation has the center in a given point
  * It is the fast version of the algorithm. It does not compute radius information
  *
  * @param vol: Volume to interpolate
  * @param rmax: Maximum Layer obtained in the spherical representation
  * @param bw: Bandwidth of the spherical representation
  * @param maxext: Maximum number of layers allowed
  * @param cx,cy,cz: Center of the spherical representation
  * @param sph2: Shperical object that stores the representation. If NULL the method creates a new object
  * @param rho: Distance between layers
  */
  vlSpherical *volumetric_sampling_fastL(vlVolume *vol, int *rmax, int bw, int maxext,float cx,
                                  float cy,float cz,float rho,vlSpherical *sph2);


  /**
  * Interpolates a volume thats have been previously Laplacian filtered in
  * a spherical representation. The spherical representation has the center in a given point
  * It is the fast version of the algorithm. It does not compute radius information.
  *
  * @param vol: Volume to interpolate
  * @param rmax: Maximum Layer obtained in the spherical representation
  * @param bw: Bandwidth of the spherical representation
  * @param maxext: Maximum number of layers allowed
  * @param cx,cy,cz: Center of the spherical representation
  * @param buf_lamda, buf_theta: Precomputed spherical coefficients.
  * @param sph2: Shperical object that stores the representation. If NULL the method creates a new object
  */
  vlSpherical *volumetric_sampling_fastL(vlVolume *vol, int *rmax, int bw, int maxext,float cx,
                     float cy,float cz,float* buf_lambda,float *buf_theta,vlSpherical *sph2=NULL );


}
#endif
#ifdef PDB_INCLUDED

/**
 * Interpolates a  pdb in
 * a spherical representation. The spherical representation has the center in a given point
 *
 * @param pdb: Pdb to interpolate
 * @param maxext: Maximum Layer obtained in the spherical representation
 * @param bw: Bandwidth of the spherical representation
 * @param maxext: Maximum number of layers allowed
 * @param cx,cy,cz: Center of the spherical representation
 * @param width: distance between layers
 * @param sph2: Shperical object that stores the representation. If NULL the method creates a new object
 */
vlSpherical *pdb_gauss_sampling(Macromolecule *pdb, int bw, int maxext,float cx,
                                  float cy,float cz,float width,vlSpherical *sph2=NULL);

/**
 * Interpolates a  pdb in
 * a spherical representation. The spherical representation has the center in a given point
 *
 * @param pdb: Pdb to interpolate
 * @param maxext: Maximum Layer obtained in the spherical representation
 * @param bw: Bandwidth of the spherical representation
 * @param maxext: Maximum number of layers allowed
 * @param cx,cy,cz: Center of the spherical representation
 * @param width: distance between layers
 * @param sph2: Shperical object that stores the representation. If NULL the method creates a new object
 */
vlSpherical *pdb_atom_sampling(Macromolecule *pdb, int bw, int maxext,float cx,
                                  float cy,float cz,float width,vlSpherical *sph2=NULL);

#endif
/**
* write a spherical representation as a PDB file
*
* @param name: Nmae of the file to be written
* @param sph: Sperical object
* @param bw: Bandwidth of the representation
* @param rmax: Maximum Layer of the representation
* @param width: distance between layers
* @param cx,cy,cz: Center of the representation in the real space
*/
void writeSphVol(char* name, vlSpherical *sph, int bw,int rmax,float width, float cx,float cy,float cz);

#endif
