
#include "include/EVolumes.h"

void EVolumes::read_volume(char *filename,int vol_id)
{
	vol_lo[vol_id] = FOPS::readFile( filename );
	init[vol_id]=true;

//	FOPS::mul( vol_lo[vol_id], -1.0 );
	//if(vol_id==3)
		//FOPS::mul( vol_lo[vol_id], -1.0 );
}
void EVolumes::get_volume(vlVolume *v,int vol_id)
{
	vol_lo[vol_id] = v;
	init[vol_id]=true;

}

void EVolumes::compute_center_masses()
{
	vlPoint3f ori;
	//calculo del centro de masas de los volumenes en baja y alta resolucion
  //FOPS::center_masses( vol_lo[0], &(c_lo_voxel[0]), &(c_lo_voxel[1]), &(c_lo_voxel[2]) );
	FOPS::center_vol(vol_lo[0], c_lo_voxel);
//	vol_lo[0]->getPosition( & ori );
//	c_lo_voxel[0]+=ori.x();
//	c_lo_voxel[1]+=ori.y();
//	c_lo_voxel[2]+=ori.z();

}

void EVolumes::get_position(vlPoint3f &origin_receptor)
{
	vol_lo[0]->getPosition( & origin_receptor );
}

float EVolumes::get_voxSize()
{
	return ( float )( vol_lo[0]->units().x() );
}

EVolumes::EVolumes()
{
	int i;
	for(i=0;i<NUM_POT;i++)
		init[i]=false;
}

EVolumes::~EVolumes()
{
	int i;
	for(i=0;i<NUM_POT;i++)
	{
		if(init[i])
			delete vol_lo[i];
	}
}

float EVolumes::getMaxRadius()
{
	int radiusMax_vol_voxel = ( int )ceil( sqrt( ( double )( vol_lo[0]->dim().x() * vol_lo[0]->dim().x() + vol_lo[0]->dim().y()
       * vol_lo[0]->dim().y() + vol_lo[0]->dim().z() * vol_lo[0]->dim().z() ) ) / 2.0 );
  return (radiusMax_vol_voxel * get_voxSize());
}
