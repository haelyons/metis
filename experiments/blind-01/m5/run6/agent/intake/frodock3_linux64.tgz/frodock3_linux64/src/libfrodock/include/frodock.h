#ifndef _FRODOCK_hpp
 #define _FRODOCK_hpp

#include <string.h>


#include "libprotprot/include/Mask.h"
#include "libprotprot/include/SH_Object.h"
#include "libprotprot/include/Auxiliar.h"
#include "libprotprot/include/SCollection.h"


#define NAMESIZE 300

struct Potential_FI{
	char name [NAMESIZE]; 		//filename of the receptor potential
	float weight;				//Multiplication factor for the correlation obtained with the potential
	int type;					//Potential type
};


struct FrodockInput{
	//PDB FILES. MANDATORY
	char receptor [NAMESIZE]; 	//Filename with the receptor PDB structure
	char ligand [NAMESIZE]; 	//Filename with the ligand PDB structure

	//MAIN POTENTIALS. OPTIONALS
	int in_type;                // type of interaction 0-E, 1->A 2->O -1 general
	// Van der Waals potential
	char vdw [NAMESIZE]; 		//Filename with the receptor Van der Waals potential
	float vdw_weight; 			//Multiplication factor for the correlation obtained with the vdw potential (default 1.0)
	//Electrostatic potentials

	float tobi_weight; 			//Multiplication factor for the correlation obtained with the vdw potential (default 1.0)
	//Electrostatic potentials

	float soap_weight; 			//Multiplication factor for the correlation obtained with the vdw potential (default 1.0)
	//Electrostatic potentials


	char ele [NAMESIZE];		//Filename with the receptor Electrostatic potential
	float ele_weight;			//Multiplication factor for the correlation obtained with the electrostatic potential (default 0.3)
	//Desolvation potential
	char desol_rec [NAMESIZE];	//Filename with the receptor desolvation potential
	char desol_lig [NAMESIZE];  //Filename with the ligand desolvation potential
	char asa_rec [NAMESIZE];	//Filename with the receptor asa projection
	char asa_lig [NAMESIZE];	//Filename with the ligand asa projection
	float desol_weight;			//Multiplication factor for the correlation obtained with the desolvation potential (default 0.5)

	//EXTRA POTENTIALS. OPTIONALS
	//Up to 50 potentials can be added
	int num_pot; 				//Number of extra potentials
	Potential_FI *potentials;		//entries for each potential (each one stores the filename of the receptor potential and Multiplication factor)

	//SEARCH PARAMETERS
	int bw;						//Bandwitdh in spherical harmonic representation. Define rotational stepsize (default: 32. Rotational stepsize ~11º)
	float lmax;					//External Mask reduction ratio (default: 0.25).
	float lmin;			      	//Internal Mask reduction ratio (default: 0.26).
	float th;	      			//Electrostatic map threshold (default: 10.0)
	float lw;		      		//Width between spherical layers in amstrongs (default: 1.0).
	float st;			      	//Translational search stepsize in amstrongs (default: 2.0).
	int np;				      	//Number of solutions stored per translational position. (default: 4)
	float rd;				   	//Minimal rotational distance allowed between close solutions in degrees (default: 12.0)
	int nt;	      				//Number of solutions stored in the search (default: unlimited -1).
	float td;	      			//Maximal translational distance to consider close solutions in grid units. (default: 0)

	bool use_around;			//Limit the translational search to a region (default: false)
	bool maskf;                 // save search space
	float around_point[3];		//Coordinates of the central point of the region

	char points[NAMESIZE];		//File with points to explore
	char soap[NAMESIZE];		// SOAP-potential file (soap.txt)

	Convention conv; 			//Forcefield convention
	ConventionNames nameconv;   // Name convention....

}; //Global input structure


//DEFAULT VALUES
void default_frodock_input ();


SCollection* frodock_function(int *flag, char *message, bool verbose,int id, int numprocs, int type);
//SCollection* frodock_function(int *flag, char *message, bool verbose,int id, int numprocs);

#endif
