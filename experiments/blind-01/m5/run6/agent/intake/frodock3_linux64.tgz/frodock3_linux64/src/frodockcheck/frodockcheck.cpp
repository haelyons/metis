#include <stdio.h>
#include <iostream>
#include <sstream>
#include <string>

#include <cmdl/CmdLine.h>
#include "libpdb/include/Macromolecule.h"
#include "libpdb/include/pdbIter.h"
#include "libtools/include/timer.h"

using namespace TCLAP;
using namespace std;

char in_r1[256],in_r2[256],in_l1[256],in_l2[256],in_data[256],in_dataK[256], in_multiple[256],in_output[256];
bool in_mult=true;
bool in_number,in_fnat,in_sfnat,in_pdb, in_old;
int in_points;
int in_only;
void parseOptions(int argc, char** argv);

inline vector<string> split(const string& str, const string& delim)
																								{
	vector<string> tokens;
	size_t prev = 0, pos = 0;
	do
	{
		pos = str.find(delim, prev);
		if (pos == string::npos) pos = str.length();
		string token = str.substr(prev, pos-prev);
		if (!token.empty()) tokens.push_back(token);
		prev = pos + delim.length();
	}
	while (pos < str.length() && prev < str.length());
	return tokens;
																								}

int main(int argc, char *argv[])
{
	int ***buffer;
	int limits[6];
	int i,j,k,cont_sol,cont_real;
	float matrix4[4][4], MAXRL, MAXRR;
	float solution[7],*solution2;
	float euler[3],offset[3];
	Tcoor original_center, invert_original_center;
	int npeaksTotal,initPeak;
	FILE *f,*f2;
	float output1,output2;
	Condition *cond1,*cond2, *condF;
	Conditions *condsLU,*condsLUF,*condsLB,*condsI_LU,*condsI_LB,*condsRU,*condsRUF, *condsRB,*condsI_RU,*condsI_RB;
	M4Rot *matrix4_op, *matrix4_opR, *matrix4_opL , *matrix4_opIL,  *matrix4_opIR  ;
	int** contact_R,maxR,fnat,fnonnat;
	bool notFound;
	Macromolecule *listB[2],*listU[2];
	Htimer time_step, time_total;
	strcpy(in_multiple,"");
	int cont_clash2;

	char **interfaceC, **contact_RC;

	//CALCULO DE CHOQUES
	Tcoor pos1,pos2;
	float sum1,sum2,sum3;
	float limit=1.0*1.0;
	float dist;
	int cont_clash=0;
	float average_clash=0;
	pdbIter *iter1;
	pdbIter *iter2;
	bool check;
	Residue *res;
	bool contA;
	Atom *at;
	Element *e;
	Atom* list_atom_1[10000];
	Atom* list_atom_2[10000];
	int cont_atom_1=0,cont_atom_2=0;
	int limit_clash=0;
	float deep_clash=1;


	//Fnat selectivo
	int rmsd_limit_I=4.0;
	int rmsd_limit_L=10.0;

	init_aminoacids(Rosseta,pdb);
	parseOptions(argc,argv);

	Macromolecule *r1=new Macromolecule();
	r1->readPDB(in_r1);
	r1->delete_hydrogens();
	fprintf(stderr,"Read R bound: %s\n",in_r1);

	Macromolecule *r2=new Macromolecule();
	r2->readPDB(in_r2);
	r2->delete_hydrogens();
	fprintf(stderr,"Read R unbound: %s\n",in_r2);

	Macromolecule *l1=new Macromolecule();
	l1->readPDB(in_l1);
	l1->delete_hydrogens();
	fprintf(stderr,"Read L bound: %s\n",in_l1);

	Macromolecule *l2=new Macromolecule();
	l2->readPDB(in_l2);
	l2->delete_hydrogens();
	fprintf(stderr,"Read L unbound: %s\n",in_l2);
	Macromolecule *l2_ref= new Macromolecule(l2);

	//













	int **contact_R10, **contact_R5, **CR5U,  maxR10, maxR5;
	char **contact_R10C, **contact_R5C, **CR5UC ;
	contact_R10=r1->getInterface( l1, 10.0 ,&maxR10, &contact_R10C, false );
	contact_R5 =r1->getInterface( l1, 5.0 ,&maxR5,  &contact_R5C, false );


	//	 for(int i=0;i<maxR5;i++)
	//		fprintf(stderr,"5 %c:%d %c:%d\n",contact_R5C[0][i],contact_R5[0][i], contact_R5C[0][i], contact_R5[1][i]);

	//	 for(int i=0;i<maxR10;i++)
	//	 		fprintf(stderr,"10  %c-%c\n",contact_R10C[0][i],contact_R10C[1][i]);

	CR5U=(int**)malloc(sizeof(int*)*2);
	for(int j=0;j<2;j++)
		CR5U[j]=(int*)malloc(sizeof(int)* maxR5);

	CR5UC=(char**)malloc(sizeof(char*)*2);
	for(int j=0;j<2;j++)
		CR5UC[j]=(char*)malloc(sizeof(char)* maxR5);

	for(int j=0;j<2;j++)
		for(int i=0;i<maxR5;i++)
			CR5U[j][i]=-1;
	//	fprintf(stderr,"%d-%d\n",contact_R5[0][i],contact_R5[1][i]);


	// Receptor

	Chain *ch;
	pdbIter *iter_ch,*iter_ch2;
	int sel_Ch, sel_Ch2;
	char in_chain;
	char *ChainB,*ChainU;

	int pOs,Seg, pOsB, pOsU;
	char string1[10], string2[10], string3[2];

	float distP, dumpf1, dumpf2,dumpf3;
	vector<string> chopping,chopping2;
	const char *tempC;
	char line[70];
	int dumpI;
	float center[3];




	// RECEPTORS BOUND AND UNBOUND
	// f=fopen("KPAX/1AHW_r_ub.kpairs","rt");


	sprintf( in_dataK, "%s_r_ub.kpairs",in_data);
	fprintf(stderr, " Open file '%s'\n", in_dataK);

	f=fopen(in_dataK,"rt");
	if ( f==NULL) {
		fprintf(stderr, "\n  Error->Cannot open file '%s'\n\n", in_dataK);
		exit(1);
	}

	iter_ch = new pdbIter( r1 );
	iter_ch2 = new pdbIter( r2 );
	for(int i=0;i<14;i++) {
		fgets( line, 70, f );
		//fprintf(stderr,"%s", line);

	}
	sscanf(line,"#Nquery:     %d \n",&dumpI);
	//fprintf(stderr,"%d\n", dumpI);
	fgets( line, 70, f );
	sscanf(line,"#Ntarget:     %d \n",&dumpI);
	//fprintf(stderr,"%d\n", dumpI);
	fgets( line, 70, f );
	fgets( line, 70, f );
	sscanf(line,"#Ncolumns:     %d \n",&dumpI);
	//fprintf(stderr,"%d\n", dumpI);
	for(int i=0;i<23;i++) {
		fgets( line, 70, f );
		//	fprintf(stderr,"-%s", line);
	}

	//Conditions
	condsRB= new Conditions();
	condsRU= new Conditions();
	condsRUF= new Conditions();

	condsI_RB= new Conditions();
	condsI_RU= new Conditions();



	for(i=0;i<dumpI;i++) {

		fscanf(f,"%d %f %f %f %d %s %s %s\n",&pOs, &distP, &dumpf1, &dumpf2,
				&Seg, &string1, &string2, &string3);

		chopping = split(string1, ":");
		if (chopping.size()==3) {
			pOsB = atoi(tempC=chopping[1].c_str());
			sel_Ch=-1;
			ChainB= (char *) chopping[0].c_str();
			for( iter_ch->pos_chain = 0; !iter_ch->gend_chain(); iter_ch->next_chain() )
			{
				ch = iter_ch->get_chain();
				if (strcmp(chopping[0].c_str(),ch->getName())==0) {
					sel_Ch=iter_ch->pos_chain ; break;
				}
			}
		}
		else {pOsB=-1;
		ChainB="-";
		}

		chopping2 = split(string2, ":");
		if (chopping2.size()==3) {
			pOsU = atoi(tempC=chopping2[1].c_str());
			sel_Ch2=-1;
			ChainU=(char *) chopping2[0].c_str();

			for( iter_ch2->pos_chain = 0; !iter_ch2->gend_chain(); iter_ch2->next_chain() )
			{
				ch = iter_ch2->get_chain();
				if (strcmp(chopping2[0].c_str(),ch->getName())==0) {
					sel_Ch2=iter_ch2->pos_chain ; break;
				}
			}

		}
		else { pOsU=-1;
		ChainU="-";
		}
		if (strcmp(string3,"@")==0) {


		   // fprintf(stderr,"%d %s %s -%c- -%c-  %d %d\n",pOs, string1, string2, ChainB[0] , ChainU[0], pOsB, pOsU );

			bool PR,PR5;
			PR=false;
			for(int i=0;i<maxR10;i++)
				if ((pOsB==contact_R10[0][i])
						&& (ChainB[0]==contact_R10C[0][i])
				) { PR=true;

				break;}

			PR5=false;
			for(int i=0;i<maxR5;i++)
				if ((pOsB==contact_R5[0][i])
						&& (ChainB[0]==contact_R5C[0][i])
				) {
					PR5=true;
					CR5U[0][i]=pOsU;
					CR5UC[0][i]=ChainU[0];
				  //  fprintf(stderr,"%d %s %s -%c- -%c-  %d %d\n",pOs, string1, string2, ChainB[0] , ChainU[0], pOsB, pOsU );

				}

			cond1= new Condition(-1,-1,-1,-1,sel_Ch,sel_Ch,pOsB,pOsB,-1,-1);
			cond2=  new Condition(-1,-1,-1,-1,sel_Ch2,sel_Ch2,pOsU,pOsU,-1,-1);
			condF = new Condition(-1,-1,-1,-1,sel_Ch2,sel_Ch2,pOsU,pOsU,-1,-1);

			if (PR)
			condsRUF->add(condF);


			cond1->add(" CA ");
			cond2->add(" CA ");



			if ( (PR5 && distP<3.0) || distP<2.0 ) {
		        //  fprintf(stderr,"RB %d Contact %c:%d  U %c:%d %f\n",i, ChainB[0], pOsB, ChainU[0], pOsU, distP  );

				condsRB->add(cond1);
				condsRU->add(cond2);
			}
		   if ( (PR5 && distP<3.0) || (PR && distP<2.0)) {
		        //  fprintf(stderr,"IB %d Contact %c:%d  U %c:%d %f\n",i, ChainB[0], pOsB, ChainU[0], pOsU, distP  );

				condsI_RB->add(cond1);
				condsI_RU->add(cond2);
			    //				fprintf(stderr,"R %d %f %f %f    %d   %s      %s     -%s- %d %d %d %d %c %c\n", pOs, distP, dumpf1, dumpf2,
				//							Seg, string1, string2, string3, pOsB, pOsU, sel_Ch, sel_Ch2, ChainB[0], ChainU[0]);
			}






		}
	}
	fclose(f);
	delete iter_ch;
	delete iter_ch2;

	Macromolecule *r1_ca=r1->select_cpy(condsRB);
	Macromolecule *r2_ca=r2->select_cpy(condsRU);
	Macromolecule *r2_ca_ref=r2->select_cpy(condsRU);
	Macromolecule *r2_refF=r2->select_cpy(condsRUF);
//	r2_refF->writePDB("refF.pdb");
//    r2->writePDB("ref.pdb");
//	fprintf(stderr," Hola\n");
//
//    getchar();

	Macromolecule *r2_ca_dump=r2->select_cpy(condsRU);

	fprintf(stderr," Receptor Bound-Unbound %f ", r1_ca->rmsd(r2_ca));
	MAXRR=r1_ca->minRmsd(r2_ca, matrix4);
	matrix4_opR=new M4Rot(matrix4);
	r2_ca_dump->applyAtoms(matrix4_opR);
	fprintf(stderr," Fitted   %f %f\n", r1_ca->rmsd(r2_ca_dump), MAXRR);

	if (in_pdb) {
		r2_ca_ref->writePDB("unbound_recept.pdb");
		r1_ca->writePDB("bound_recept.pdb");
	}


	Macromolecule *r1_ca_I=r1->select_cpy(condsI_RB);
	Macromolecule *r2_ca_I=r2->select_cpy(condsI_RU);
	Macromolecule *r2_ca_I_ref=r2->select_cpy(condsI_RU);

	float dumpf;
	fprintf(stderr," Interface R-  %f ", r1_ca_I->rmsd(r2_ca_I));
	MAXRR=r1_ca_I->minRmsd(r2_ca_I, matrix4);
	matrix4_opIR=new M4Rot(matrix4);
	r2_ca_I_ref->applyAtoms(matrix4_opIR);
	fprintf(stderr," Fitted   %f %f\n", r1_ca_I->rmsd(r2_ca_I_ref), MAXRR);

	if (in_pdb) {
		r2_ca_I->writePDB("Uinter_recept.pdb");
		r2_ca_I_ref->writePDB("Uinter_receptRef.pdb");
		r1_ca_I->writePDB("Binter_recept.pdb");
	}


	//Macromolecule *l2_ca_I_ref=l2_ref->select_cpy(conds2_3);





	// LIGANDS BOUND AND UNBOUND

	sprintf( in_dataK, "%s_l_ub.kpairs",in_data);
	fprintf(stderr, " Open file '%s'\n", in_dataK);

	f=fopen(in_dataK,"rt");
	if ( f==NULL) {
		fprintf(stderr, "\n  Error->Cannot open file '%s'\n\n", in_dataK);
		exit(1);
	}

	iter_ch = new pdbIter( l1 );
	iter_ch2 = new pdbIter( l2 );
	for(i=0;i<14;i++) {
		fgets( line, 70, f );
		//fprintf(stderr,"%s", line);

	}
	sscanf(line,"#Nquery:     %d \n",&dumpI);
	//fprintf(stderr,"%d\n", dumpI);
	fgets( line, 70, f );
	sscanf(line,"#Ntarget:     %d \n",&dumpI);
	//fprintf(stderr,"%d\n", dumpI);
	fgets( line, 70, f );
	fgets( line, 70, f );
	sscanf(line,"#Ncolumns:     %d \n",&dumpI);
	//fprintf(stderr,"%d\n", dumpI);
	for(i=0;i<23;i++) {
		fgets( line, 70, f );
		// fprintf(stderr,"-%s", line);
	}

	//Conditions
	condsLB= new Conditions();
	condsLU= new Conditions();
	condsLUF= new Conditions();

	condsI_LB= new Conditions();
	condsI_LU= new Conditions();


	for(i=0;i<dumpI;i++) {

		fscanf(f,"%d %f %f %f %d %s %s %s\n",&pOs, &distP, &dumpf1, &dumpf2,
				&Seg, &string1, &string2, &string3);

		// fprintf(stderr,"---> %d B %s U %s\n",pOs, string1, string2 );

		chopping = split(string1, ":");
		if (chopping.size()==3) {
			pOsB = atoi(tempC=chopping[1].c_str());
			ChainB=(char *)chopping[0].c_str();
			sel_Ch=-1;
			for( iter_ch->pos_chain = 0; !iter_ch->gend_chain(); iter_ch->next_chain() )
			{
				ch = iter_ch->get_chain();
				if (strcmp(chopping[0].c_str(),ch->getName())==0) {
					sel_Ch=iter_ch->pos_chain ; break;
				}
			}
		}
		else {
			pOsB=-1;
			ChainB="-";
		}

		chopping2 = split(string2, ":");
		if (chopping2.size()==3) {
			pOsU = atoi(tempC=chopping2[1].c_str());
			ChainU=(char *)chopping2[0].c_str();
			sel_Ch2=-1;
			for( iter_ch2->pos_chain = 0; !iter_ch2->gend_chain(); iter_ch2->next_chain() )
			{
				ch = iter_ch2->get_chain();
				if (strcmp(chopping2[0].c_str(),ch->getName())==0) {
					sel_Ch2=iter_ch2->pos_chain ; break;
				}
			}

		}
		else {
			pOsU=-1;
			ChainU="-";
		}


		if (strcmp(string3,"@")==0) {


			// fprintf(stderr,"%d %s %s B -%c- U -%c-  %d %d\n",pOs, string1, string2, ChainB, ChainU, pOsB, pOsU );


			bool PL,PL5;
			PL=false;
			for(int i=0;i<maxR10;i++)
				if ((pOsB==contact_R10[1][i])
						&& (ChainB[0]==contact_R10C[1][i])

				) { PL=true;

				//	fprintf(stderr,"%d B -%c- Contact -%c- %d\n",i, ChainB, contact_R10C[1][i], contact_R10[1][i] );
				//	getchar();
				break;}

			PL5=false;
			for(int i=0;i<maxR5;i++)
				if ((pOsB==contact_R5[1][i]) &&
						(ChainB[0]==contact_R5C[1][i])) {
					PL5=true;
					CR5U[1][i]=pOsU;
					CR5UC[1][i]=ChainU[0];
				}


			cond1 = new Condition(-1,-1,-1,-1,sel_Ch,sel_Ch,pOsB,pOsB,-1,-1);
			cond2 = new Condition(-1,-1,-1,-1,sel_Ch2,sel_Ch2,pOsU,pOsU,-1,-1);
			condF = new Condition(-1,-1,-1,-1,sel_Ch2,sel_Ch2,pOsU,pOsU,-1,-1);


			if (PL)
			condsLUF->add(condF);


			cond1->add(" CA ");
			cond2->add(" CA ");





			if ( (PL5 && distP<3.0) || distP<2.0 ) {

	      //    fprintf(stderr,"LB %d Contact %c:%d  U %c:%d %f\n",i, ChainB[0], pOsB, ChainU[0], pOsU, distP  );

				condsLB->add(cond1);
				condsLU->add(cond2);
			}

			if ( (PL5 && distP<3.0) || (PL && distP<2.0)) {
		//          fprintf(stderr,"IB %d Contact %c:%d  U %c:%d %f\n",i, ChainB[0], pOsB, ChainU[0], pOsU, distP  );

				condsI_LB->add(cond1);
				condsI_LU->add(cond2);
				//		fprintf(stderr,"L %d %f %f %f    %d   %s      %s     -%s- %d %d %d %d %c %c\n",pOs, distP, dumpf1, dumpf2,
				//				Seg, string1, string2, string3, pOsB, pOsU, sel_Ch, sel_Ch2, ChainB[0], ChainU[0]);
			}




		}
	}
	fclose(f);
	delete iter_ch;
	delete iter_ch2;

	Macromolecule *l1_ca=l1->select_cpy(condsLB);
	Macromolecule *l2_ca=l2->select_cpy(condsLU);

	Macromolecule *l2_ca_dump=l2->select_cpy(condsLU); // do not use now

	// l2_ca->writePDB("unbound_ligand.pdb");
	fprintf(stderr," Ligand Bound-Unbound %f", l1_ca->rmsd(l2_ca));
	MAXRL=l1_ca->minRmsd(l2_ca, matrix4);
	matrix4_opL=new M4Rot(matrix4);
	l2_ca_dump->applyAtoms(matrix4_opL);


	fprintf(stderr," Fitted   %f %f\n", l1_ca->rmsd(l2_ca_dump), MAXRL);
	if (in_pdb) {
		l1_ca->writePDB("bound_ligand.pdb");
		l2_ca->writePDB("unbound_ligand.pdb");
	}


	Macromolecule *l1_ca_I=l1->select_cpy(condsI_LB);
	//	l1_ca_I->writePDB("Binter_ligand.pdb");
	Macromolecule *l2_ca_I=l2->select_cpy(condsI_LU);
	Macromolecule *l2_ca_I_dump=l2->select_cpy(condsI_LU);

	fprintf(stderr," Interface L  %f ",l1_ca_I->rmsd(l2_ca_I));
	MAXRL=l1_ca_I->minRmsd(l2_ca_I, matrix4);
	matrix4_opIL=new M4Rot(matrix4);
	l2_ca_I_dump->applyAtoms(matrix4_opIL);
	fprintf(stderr," Fitted   %f %f\n", l1_ca_I->rmsd(l2_ca_I_dump),MAXRL);
	if (in_pdb) {
		l2_ca_I->writePDB("Uinter_ligand.pdb");
		l2_ca_I_dump->writePDB("Uinter_ligandref.pdb");
	}
	//		fprintf(stderr,"\n");
	//		for(int i=0; i < 4; i++) {
	//			for(int j=0; j < 4; j++)
	//		    fprintf(stderr,"%6.3f ", matrix4[i][j]);
	//			fprintf(stderr, "\n");
	//
	//		}



	listB[0]=r1_ca_I;listB[1]=l1_ca_I;
	Macromolecule *complexB= new Macromolecule(listB,2);


	listB[0]=r2_ca_I_ref;listB[1]=l2_ca_I_dump;
	Macromolecule *complexU= new Macromolecule(listB,2);

	Macromolecule *complexU_ref= new Macromolecule(listB,2);

	if (in_pdb) {
		complexU->writePDB("unbound_interface.pdb");
		complexB->writePDB("bound_interface.pdb");
	}

	fprintf(stderr," Interface  %f ", complexB->minRmsd(complexU,matrix4));
	matrix4_op=new M4Rot(matrix4);
	complexU->applyAtoms(matrix4_op);
	fprintf(stderr," Fitted %f\n", complexB->rmsd(complexU));
	if (in_pdb) {
		complexU->writePDB("unbound_interface_fitted.pdb");
	}
	delete complexU;

	// FNAT
	contact_R =r2->getInterface( l2_ref, 5.0 ,&maxR, &contact_RC, false );
			//		for(int i=0;i<maxR;i++)
			//						fprintf(stderr,"[%c-%3d] [%c-%3d] [%c-%3d] [%c-%3d]\n",CR5UC[0][i], CR5U[0][i], CR5UC[1][i], CR5U[1][i],
			//									contact_RC[0][i],contact_R[0][i],contact_RC[1][i],contact_R[1][i]);
			fnat=fnonnat=0;
					for(int j=0;j<maxR5;j++) {
						notFound=true;
						for(int i=0;i<maxR;i++) {
							if(        (contact_R[0][i]==CR5U[0][j])
									&& (contact_R[1][i]==CR5U[1][j])
									 && (contact_RC[0][i]==CR5UC[0][j])
									 && (contact_RC[1][i]==CR5UC[1][j]) ) {
								fnat++;
								notFound=false;
								break;
							}
						}
						if(notFound) {
							fnonnat++;
						}
					}
					free(contact_R);
					free(contact_RC);
			fprintf(stderr," %s Max Rmsd R %f L %f Fnat %f Fnonat %f #contacts %d\n",
					in_data + strlen(in_data) - 4, MAXRR, MAXRL, (float) fnat/(maxR5*1.0), fnonnat/(maxR5*1.0), maxR5 );




	if(in_mult)
	{
		fprintf(stderr,"Reading %s\n", in_multiple);


		f=fopen(in_multiple,"rb");
		if ( f==NULL) {
			fprintf(stderr, "\n  Error->Cannot open file '%s'\n\n", in_multiple);
			exit(1);
		}

		fread(&npeaksTotal,  sizeof(int),  1, f);
		if (in_old) {fread(&center[0],  sizeof(float),  3, f);
		fprintf(stderr," Read  Lig center: %f %f %f Peaks %d\n", center[0],center[1],center[2], npeaksTotal);
		}
		if (npeaksTotal>in_points) {
			fprintf(stderr," Checking %d peaks\n", in_points);
			npeaksTotal=in_points;
		}




		l2_ref->geoCenter( original_center );
		invert_original_center[0] = original_center[0] * ( -1.0 );
		invert_original_center[1] = original_center[1] * ( -1.0 );
		invert_original_center[2] = original_center[2] * ( -1.0 );

		fprintf(stderr," Apply Lig center: %f %f %f\n",original_center[0],original_center[1],original_center[2]);


		l2_ref->moveAll( invert_original_center );
		Macromolecule *l2_ca_ref=l2_ref->select_cpy(condsLU); // do not use now
		Macromolecule *l2_ca_I_ref=l2_ref->select_cpy(condsI_LU);
		Macromolecule *l2_refF=l2_ref->select_cpy(condsLUF);
		Macromolecule *l2_dumpF=l2_ref->select_cpy(condsLUF);


		solution2=(float*)malloc(sizeof(float)*11*npeaksTotal);

        EulerRot *rot;

		for(cont_sol=initPeak,cont_real=0;cont_sol<npeaksTotal;cont_sol++)
		{
			time_total.restart();
			time_step.restart();

			if(in_mult)
			{
				fread(solution,sizeof(float),7,f);

				euler[0]=solution[0]*(3.1415297/180.0);
				euler[1]=solution[1]*(3.1415297/180.0);
				euler[2]=solution[2]*(3.1415297/180.0);
				offset[0]=solution[3];//+0.5;
				offset[1]=solution[4];//+0.5;
				offset[2]=solution[5];//+0.5;

				M4Rot *m4rot =new M4Rot(euler, 0,offset);
				l2_ca ->applyAtoms(m4rot,l2_ca_ref);
				l2_ca_I->applyAtoms(m4rot,l2_ca_I_ref);

//				l1_ca->writePDB("bound_ligand2.pdb");
//				l2_ca->writePDB("unbound_ligand2.pdb");

//				l1_ca_I->writePDB("bound_ligandI2.pdb");
//				l2_ca_I->writePDB("unbound_ligandI2.pdb");

				listU[0]=r2_ca_I;listU[1]=l2_ca_I;
				Macromolecule *complexU= new Macromolecule(listU,2);


				for(int i=0;i<7;i++)
					solution2[i+(cont_real*11)]=solution[i];
				output1=l1_ca->rmsd(l2_ca);;
				solution2[7+(cont_real*11)]=output1;
				output2=complexB->minRmsd(complexU,matrix4);
				solution2[8+(cont_real*11)]=output2;


				//fprintf(stderr,"%d %f %f\n", cont_real, solution2[7+(cont_real*11)], solution2[8+(cont_real*11)] );
//			    getchar();
				// FNAT calculation
			    if( in_fnat || (in_sfnat && (output1<rmsd_limit_L || output2<rmsd_limit_I))	)
				{

					l2_dumpF ->applyAtoms(m4rot,l2_refF);
					contact_R =r2_refF->getInterface( l2_dumpF, 5.0 ,&maxR, &contact_RC, false );
					// fprintf(stderr,"MAX_R %d %d\n",maxR, maxR5);

//					l2 ->applyAtoms(m4rot,l2_ref);
//					contact_R =r2_refF ->getInterface( l2 , 5.0 ,&maxR, &contact_RC, false );

					fnat=fnonnat=0;
					for(int j=0;j<maxR5;j++) {
						notFound=true;
						for(int i=0;i<maxR;i++) {
							if(        (contact_R[0][i]==CR5U[0][j])
									&& (contact_R[1][i]==CR5U[1][j])
							//		&& (contact_RC[0][i]==contact_R5C[0][j])
							//		&& (contact_RC[1][i]==contact_R5C[1][j]) ) {
									&& (contact_RC[0][i]==CR5UC[0][j])
									&& (contact_RC[1][i]==CR5UC[1][j]) ) {
								fnat++;
								notFound=false;
//								fprintf(stderr, "%c-%d - %c-%d    %c-%d - %c-%d\n",contact_RC[0][i],contact_R[0][i],
//																			 contact_RC[1][i],contact_R[1][i],
//																			 contact_R5C[0][j],CR5U[0][j],
//																			 contact_R5C[1][j],CR5U[1][j] );
								break;
							}
						}
						if(notFound) {
							fnonnat++;
									}
					}
					//fprintf(stderr,"%d %f Fnat %f Fnonat %f #contacts %d\n", Fnat, solution2[7+(cont_real*11)], (float) fnat/(maxR5*1.0), fnonnat/(maxR5*1.0), maxR5 );


					free(contact_R);
					free(contact_RC);
					solution2[9+(cont_real*11)]=(float) fnat/(maxR5*1.0);
					solution2[10+(cont_real*11)]=(float)fnonnat/(maxR5*1.0);
				}

//				else {
//					fprintf(stderr,"Mierda\n");
//
//					solution2[9+(cont_real*11)]=0;
//					solution2[10+(cont_real*11)]=0;
//				}
				delete m4rot;
				delete(complexU);
			}
			cont_real++;


		}




		fclose(f);



		fprintf(stderr, " Saving %s file\n\n", in_output);

		f2=fopen(in_output,"wt");
		if ( f2==NULL) {
			fprintf(stderr, "\n  Error->Cannot open file '%s'\n\n", in_output);
			exit(1);
		}
		fwrite(&cont_real,sizeof(int),1,f2);
		if (in_old) fwrite(&center[0],  sizeof(float),  3, f2);
		fwrite(solution2,sizeof(float),11*cont_real,f2);
		fclose(f2);
	}

	else {

		fprintf(stderr, "\n  Pending '\n");
		exit(1);

	}









}

void parseOptions(int argc, char** argv)
{
	string temp;
	CmdLine cmd(argv[0],"   ", "2.0" );

	try {
		//
		// Define required arguments no labeled
		//
		UnlabeledValueArg<string> receptB("boundReceptor","bound receptor pdb file","default","boundReceptor");
		cmd.add( receptB );

		UnlabeledValueArg<string> receptU("unboundReceptor","unbound receptor pdb file","default","unboundReceptor");
		cmd.add( receptU );

		UnlabeledValueArg<string> ligandB("boundLigand","bound ligand pdb file","default","boundLigand");
		cmd.add( ligandB );

		UnlabeledValueArg<string> ligandU("unboundLigand","unbound ligand pdb file","default","unboundLigand");
		cmd.add( ligandU );

		UnlabeledValueArg<string> data("Kdata","Kpair data input file","default","data");
		cmd.add( data );

		ValueArg < string > multiple( "", "solutions", "data solutions file", false, "solutions.dat", "string" );
		cmd.add( multiple );

		ValueArg < string > output( "", "output", "binary output file (default: tcheck.dat)", false, "tcheck.dat", "string" );
		cmd.add( output );

		//		SwitchArg number( "n", "", "show number of amino acids in interface", false );
		//		cmd.add( number );
		ValueArg < int > nump( "n", "npoints", "Maximum number of points considered.", false, 10000, "int" );
		cmd.add( nump );

		SwitchArg fnat( "f", "fnat", "Enable full fnat computation", false );
		cmd.add( fnat );

		SwitchArg sfnat( "s", "sfnat", "Disable selective computation of fnat ", true );
		cmd.add( sfnat );

		SwitchArg savep( "p", "savepdb", "savepdbs", true );
		cmd.add( savep );

		//		ValueArg < int > only( "o", "only", "evaluate only one solution on the data input file", false, -1, "int" );
		//		cmd.add( only );

		SwitchArg old( "", "old", "Old format", false );
		cmd.add( old );


		// Parse the command line.
		cmd.parse(argc,argv);

		strcpy(in_r1,((temp=receptB.getValue()).c_str()));
		strcpy(in_r2,((temp=receptU.getValue()).c_str()));
		strcpy(in_l1,((temp=ligandB.getValue()).c_str()));
		strcpy(in_l2,((temp=ligandU.getValue()).c_str()));
		strcpy(in_data,((temp=data.getValue()).c_str()));


		strcpy(in_output,((temp=output.getValue()).c_str()));

		if(multiple.isSet())
		{
			in_mult=true;
			strcpy(in_multiple,((temp=multiple.getValue()).c_str()));
		}
		else
			in_mult=false;

		//		in_number=number.getValue();



		if(sfnat.isSet()) in_sfnat=false;
		   else in_sfnat=true;

		if(fnat.isSet()) { in_fnat=true; }
		else in_fnat=false;

		if (in_sfnat) fprintf(stderr," Fnat computation RMSD<10 or RMSDi<4.0 on\n");
		if (in_fnat)  fprintf(stderr," Full Fnat computation on\n");
		else fprintf(stderr,"  Full fnat computation off\n");

		in_pdb=savep.getValue();
		in_points=nump.getValue();

		//		in_only=only.getValue();

		if(old.isSet()) in_old=false;
		else in_old=true;


	} catch ( ArgException& e )
	{
		cout << "  Error->" << e.error() << " " << e.argId() << endl;
	}
	//cmd.~CmdLine();

}
