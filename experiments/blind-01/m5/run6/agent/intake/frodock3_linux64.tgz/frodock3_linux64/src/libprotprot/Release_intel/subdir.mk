################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CPP_SRCS += \
../Auxiliar.cpp \
../EVolumes.cpp \
../Mask.cpp \
../PCollection.cpp \
../SCollection.cpp \
../SH_Object.cpp 

OBJS += \
./Auxiliar.o \
./EVolumes.o \
./Mask.o \
./PCollection.o \
./SCollection.o \
./SH_Object.o 

CPP_DEPS += \
./Auxiliar.d \
./EVolumes.d \
./Mask.d \
./PCollection.d \
./SCollection.d \
./SH_Object.d 


# Each subdirectory must supply rules for building sources it contributes
%.o: ../%.cpp
	@echo 'Building file: $<'
	@echo 'Invoking: Intel C++ Compiler'
	icpc -O3 -inline-level=2 -I../include -I../../../src -DVOLUME_INCLUDED -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@:%.o=%.d)" -c -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


