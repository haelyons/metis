#pragma once
#include <iostream>
using namespace std;
class PointVoxel
{
public:
	PointVoxel(float *p,float vC, float vF);
	~PointVoxel(void);
	void setSH(float** SHR, float** SHI);
	float** getSHRe();
	float** getSHIm();
	float getX();
	float getY();
	float getZ();
	float getValueClose();
	float getValueFar();
	bool operator<(PointVoxel& p1);
	friend ostream& operator<<(ostream& os,const PointVoxel& pv);
private:
	float point[3];
	float valueClose;
	float valueFar;
	float **SHRe;
	float **SHIm;
};

