################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CPP_SRCS += \
../Correlation.cpp \
../obj_aux.cpp \
../obj_fsphh.cpp \
../obj_vlsphh.cpp \
../sh_makeweights.cpp \
../sh_seminaive_analysis.cpp \
../sh_tbl_cospmls.cpp \
../sh_tbl_utils.cpp 

OBJS += \
./Correlation.o \
./obj_aux.o \
./obj_fsphh.o \
./obj_vlsphh.o \
./sh_makeweights.o \
./sh_seminaive_analysis.o \
./sh_tbl_cospmls.o \
./sh_tbl_utils.o 

CPP_DEPS += \
./Correlation.d \
./obj_aux.d \
./obj_fsphh.d \
./obj_vlsphh.d \
./sh_makeweights.d \
./sh_seminaive_analysis.d \
./sh_tbl_cospmls.d \
./sh_tbl_utils.d 


# Each subdirectory must supply rules for building sources it contributes
%.o: ../%.cpp
	@echo 'Building file: $<'
	@echo 'Invoking: Cross G++ Compiler'
	g++ -DVOLUME_INCLUDED -DPDB_INCLUDED -I../include -I../../../src -O2 -U_FORTIFY_SOURCE -g -Wall -c  -fpermissive  -fno-omit-frame-pointer -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


