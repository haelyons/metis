
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <list>

#include <cmdl/CmdLine.h>
#include <libpdb/include/Macromolecule.h>
#include <libpdb/include/pdbIter.h>
#include <libtools/include/timer.h>
#include <libtools/include/Io.h>



using namespace TCLAP;

// Computes the Gaussian weights profile from inter-atomic distances between "mol" and "mol2"
// allocating profile memory if (*p_profile==NULL).
// Weights are computed according to ec.(7) from: w= exp(-(d^2)/c ) --> c=5A (for big motions)
// Damm & Carlson. "Gaussian-Weighted RMSD Superposition of Proteins: A Structural
// Comparison for Flexible Proteins and Predicted Protein Structures".
// Biophysical Journal. Volume 90, Issue 12, 15 June 2006, Pages 4558-4573
//void gaussian_weight(Macromolecule *mol, Macromolecule *mol2, double **p_profile, double c=5.0);

int main(int argc, char *argv[])
{

	CmdLine cmd(argv[0],"   ", "1.04" );
	char file_ref[500]; // pdb input reference
	char file_mob[500]; // pdb input
	char file_out[500]; // pdb output
	char file_aln[500]; // Sequence alignment file name
	char dist_profiles[] = "dist_profiles.txt";
	float matrix4[4][4];
	std::string temp;
	int aln_level = 2; // Clustal alignment level  (1, 2 or 3 to match *, *: or *:. ,respectively)
	bool *maskres,*maskres2;
	bool *maskmol=NULL, *maskmol2=NULL;
	int nmatch,nali1,nali2;
	double *prof=NULL; // Distance profile before alignment
	double *prof2=NULL; // Distance profile after alignment
	Chain *ch; // Mon(7/1/2016): See below...

	for(int i=0; i < 4; i++)
		for(int j=0; j < 4; j++)
			    matrix4[i][j]=0;



	try {
		//
		// Define required arguments no labeled
		//
		UnlabeledValueArg<std::string> pdb_ref("ref_pdb","reference pdb file","default","pdb");
		cmd.add( pdb_ref );

		UnlabeledValueArg<std::string> pdb_mob("mob_pdb","mobile pdb file","default","pdb");
		cmd.add( pdb_mob );

		// optional arguments

		SwitchArg Dist("","dist", "Compute the inter-residue distance profiles (averaged over residue atoms) before and after alignment: dist_profiles.txt", false);
		cmd.add( Dist );

		ValueArg<int> AlnLevel("","aln_level", "Clustal alignment level (1, 2 or 3 to match *, *: or *:. ,respectively) (default=2)",false,2,"int");
		cmd.add( AlnLevel );

	    ValueArg<std::string> AlnFile("a","aln_file", "Clustal's \".aln\" file defining alingment between initial and target atomic structures.\n",false,"alnstring","string");
	    cmd.add( AlnFile );

		ValueArg<double> gauss_c("C","gauss_c", "Gaussian width (default=20)",false,20.0,"double");
		cmd.add( gauss_c );

		SwitchArg gauss("g","gauss", "Gaussian-weighted RMSD superposition", false);
		cmd.add( gauss );

		SwitchArg RemoveH("", "noH","Removing Hydrogen atoms from output files and computations.", false);
		cmd.add( RemoveH );

		SwitchArg BBone("b","bb", "only BackBone atoms (N,CA,C,O) in proteins", false);
		cmd.add( BBone );

		SwitchArg CAlpha("c","calpha", "only C alpha in proteins or P in nucleic acids", false);
		cmd.add( CAlpha );

		ValueArg<std::string> pdb_moved("o","output","output pdb file (mobile onto reference)",false,"","string");
		cmd.add(pdb_moved);

		ValueArg<char> Chain("","chain", "Chain ID (default=first chain of reference PDB)",false,1,"int");
		cmd.add( Chain );

		ValueArg<int> ResOffset("","res_offset", "Residue index offset (default=0)",false,0,"int");
		cmd.add( ResOffset );

		// Parse the command line.
		cmd.parse(argc,argv);

		init_aminoacids(Rosseta,pdb);


		// reading pdb
		Macromolecule *mol=new Macromolecule("pdb");
		Macromolecule *mol2=new Macromolecule("pdb2");
		Macromolecule *mol_ca;
		Macromolecule *mol2_ca;

		// stupid transformation from string to char
		strcpy(file_ref,((temp=pdb_ref.getValue()).c_str()));
		strcpy(file_mob,((temp=pdb_mob.getValue()).c_str()));
		mol->readPDB(file_ref);
		mol2->readPDB(file_mob);

		// Removeing Hydrogens
		if(RemoveH.isSet())
		{
			mol->delete_hydrogens(); // Remove Hydrogens
			mol2->delete_hydrogens(); // Remove Hydrogens
//			printf( ">> Hydrogens were removed.\n" );
		}


		int ri = -1; // All residues by default
		int rf = -1; // All residues by default
		int ichain = -1; // All chains by default

		// Get loop limits and chain id from first model in Multi-PDB (Mobile)
		Condition *firstmolec; // First molecule conditions
		firstmolec = new Condition(0,0,-1,-1,-1,-1,-1,-1,-1,-1); // First loop selection
		Conditions *firstmolec2= new Conditions();
		firstmolec2->add(firstmolec);
		Macromolecule *molec0;
		molec0 = mol2->select_cpy(firstmolec2);
		pdbIter *iter_molec = new pdbIter(molec0);
		// Segment *seg;
		// iter_molec->pos_segment=0;
		// seg = iter_molec->get_segment();
		iter_molec->pos_chain=0;
		ch = iter_molec->get_chain();
		// pdbIter *iter_seg = new pdbIter(seg);
		pdbIter *iter_chain = new pdbIter(ch);
//		iter_seg->pos_fragment=0;
//		ri = (iter_seg->get_fragment())->getIdNumber(); // get Nt anchor residue number (PDB)
//		iter_seg->pos_fragment=iter_seg->num_fragment()-1;
//		rf = (iter_seg->get_fragment())->getIdNumber(); // get Ct anchor residue number (PDB), i.e. the last that moves...
		iter_chain->pos_fragment=0;
		ri = (iter_chain->get_fragment())->getIdNumber(); // get Nt anchor residue number (PDB)
		iter_chain->pos_fragment=iter_chain->num_fragment()-1;
		rf = (iter_chain->get_fragment())->getIdNumber(); // get Ct anchor residue number (PDB), i.e. the last that moves...
		// Chain *ch; // Mon(7/1/2016): Compilers (intel and gcc) say this is not declared within scope... WTF???
		iter_molec->pos_chain = 0;
		ch = iter_molec->get_chain();
		char chain = ch->getName()[0];
		delete iter_molec;
//		delete seg;
		ri += ResOffset.getValue();
		rf -= ResOffset.getValue();
		fprintf(stderr, "> Considered chain \"%c\" goes from residue %d (Nt) to %d (Ct), including an index offset of %d.\n", chain, ri, rf, ResOffset.getValue() );

		// Get chain index (internal) for Reference PDB
		pdbIter *iter_mol = new pdbIter(mol);
		for( iter_mol->pos_chain = 0; !iter_mol->gend_chain(); iter_mol->next_chain() ) // screen chains
		{
			ch=iter_mol->get_chain();
			if(ch->getName()[0] == chain)
			{
				ichain = iter_mol->pos_chain; // chain internal index
				break;
			}
		}
		delete iter_mol;
		if(ichain < 0) // Some checking...
		{
			fprintf(stderr,"> Sorry, chain \"%c\" not found in %s (reference PDB)! Using all chains!\n",chain,file_ref);
			//exit(1);
		}
		// Note: chain index "0" is assumed for Mobile PDB

		// Atomic selection Conditions
//		Condition *calpha= new Condition(-1,-1,-1,-1,ichain,ichain,ri,rf,-1,-1);
		Condition *calpha= new Condition(-1,-1,ichain,ichain,-1,-1,ri,rf,-1,-1); // Mon (9/4/2018): Bug, we must select by chain, not segment.
		if( CAlpha.isSet() )
		{
			calpha->add(" CA ");
			calpha->add(" P  ");
		}
		if( BBone.isSet() )
		{
			calpha->add(" N  ");
			calpha->add(" CA ");
			calpha->add(" C  ");
			calpha->add(" O  ");
		}
		Conditions *calpha2= new Conditions();
		calpha2->add(calpha);


		if(AlnFile.isSet())
		{
			strcpy(file_aln,((temp=AlnFile.getValue()).c_str())); // Gets Alignment file name
			aln_level = AlnLevel.getValue();

			printf( "%s> Reading Clustal's sequence alignment from: %s\n","",file_aln);
			read_aln(file_aln, &maskres, &nali1, &maskres2, &nali2, &nmatch, aln_level);
			printf( "%s> %d residues matched!  nali1= %d  nali2= %d\n","",nmatch,nali1,nali2);
		}

		// only selection is considered
		float rmsd_i,rmsd_f;
		if( CAlpha.isSet() || BBone.isSet() )
		{
			// if CA / BB selection
			mol_ca=mol->select(calpha2);
			mol2_ca=mol2->select(calpha2);
//			mol->writePDB("mymol.pdb");
//			mol_ca->writePDB("mymolca.pdb");
//			mol2->writePDB("mymol2.pdb");
//			mol2_ca->writePDB("mymol2ca.pdb");

			if(AlnFile.isSet())
			{
				maskmol = mol_ca->maskres2maskatom(maskres);
				maskmol2 = mol2_ca->maskres2maskatom(maskres2);
				rmsd_i = mol_ca->rmsd(mol2_ca,maskmol,maskmol2);
			}
			else
				rmsd_i = mol_ca->rmsd(mol2_ca);

//			fprintf(stderr,"ichain=%d  ri=%d  rf=%d  maskmol %d:\n", ichain, ri, rf, mol_ca->get_num_atoms());
//			for(int x=0; x<mol_ca->get_num_atoms(); x++)
//				fprintf(stderr," %1d",maskmol[x]);
//			fprintf(stderr,"\n");

			if(pdb_moved.isSet() || gauss.isSet())
				if(AlnFile.isSet())
					rmsd_f = mol_ca->minRmsd(mol2_ca,matrix4,maskmol,maskmol2);
				else
					rmsd_f = mol_ca->minRmsd(mol2_ca,matrix4);
			else
				if(AlnFile.isSet())
				{
					// rmsd_f = mol_ca->minRmsd(mol2_ca,maskmol,maskmol2);
					// fprintf(stderr,"Not implemented yet!\n");
					// exit(0);
					rmsd_f = mol_ca->minRmsd(mol2_ca,matrix4,maskmol,maskmol2); // A different function (without matrix4 computation) should be made...
				}
				else
					rmsd_f = mol_ca->minRmsd(mol2_ca);
		}
		else // All atoms
		{
			if(AlnFile.isSet())
			{
				maskmol = mol->maskres2maskatom(maskres);
				maskmol2 = mol2->maskres2maskatom(maskres2);
				rmsd_i = mol->rmsd(mol2,maskmol,maskmol2);
			}
			else
				rmsd_i = mol->rmsd(mol2);

			if (pdb_moved.isSet() || gauss.isSet())
				if(AlnFile.isSet())
					rmsd_f = mol->minRmsd(mol2,matrix4,maskmol,maskmol2);
				else
					rmsd_f = mol->minRmsd(mol2,matrix4);
			else
				if(AlnFile.isSet())
				{
					// rmsd_f = mol_ca->minRmsd(mol2_ca,maskmol,maskmol2);
					// fprintf(stderr,"Not implemented yet!\n");
					// exit(0);
					rmsd_f = mol->minRmsd(mol2,matrix4,maskmol,maskmol2);
				}
				else
					rmsd_f = mol->minRmsd(mol2);
		}
		printf("RMSD: init. %.4f ",rmsd_i);

		printf("\n");
		for(int i=0; i < 4; i++) {
			for(int j=0; j < 4; j++)
		    printf("%6.3f ", matrix4[i][j]);
			printf("\n");

		}


		if(Dist.isSet())
		{
			if( CAlpha.isSet() || BBone.isSet() )
				mol_ca->dist_profile(mol2_ca,&prof,maskmol,maskmol2);
			else
				mol->dist_profile(mol2,&prof,maskmol,maskmol2);
		}

		if(gauss.isSet()) // YES-Gauss
		{
			int imax = 1000; // maximum number of iterations
			int iter=0;
			double *prof_wrmsd=NULL;
			float conv = 1e-6; // convergence criteria
			float delta = 1e6;
			float score_old = 1e6;
			float score;
			double sum_w=0.0;
			int num_atoms,num_res;

			// Initial alignment (minRMSD) (computed with selection, but applied to full model)
			M4Rot *matrix4_op=new M4Rot(matrix4);
			mol2->applyAtoms(matrix4_op); // superpose full-atom
			delete matrix4_op;

			if( CAlpha.isSet() || BBone.isSet() )
			{
				num_atoms = mol_ca->get_num_atoms();
				num_res = mol_ca->get_num_fragments();
			}
			else
			{
				num_atoms = mol->get_num_atoms();
				num_res = mol->get_num_fragments();
			}

			// Iterate until convergence
			for(iter=0; iter<imax && delta>conv; iter++)
			{
				score_old = score;
				if( CAlpha.isSet() || BBone.isSet() )
				{
					//			norm_profile(prof_wrmsd, mol_ca->get_num_atoms(), 0.0, 1.0);
					if(AlnFile.isSet())
					{
						mol_ca->gaussian_weight(mol2_ca,&prof_wrmsd,maskmol,maskmol2,gauss_c.getValue());
						score = mol_ca->minWRmsd(mol2_ca,matrix4,prof_wrmsd,maskmol,maskmol2); // computing transformation
					}
					else
					{
						mol_ca->gaussian_weight(mol2_ca,&prof_wrmsd,gauss_c.getValue());
						score = mol_ca->minWRmsd(mol2_ca,matrix4,prof_wrmsd); // computing transformation
					}
					matrix4_op = new M4Rot(matrix4);
					mol2->applyAtoms(matrix4_op);
				}
				else
				{
					//			norm_profile(prof_wrmsd, mol->get_num_atoms(), 0.0, 1.0);
					if(AlnFile.isSet())
					{
						mol->gaussian_weight(mol2,&prof_wrmsd,maskmol,maskmol2,gauss_c.getValue());
						score = mol->minWRmsd(mol2,matrix4,prof_wrmsd,maskmol,maskmol2); // computing transformation
					}
					else
					{
						mol->gaussian_weight(mol2,&prof_wrmsd,gauss_c.getValue());
						score = mol->minWRmsd(mol2,matrix4,prof_wrmsd); // computing transformation
					}
					matrix4_op = new M4Rot(matrix4);
					mol2->applyAtoms(matrix4_op);
				}
				delta = fabs(score_old - score);
				//			printf("iter= %d  score= %f  old= %f\n",iter,score,score_old);
			}
			if(AlnFile.isSet())
				rmsd_f = mol->rmsd(mol2,maskmol,maskmol2);
			else
				rmsd_f = mol->rmsd(mol2);

			for(int i=0; i < num_atoms; i++)
				sum_w += prof_wrmsd[i];
			//		  printf(">> rmsd_i %.4f -> rmsd_f %.4f  wrmsd= %f %%match= %.2f iters= %d C= %.1f\n",rmsd_i,rmsd_f,score,100*(sum_w/num_atoms),iter,gauss_c.getValue());
			printf(" final %.4f  wrmsd= %f  %%Matching: atoms= %.2f  res= %.2f  iter= %d  C= %.1f\n",rmsd_f,score,100*(sum_w/num_atoms),100*(sum_w/num_res),iter,gauss_c.getValue());
		}
		else
			printf(" final %.4f\n",rmsd_f);


		if(pdb_moved.isSet())
		{
			if(!gauss.isSet()) // NO-Gauss (with Gauss, transformation was already applied)
			{
				M4Rot *matrix4_op=new M4Rot(matrix4);
				mol2->applyAtoms(matrix4_op); // superpose full-atom
				delete matrix4_op;
			}

			if(Dist.isSet())
//				mol->dist_profile(mol2,&prof2,maskmol,maskmol2);
			{
				if( CAlpha.isSet() || BBone.isSet() )
					mol_ca->dist_profile(mol2_ca,&prof2,maskmol,maskmol2);
				else
					mol->dist_profile(mol2,&prof2,maskmol,maskmol2);
			}

			strcpy(file_out,((temp=pdb_moved.getValue()).c_str()));
			mol2->writePDB(file_out);
			printf(">> Saved in %s\n", file_out);
		}

		if(Dist.isSet())
		{
			FILE *f_prof;
			if((f_prof=fopen(dist_profiles,"w"))==NULL)
			{
				fprintf(stderr, "\n Error opening file: %s\n\n",dist_profiles);
				exit(1);
			}

			pdbIter *it = new pdbIter(mol,false); // without SMol
			int num_res = it->num_fragment();
			delete it;
			// printf("Number of fragments: %d\n",num_res);
			if(pdb_moved.isSet())
			{
				fprintf(f_prof,"# Res  Before[A]   After[A]\n");
				for(int i=0; i < num_res; i++)
					fprintf(f_prof,"%5d %10f %10f\n",i+1,prof[i],prof2[i]);
				free(prof2);
			}
			else
			{
				fprintf(f_prof,"# Res  Before[A]\n");
				for(int i=0; i < num_res; i++)
					fprintf(f_prof,"%5d %10f\n",i+1,prof[i]);
			}
			fclose(f_prof);
			printf(">> Distance profile(s) saved in %s\n", dist_profiles);
			free(prof);
		}


		// END
	}
	catch ( ArgException& e )
	{
		std::cout << "  Error->" << e.error() << " " << e.argId() << std::endl;
	}
}

