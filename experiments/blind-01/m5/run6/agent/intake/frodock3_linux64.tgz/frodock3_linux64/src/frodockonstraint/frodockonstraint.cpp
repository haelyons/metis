#include <stdio.h>
#include <cmdl/CmdLine.h>


#include <libpdb/include/Macromolecule.h>
#include <libpdb/include/pdbIter.h>


inline vector<string> split(const string& str, const string& delim)
{
    vector<string> tokens;
    size_t prev = 0, pos = 0;
    do
    {
        pos = str.find(delim, prev);
        if (pos == string::npos) pos = str.length();
        string token = str.substr(prev, pos-prev);
        if (!token.empty()) tokens.push_back(token);
        prev = pos + delim.length();
    }
    while (pos < str.length() && prev < str.length());
    return tokens;
}


#define SWAP(a,b) temp=(a);(a)=(b);(b)=temp;

using namespace TCLAP;
using namespace std;

typedef float Triple[3];

typedef struct {
	int c1;
	char chain_c1;
	int c2;
	char chain_c2;
	float dist;
} constraint;

int num_elem;
char in_input[256],in_xorfiles[256],in_ligand[256];
bool in_old;
char in_receptor[256],in_constr[256],in_output[256], in_cons;

vector<string>  fileNamesXor;

bool in_eval=true;

void parseOptions(int argc, char** argv);

bool check_distance_res(Fragment * res1,Fragment *res2, float min_dist)
{
	bool contA,contA2;
	Atom *a,*a2;
	Tcoor pos_atom1,pos_atom2;
	float dist,min_dist2=min_dist*min_dist;
	bool first=true;

	contA = true;

	res1->initAll();
	while ( contA != false )
	{
		a = ( Atom * ) res1->getCurrent();
		a->getPosition(pos_atom1);

		res2->initAll();
		contA2=true;
		while( contA2 != false )
		{
			a2 = (Atom*) res2->getCurrent();
			a2->getPosition(pos_atom2);
			dist=(pos_atom2[0]-pos_atom1[0])*(pos_atom2[0]-pos_atom1[0])+
					(pos_atom2[1]-pos_atom1[1])*(pos_atom2[1]-pos_atom1[1])+
					(pos_atom2[2]-pos_atom1[2])*(pos_atom2[2]-pos_atom1[2]);

			if(dist<min_dist2)
				return true;

			contA2=res2->next();
		}
		contA=res1->next();
	}

	return false;
}


// Return "true" if constrain matched (found)
// fixed?
bool check_constrain(pdbIter *ligand,pdbIter *recpt,constraint constr) {
	// If both are "Any", then any solution should be OK...
	if(constr.c1 == -1 && constr.c2 == -1)
		return true;

	int init_l, end_l,init_r,end_r;
	int i,j;
	bool found=false;
	bool exitL=false;
	bool exitR=false;
	Fragment *res1,*res2;
	pdbIter *iter_fragL, *iter_fragR;
	Chain *ch, *ch2;

	int sel_Ch=-1;
	char in_chain='\0';

	// printf("constr.chain_c1= %c  constr.chain_c2= %c  constr.c1= %d  constr.c2= %d\n",constr.chain_c1,constr.chain_c2,constr.c1,constr.c2);

	// Search ligand residue and store it in "res1"
	if(constr.c1 != -1) // If ligand is not "Any"
	{
		for( ligand->pos_chain = 0; !ligand->gend_chain() && !exitL; ligand->next_chain() )
		{
			ch = ligand->get_chain();
			if ((ch->getName()[0]==constr.chain_c1)||(constr.c1==-1))
			{
				// run residues ch ligand
				iter_fragL = new pdbIter(ch);
				for( iter_fragL->pos_fragment = 0; !iter_fragL->gend_fragment() && !exitL; iter_fragL->next_fragment() )
				{
					res1=iter_fragL->get_fragment();
					// printf("res1=%s %d\n",res1->getName(),res1->getIdNumber());

					if (res1->getIdNumber() == constr.c1)
					{
						found = true; // ligand "res1" found
						exitL = true;
						break; // Break, "res1" will retain the correct residue
					}
				}
				delete iter_fragL;
			}
		}
		if(!found) // If not found, force exit!
		{
			printf("Msg(check_constrain): ligand residue not found! (chain= %c  index= %d)\n",constr.chain_c1,constr.c1);
			exit(2);
		}
	}
	found = false; // reset "found" flag

	// Search receptor residue and store it in "res1"
	if(constr.c2 != -1) // If receptor is not "Any"
	{
		// Search ligand residue and store it in "res1"
		for( recpt->pos_chain = 0; !recpt->gend_chain() && !exitR; recpt->next_chain() )
		{
			ch2 = recpt->get_chain();
			if ((ch2->getName()[0]==constr.chain_c2)||(constr.c2==-1))
			{
				// run residues ch2 recept
				iter_fragR = new pdbIter(ch2);
				for( iter_fragR->pos_fragment = 0; !iter_fragR->gend_fragment() && !exitR; iter_fragR->next_fragment() )
				{
					res2=iter_fragR->get_fragment();
					// printf("res2=%s %d\n",res2->getName(),res2->getIdNumber());

					if(res2->getIdNumber() == constr.c2)
					{
						found = true; // receptor "res2" found
						exitR = true;
						break; // Break, "res2" will retain the correct residue
					}
				}
				delete iter_fragR;
			}
		}
		if(!found) // If not found, force exit!
		{
			printf("Msg(check_constrain): receptor residue not found! (chain= %c  index= %d)\n",constr.chain_c2,constr.c2);
			exit(2);
		}
	}
	found = false; // reset "found" flag


	// If ligand is NOT "Any" and receptor is NOT "Any" --> direct check between res1 and res2 atoms
	if(constr.c1 != -1 && constr.c2 != -1)
		if(check_distance_res(res1,res2,constr.dist))
		{
			// printf("Distance ok\n");
			// printf("res1=%s %d\n",res1->getName(),res1->getIdNumber());
			// printf("res2=%s %d\n",res2->getName(),res2->getIdNumber());
			return true;
		}

	// If ligand is "Any" and receptor is NOT "Any" --> Screen ligand residues
	if(constr.c1 == -1 && constr.c2 != -1)
	{
		// printf("Ligand is Any and receptor is NOT Any --> Screen ligand residues\n");
		exitL = false;
		for( ligand->pos_chain = 0; !ligand->gend_chain() && !exitL; ligand->next_chain() )
		{
			ch = ligand->get_chain();
			if ((ch->getName()[0]==constr.chain_c1)||(constr.c1==-1))
			{
				// run residues ch ligand
				iter_fragL = new pdbIter(ch);
				for( iter_fragL->pos_fragment = 0; !iter_fragL->gend_fragment() && !exitL; iter_fragL->next_fragment() )
				{
					res1=iter_fragL->get_fragment();
					// printf("res1=%s %d\n",res1->getName(),res1->getIdNumber());

					if(check_distance_res(res1,res2,constr.dist))
					{
						// printf("Distance ok\n");
						// printf("res1=%s %d\n",res1->getName(),res1->getIdNumber());
						// printf("res2=%s %d\n",res2->getName(),res2->getIdNumber());
						found=true; // not return here, memory must be deallocated...
						exitL=true;
						break;
					}
				}
				delete iter_fragL;
			}
		}
	}

	// If receptor is "Any" and ligand is NOT "Any" --> Screen receptor residues
	if(constr.c1 != -1 && constr.c2 == -1)
	{
		// printf("If receptor is Any and ligand is NOT Any --> Screen receptor residues\n");
		exitR = false;
		for( recpt->pos_chain = 0; !recpt->gend_chain() && !exitR; recpt->next_chain() )
		{
			ch2 = recpt->get_chain();
			if ((ch2->getName()[0]==constr.chain_c2)||(constr.c2==-1))
			{
				// run residues ch2 recept
				iter_fragR = new pdbIter(ch2);
				for( iter_fragR->pos_fragment = 0; !iter_fragR->gend_fragment() && !exitR; iter_fragR->next_fragment() )
				{
					res2=iter_fragR->get_fragment();
					// printf("res2=%s %d\n",res2->getName(),res2->getIdNumber());

					if(check_distance_res(res1,res2,constr.dist))
					{
						// printf("Distance ok\n");
						// printf("res1=%s %d\n",res1->getName(),res1->getIdNumber());
						// printf("res2=%s %d\n",res2->getName(),res2->getIdNumber());
						found=true; // not return here, memory must be deallocated...
						exitR=true;
						break;
					}
				}
				delete iter_fragR;
			}
		}
	}

	return found;
}


// Return "true" if constrain matched (found)


int read_constrains(char *name,constraint *buff) {
	char line[100], chain_1, chain_2;
	int cont=0;
	FILE *f;
	char r1[12],r2[12]; // residue indices as text first to avoid bug...
	int c1,c2;
	float dist;
	f=fopen(name,"r");

	fgets(line,99,f);// Reads the whole file (line by line)
	fgets(line,99,f);// Reads the whole file (line by line)

	while(!feof(f))
	{
		//		fscanf(f,"%*s %c %d %*s %c %d %f\n",&chain_1,&c1,&chain_2,&c2,&dist);
		fscanf(f,"%*s %c %s %*s %s %s %f\n",&chain_1,r1,&chain_2,r2,&dist);
		if(r2[0] != '-')
			sscanf(r2,"%d",&c2);
		else
			c2=-1; // "Any"
		if(r1[0] != '-')
			sscanf(r1,"%d",&c1);
		else
			c1=-1; // "Any"
		buff[cont].c1=c2;
		buff[cont].c2=c1;

		if(chain_2 == '-')
			chain_2 = ' ';
		if(chain_1 == '-')
			chain_1 = ' ';
		buff[cont].chain_c1=chain_2;
		buff[cont].chain_c2=chain_1;
		buff[cont].dist=dist;
		fprintf(stdout,"fdkcons> INPUT: chain1 \"%c\" residue1 %d  chain2 \"%c\" residue2 %d  distance %f\n",buff[cont].chain_c1,buff[cont].c1,buff[cont].chain_c2,buff[cont].c2,buff[cont].dist );
		cont++;
	}

	fclose(f);
	return cont;
}


int main(int argc, char *argv[])
{
	parseOptions(argc, argv);

	float *buffer;
	bool *valid;
	constraint **buff_cons;
	int num_cons[10];
	int num_xor;
	int npeaksTotal = 0,i,j,cont=0;
	Tcoor original_center,invert_original_center;
	Triple s_rot,s_trans, euler;
	pdbIter * iter_recept,*iter_ligand;
	bool constraints;

	// Initialize aminoacids and nucleotids
	init_aminoacids();

	FILE *f=fopen(in_input,"rb");
	float center[3];

	fread(&npeaksTotal,  sizeof(int),  1, f);
	fprintf(stdout,"fdkcons>\nfdkcons> npeaksTotal= %d\n",npeaksTotal);
	if (in_old) {fread(&center[0],  sizeof(float),  3, f);
		    fprintf(stderr,"fdkcons>Center Lig %f %f %f\n", center[0],center[1],center[2]);
	}
	buffer=(float*)malloc(sizeof(float)*num_elem*npeaksTotal);
	valid=(bool*)malloc(sizeof(bool)*npeaksTotal);
	memset(valid,0,npeaksTotal*sizeof(bool));
	fread(buffer,sizeof(float),num_elem*npeaksTotal,f);
	fclose(f);

	num_xor=in_cons;


	buff_cons=(constraint**)malloc(sizeof(constraint*)*num_xor);
	for ( i = 0; i < num_xor ; i++) {
		buff_cons[i]=(constraint*)malloc(sizeof(constraint)*50);
	}

	// read constrains
	fprintf(stdout,"fdkcons> Constraint file %s\n",in_constr);

	num_cons[0]=read_constrains(in_constr,buff_cons[0]);

	// read Xor constrains files...
	for ( i = 1; i < num_xor ; i++) {
		strcpy(in_xorfiles,fileNamesXor[i-1].c_str());
		// fprintf(stdout,"fdkcons> Constrain Xor file%d %s\n",i, in_xorfiles);
		num_cons[i]=read_constrains(in_xorfiles,buff_cons[i]);
	}

	//
	//
	//	for ( i = 0; i < num_xor ; i++)
	//	fprintf(stdout,"num_xor= %d %d\n",i,num_cons[i]);

	Macromolecule *ligand=new Macromolecule();
	ligand->readPDB(in_ligand);
	//ligand->info(stdout);
	ligand->deleteHYDS();
	ligand->geoCenter( original_center );
	invert_original_center[0] = original_center[0] * ( -1.0 );
	invert_original_center[1] = original_center[1] * ( -1.0 );
	invert_original_center[2] = original_center[2] * ( -1.0 );
	ligand->moveAll( invert_original_center );
	Macromolecule *ligand_ref=new Macromolecule(ligand);
	iter_ligand=new pdbIter(ligand);

	Macromolecule *recpt=new Macromolecule();
	recpt->readPDB(in_receptor);
	//recpt->info(stdout);
	iter_recept=new pdbIter(recpt);


	for ( i = 0; i < npeaksTotal ; i++)
	{
		// printf("Searching peak %5d:\n",i);
		for(j=0;j<3;j++)
		{
			s_rot[j]=buffer[i*num_elem+j];
			s_trans[j]=buffer[i*num_elem+j+3];
		}

		euler[0]=s_rot[0]*(3.1415297/180.0);
		euler[1]=s_rot[1]*(3.1415297/180.0);
		euler[2]=s_rot[2]*(3.1415297/180.0);
		M4Rot *m4rot =new M4Rot(euler, 0,s_trans);
		ligand->applyAtoms(m4rot,ligand_ref);
		delete m4rot;

		constraints=true;


		for(int xorj=0;xorj<num_xor;xorj++) {

			// if constraint is fulfilled
			constraints=true;
			for(j=0;j<num_cons[xorj] && constraints;j++) // Iter constraints
			{
				if(!check_constrain(iter_ligand,iter_recept, buff_cons[xorj][j]))
				{
					constraints=false;
					break; // If just one constraint is not matched... then exit!
				}
			}

			if(constraints)
			{
				valid[i]=true;
				cont++;
				break;
				//fprintf(stderr,"encontrado %d\n",i);
			}

		}
	}

	fprintf(stdout,"fdkcons> Number of solutions=%d\nfdkcons>\n",cont);
	f=fopen(in_output,"wb");
	fwrite(&cont,sizeof(int),1,f);
	if (in_old) fwrite(&center[0],  sizeof(float),  3, f);
	cont=0;
	for ( i = 0; i < npeaksTotal ; i++)
	{
		if(valid[i])
		{
			fwrite(&(buffer[i*num_elem]),sizeof(float),num_elem,f);
		}
	}
	fclose(f);
}



void parseOptions(int argc, char** argv)
{
	string temp;
	CmdLine cmd(argv[0],"   ", "3.0" );

	try {
		//
		// Define required arguments no labeled
		//
		UnlabeledValueArg<string> input("input","input file","default","input");
		cmd.add( input );

		UnlabeledValueArg<string> receptor("receptor","receptor pdb file","default","receptor");
		cmd.add( receptor );

		UnlabeledValueArg<string> ligand("ligand","ligand pdb file","default","ligand");
		cmd.add( ligand );

		UnlabeledValueArg<string> constr("constrains","constrains file","default","constrains");
		cmd.add( constr );

		ValueArg < string > output( "o", "output", "output file with the best solutions per cluster", false, "constrains_output.dat", "string" );
		cmd.add( output );

		SwitchArg eval( "e", "evaluated", "file is previously evaluated", false );
		cmd.add( eval );

		ValueArg <string> xorfiles("","xor", "xor extra constrains file\n",false,"constrains file","string");
		cmd.add(xorfiles);

		SwitchArg old( "", "old", "Old format", false );
		cmd.add( old );

		// Parse the command line.
		cmd.parse(argc,argv);

		in_eval=eval.getValue();
		if(in_eval)
		{
			num_elem=11;
		}
		else
		{
			num_elem=7;
		}

		strcpy(in_input,((temp=input.getValue()).c_str()));
		strcpy(in_output,((temp=output.getValue()).c_str()));
		strcpy(in_ligand,((temp=ligand.getValue()).c_str()));
		strcpy(in_receptor,((temp=receptor.getValue()).c_str()));
		strcpy(in_constr,((temp=constr.getValue()).c_str()));
		// reading multiple constrains filer for XOR
		in_cons=1;
		if(xorfiles.isSet()) {
			strcpy(in_xorfiles,((temp=xorfiles.getValue()).c_str()));
			fileNamesXor = split(in_xorfiles, ",");
			in_cons +=fileNamesXor.size();
		}

		  if(old.isSet()) in_old=false;
				        else in_old=true;


	} catch ( ArgException& e )
	{
		cout << "  Error->" << e.error() << " " << e.argId() << endl;
	}
	//cmd.~CmdLine();

}
