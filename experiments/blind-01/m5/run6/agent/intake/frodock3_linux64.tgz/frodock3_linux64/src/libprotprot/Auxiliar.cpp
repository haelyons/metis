
#include <libvolume/include/floatops.h>
#include <libfrm/include/Correlation.h>
#include "Auxiliar.h"
#define gidz_general(posz,posy,posx,dimy,dimx) ((posz)*(dimx)*(dimy)+(posy)*(dimx)+(posx))



/**
 * Creation of a spherical objects from tridimensional volumes that represent different values related to a macromolecule.
 * Each spherical object will store a projecxtion of a value
 * The spherical objects will adapt its dimensions to the volume
 * The spherical objects are inverted, so positive values are negatives and negatives are positives. This is necessary for the external docking computation
 * It must be called after pre_volumetric_sampling() function. the positions to project are precomputed.
 *
 *@param vol: reference volume structure. It provides pointers to the different value volumes (weight, charge, ASA and desolvcation potential)
 *@param eval: Shows which spherical objects must be computed (true)
 *@param rmax: Number of the maximum layer in the spherical representation. It is computed from all the necessary values
 *@param rmin : Number of the minimum layer in the spherical representation. It is computed from all the necessary values
 *@param bw: Bandwidth. Grade of the spherical harmonic base
 *@param maxext: Maximum number of necessary layers for each volume value
 *@param cx,cy,cz: center position of the spherical representations (in voxels)
 *@param sph2: Initialized and empty spherical objects to fill up with the projections
 *@param sps: Precomputed collection of spherical positions to project
 *@param num: Number of precomputed positions
 */
vlSpherical ** volumetric_samplingN2( vlVolume ** vol,bool *eval, int * rmax, int * rmin, int bw, int *maxext, float cx, float cy, float cz,
     vlSpherical ** sph2,spherical_point *sps, int num )
     {
       /* performs the sampling in spherical coordinates */

       int i, j, r,k, size;
       /* longitude and latitude */
       float x, y, z;
       float a, b, c;
       int x1, y1, z1;
       int x2, y2, z2;
       int p_z1,p_z2, p_y1,p_y2;
       float f111, f112, f121, f122, f211, f212, f221, f222;
       float aux;
       float pointer[8];
       int g_extx=0, g_exty=0, g_extz=0;
	   int Maxext=0;
       int cont;

       //For each volume value needed
	   for(i=0;i<NUM_POT;i++)
       if(eval[i])
       {

    	//Initializations
    	if(g_extx < vol[i]->dim().x())
       		g_extx =vol[i]->dim().x();
       	if(g_exty < vol[i]->dim().y())
       		g_exty =vol[i]->dim().y();
       	if(g_extz < vol[i]->dim().z())
       		g_extz =vol[i]->dim().z();
       	if(Maxext<maxext[i])
       	{
       			Maxext=maxext[i];

       	}
       	rmax[i] = 0;
        rmin[i] = maxext[i];
       }

       size = ( bw << 1 );

       //Explore all the spherical positions
       for(cont=0;cont<num;cont++)
       {	r=sps[cont].r;
      		if(r<=Maxext)
      		{
	      		i=sps[cont].i;
	      		j=sps[cont].j;

	      		x=sps[cont].x +cx;
	      		y=sps[cont].y +cy;
	      		z=sps[cont].z +cz;

               // interpolation
               if ( x < 0.0 || x >= vol[0]->dim().x() - 1.0 || y < 0.0 || y >= vol[0]->dim().y() - 1.0 || z < 0.0
                || z >= vol[0]->dim().z() - 1.0 )
                {
            	// Do nothing
                //    sph->setP( r, i, j, 0.0 );
                }
			    else
			    {
			    	x1 = ( int )floor( x ); y1 = ( int )floor( y ); z1 = ( int )floor( z );
			    	a = x - x1; b = y - y1; c = z - z1;
			    	x2=x1+1;
			    	y2=y1+1;
			    	z2=z1+1;
			    	p_y1=y1*g_extx;
			    	p_y2=y2*g_extx;
			    	p_z1=z1*g_extx*g_exty;
			    	p_z2=z2*g_extx*g_exty;
			    	pointer[0]=p_z1+p_y1+x1;
		            pointer[1]=p_z2+p_y1+x1 ;
		            pointer[2]=p_z1+p_y2+x1 ;
		            pointer[3]=p_z2+p_y2+x1 ;
		            pointer[4]=p_z1+p_y1+x2 ;
		            pointer[5]=p_z2+p_y1+x2 ;
		            pointer[6]=p_z1+p_y2+x2 ;
		            pointer[7]=p_z2+p_y2+x2 ;

		           //For each volume value required
	               for(k=0;k<NUM_POT;k++)
	               {
	            	     if(eval[k] && r<maxext[k])
		       			 {
	            	    	 //fprintf(stderr,"empiezo %d maxext=%d\n",k,maxext[k]);

							 f111 = vol[k]->getVoxelSpecial(pointer[0]);
		       				 f112 = vol[k]->getVoxelSpecial(pointer[1]);
		       				 f121 = vol[k]->getVoxelSpecial(pointer[2]);
		       				 f122 = vol[k]->getVoxelSpecial(pointer[3]);
		       				 f211 = vol[k]->getVoxelSpecial(pointer[4]);
		       				 f212 = vol[k]->getVoxelSpecial(pointer[5]);
		       				 f221 = vol[k]->getVoxelSpecial(pointer[6]);
		       				 f222 = vol[k]->getVoxelSpecial(pointer[7]);
		       				 //fprintf(stderr,"flag0 %d\n",k);

							 if(f111!=0.0 || f112!=0.0 || f121!=0.0 || f122!=0.0 ||
									   f211!=0.0 || f212!=0.0 || f221!=0.0 || f222!=0.0 )
							 {

								 aux = ( ( 1 - a ) * ( ( 1 - b ) * ( ( 1 - c ) * f111 + c * f112 ) + b * ( ( 1 - c ) * f121 + c * f122 ) ) + a
			                    * ( ( 1 - b ) * ( ( 1 - c ) * f211 + c * f212 ) + b * ( ( 1 - c ) * f221 + c * f222 ) ) );
								 //Introduction of value in spherical object. -AUX is used in order4 to inverse the projection
								 //fprintf(stderr,"flag1 %d\n",k);
								/*if(k>=6)
								 {
									 if(aux>0.0)
										 aux*=10.0;
								 }*/
								 if(aux!=0.0)
									 sph2[k]->setP( r, i, j, -aux );
								 //fprintf(stderr,"flag2 %d\n",k);

								 //Maximum radius calculus
								 if ( aux != 0 && r >  rmax[k] ) rmax[k] = r;
								 //fprintf(stderr,"flag3 %d\n",k);

							 }
							 //fprintf(stderr,"fin %d\n",k);
		       			 }//if


	               }
       			 }//else


      		}

       }

       // minimum radius calculum
       for ( i = 0; i < size; i++ )
       {
         for ( j = 0; j < size; j++ )
         {
         	for(k=0;k<NUM_POT;k++)
       		if(eval[k])
       		{
           for ( r = 1; r < maxext[k]; r++ )
             if ( sph2[k]->getP( r, i, j ) != 0.0 )
             {
               if ( r < rmin[k] )
               {
                 rmin[k] = r;
                 break;
               }
             }
       		}
         }
       }

       return sph2;
}


/**
 * Creation of the collection of spherical positions where volume properties are projected.
 * It must be called once before calling volumetric_samplingN2
 *@param bw: Bandwidth. Grade of the spherical harmonic base
 *@param maxext: Maximum number of layers in the spherical representation
 *@param rho: Distance between layers in voxels
 *@param sps: Output. Computed collection of spherical positions to project
 *@return Number of precomputed positions
 */
int pre_volumetric_sampling(int bw,int maxext,float rho,spherical_point **sps)
{
	int i, j, r;
	float x,y,z;
	float lambda, theta, initlambda,st,ct,stsl,stcl;
	int size = ( bw << 1 );
	int num=0,cont=0;
	initlambda = M_PI / bw;

	num=size*size*maxext;

	*sps=(spherical_point*)malloc(sizeof(spherical_point)*num);

	for ( i = 0; i < size; i++ ) /* i represents latitude values */
	{
		theta = 0.5 * M_PI * ( i + 0.5 ) / bw;
    //time_elapsed2.restart();
    st = sin( theta ) * rho; ct = cos( theta ) * rho;
    //tiempo2+=time_elapsed2.elapsed();
    for ( j = 0, lambda = 0; j < size; j++, lambda += initlambda ) /* j represents longitude values */
    {
			//time_elapsed2.restart();
			stsl = st * sin( lambda ); stcl = st * cos( lambda );
			//tiempo2+=time_elapsed2.elapsed();
			for ( r = 0, x = 0, y = 0, z = 0; r < maxext; r++, x += stcl, y += stsl, z += ct ) //r=Distancia al centro
			{
				(*sps)[cont].i=i;
				(*sps)[cont].j=j;
				(*sps)[cont].r=r;

				(*sps)[cont].x=x;
				(*sps)[cont].y=y;
				(*sps)[cont].z=z;

				cont++;

			}
    }
  }

	return num;
}


/**
 * Computes the Integral in the Fourier space necessary to compute the correation
 *
 *@param integrali: buffer to store the imaginary part of the integral
 *@param integralr: buffer to store the real part of the integral
 *@param sph: spherical projection of one of the object to correlate
 *@param Mcoefr,Mcoefi: buffer to keep the spherical coefficients of the sph object
 *@param bw: Bandwidth. Grade of the spherical harmonic base
 *@param rmax: Number of the maximum layer in the spherical representation.
 *@param rmin: Number of the minimum layer in the spherical representation.
 *@param steprho: Distance between layers in amstrongs
 *@param SH_layerr,SH_layeri : Precomputed spherical harmonics of the second object to correlate
 *@param radius: radius of the layers in the second object
 */
void createIntegral(float *integrali, float *integralr,vlSpherical *sph,float **Mcoefr,float **Mcoefi,int bw, int rmax,int rmin,float steprho,float **SH_layerr,float **SH_layeri,float *radius)
{

  int init,init2;
  int l,m,n,aux,tl,i;
  int ind_coef,ind_i;
  int Rmin=rmin;
  float sphericalr,sphericali;
  float dist;
  int j;
  float rad;
	int ind_sh;
	float down,A,B,C,D;


  //Htimer t2;
  //t2.restart();

  // computation of spherical coefficients for the first object
  if (Rmin==0)
    Rmin=1;
  for(i=Rmin;i<=rmax;i++)
  {
     if(radius[i]!=0.0 || radius[i-1]!=0.0)
	 {
		 //fprintf(stderr,"radius2[%d]=%f radius2[%d]=%f\n",i,radius[i],i-1,radius[i-1]);
		 	 	 sph->sphCoef(i,Mcoefr[i],Mcoefi[i]);
		 //fprintf(stderr,"sph\n");

	 }
  }


	  //Combination of spherical coefficients
      init2=0;
      for(l=0, tl=0;l<bw;l++, tl+=2)
      {
        init=(l*(tl*tl-1)/3 + (l*l) )/2 ;
        init2+=l;
        for(m=l;m<=tl;m++)
        {
          ind_coef=seanindex(m-l,l,bw);

          ind_i=(init+(m-l)*(tl+1))+l;
          for(n=l,aux=0;n<=tl;n++,aux++)
          {
            //fprintf(stderr,"l=%d,m=%d,n=%d\n",l,m,n);
            for(i=Rmin;i<rmax;i++)
            {
              //fprintf(stderr,"atom=%d radius[%d]=%f\n",i,i,radius[i]);
              if(radius[i]!=0)
              {
                rad=radius[i];
                sphericalr=0.0;
                sphericali=0.0;
                j=i;
                dist=(rad-((float)j*steprho))/steprho;
                //fprintf(stderr,"dist=%f\n",dist);

                if(j>=0)
                {
                  if(j==0)
                  {
                   //fprintf(stderr,"Mcoefr=%f Mcoefi=%f",Mcoefr[j+1][ind_coef],Mcoefi[j+1][ind_coef]);
                   sphericalr=/*(1-dist)**/Mcoefr[j+1][ind_coef];
                   sphericali=/*(1-dist)**/Mcoefi[j+1][ind_coef];
                  }
                  else
                  {
                   if(j<rmax)
                   {
                    down =1.0-dist;
                    if((j+1)<rmax)
                    {
                      //fprintf(stderr,"Mcoefr=%f Mcoefi=%f",Mcoefr[j][ind_coef],Mcoefi[j][ind_coef]);
                      sphericalr=(down)*Mcoefr[j][ind_coef]
                            +(dist)*Mcoefr[j+1][ind_coef];
                      sphericali=(down)*Mcoefi[j][ind_coef]
                            +(dist)*Mcoefi[j+1][ind_coef];
                    }
                    else
                    {
                      //fprintf(stderr,"Mcoefr=%f Mcoefi=%f",Mcoefr[j][ind_coef],Mcoefi[j][ind_coef]);
                      sphericalr=(down)*Mcoefr[j][ind_coef];
                      sphericali=(down)*Mcoefi[j][ind_coef];
                    }
                   }
                  }
                }
                //fprintf(stderr,"atom2=%d\n",i);
				ind_sh=init2+aux;
				A=(float)(SH_layerr[i][ind_sh]*sphericalr);
				B=(float)(SH_layeri[i][ind_sh]*sphericali);
				C=(float)(SH_layeri[i][ind_sh]*sphericalr);
				D=(float)(SH_layerr[i][ind_sh]*sphericali);

				*(integralr+ind_i+(n-l)) +=A-B;
        		*(integrali+ind_i+(n-l)) +=C+D;
				if(n!=l)
            	{
					if((n-l)%2!=0)
              		{
              			*(integralr+ind_i-(n-l)) +=(-A)-B;
          				*(integrali+ind_i-(n-l)) +=C-D;
              		}
              		else
              		{
              			*(integralr+ind_i-(n-l)) +=A+B;
          				*(integrali+ind_i-(n-l)) +=(-C)+D;
              		}
           		}
              }
            }
          }//j
        }//i
      }//l
 }



