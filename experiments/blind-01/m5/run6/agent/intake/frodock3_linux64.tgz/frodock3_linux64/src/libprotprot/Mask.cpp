#include "include/Mask.h"
#include <libfrm/include/obj_vlsphh.h>



Mask::Mask(Macromolecule *ligand, float radiusMax_lig_amstrongs, int bw, EVolumes *evol,float limitMinMask,float limitMaxMask)
{

	float voxSize= evol->get_voxSize();

	int voxel_lig_in[2], voxel_lig_out[2], voxel_zero_layer[2];
	float voxel_lig_out2[2];
	int radiusMax_lig_voxel = (int)floor((radiusMax_lig_amstrongs) / voxSize);
	float dilateMax,dilateMin;
	int dilate_pad;
	vlPoint3f origin_mask1, origin_mask2;
	int msk_dim_max;
	int limitMax_mask; //Distancia maxima de la mascara
	float center[3];

  //calculo de las dimensiones maxima y minima del ligando
  increase_voxel = 1;
  //Si el tamño del ligando es muy grande se aumenta el tamaño de voxel para calcular dimensiones
  if ( radiusMax_lig_amstrongs * 2 > 300 )
  {
    increase_voxel = ( radiusMax_lig_amstrongs * 2 ) / 300.0;
    fprintf( stderr, "warning increase_voxel=%f %f\n",increase_voxel,radiusMax_lig_amstrongs);

  }
  //fprintf( stderr, "flag2 increase_voxel=%f %f\n",increase_voxel,radiusMax_lig_amstrongs);
  vlVolume * volAux = ligand->projectSurface( voxSize * increase_voxel, 4.0 );




  //FOPS::center_masses( volAux, & cx_lo_aux, & cy_lo_aux, & cz_lo_aux );
	FOPS::center_vol(volAux, center);
	cx_lo_aux=center[0];
	cy_lo_aux=center[1];
	cz_lo_aux=center[2];
	//fprintf(stderr,"center aux=%f, %f, %f\n",cx_lo_aux,cy_lo_aux,cz_lo_aux);

  vlSpherical * sphkk = FOPS::volumetric_sampling_slow( volAux, voxel_lig_in, voxel_lig_out, voxel_zero_layer, bw, radiusMax_lig_voxel,
  							cx_lo_aux, cy_lo_aux, cz_lo_aux,1.0 );

  //sphkk->preComputation();
	//sphkk->free_preComputation();

  voxel_lig_out2[1] = voxel_lig_out[1]*increase_voxel;
  //voxel_lig_out2[1] = radiusMax_lig_voxel;
  voxel_lig_out2[0] = voxel_lig_out[0]*increase_voxel;

	delete sphkk;
  //FOPS::writeFile( volAux, "maski0.ccp4" );
  delete volAux;
  //fprintf( stderr, "adp_pp> Maximum size of the PDB(in amstrongs): %f\n", voxel_lig_out2[1] * voxSize );
  //fprintf( stderr, "adp_pp> Minimum size of the PDB:(in amstrongs) %f\n", voxel_lig_out2[0] * voxSize );

  //Calculo de los limites maximo y minimo de la mascara
	  dilate_pad = ( int )ceil( voxel_lig_out2[1] + 1.0 );
	  dilateMax = voxel_lig_out2[1] - ( int )ceil( limitMaxMask * voxel_lig_out2[1] );
//  dilateMin = voxel_lig_out[0] - ( int )ceil( 0.2 * voxel_lig_out[0] );
    dilateMin = voxel_lig_out2[0] - ( int )ceil( limitMinMask * voxel_lig_out2[0] );
  //dilate_pad = ( int )ceil( dilateMax + 1.0 );

    //fprintf(stdout,"dilateMax=%f voxel_lig_out[1]=%f limitMaxMask=%f\n",dilateMax,voxel_lig_out2[1],limitMaxMask);
    //fprintf(stdout,"dilateMin=%f voxel_lig_out[0]=%f limitMinMask=%f\n",dilateMin,voxel_lig_out2[0],limitMinMask);

    if(dilateMax<=dilateMin)
    {
    	fprintf(stdout,"Error: mask empty. lmax and lmin parameters not valid. Max limit=%f Min limit=%f\n",dilateMax,dilateMin);
    	exit(1);
    }


  //Creacion de mascara
  msk = FOPS::createMask( evol->vol_lo[0], 5.0 );//antes 4
  //FOPS::writeFile( msk, "maski.ccp4" );

  //fprintf(stderr,"vol: %d %d %d\n",msk->dim().x(),msk->dim().y(),msk->dim().z());
  msk = FOPS::crop( msk, 0.001, true );
  //fprintf(stderr,"vol tras crop: %d %d %d\n",msk->dim().x(),msk->dim().y(),msk->dim().z());
  msk = FOPS::padVolume( msk, vlDim( dilate_pad, dilate_pad, dilate_pad ), true );
  msk->getPosition( & origin_mask1 );
  //fprintf(stderr,"vol tras pad: %d %d %d\n",msk->dim().x(),msk->dim().y(),msk->dim().z());
  if ( msk->dim().x() > msk->dim().y() && msk->dim().x() > msk->dim().z() )
    msk_dim_max = msk->dim().x();
  else if ( msk->dim().y() > msk->dim().z() )
    msk_dim_max = msk->dim().y();
  else
    msk_dim_max = msk->dim().z();

  increase_voxel = 1;
  //Si la mascara es muy grande se reduce aumentando el tamaño del voxel
  if ( msk_dim_max > 400 )
  {

    // getchar();
    increase_voxel = ( float )( msk_dim_max ) / 400.0;
	printf("Warning increasing mask voxel size not tested!! %f\n",increase_voxel);
    vlUnit newUnit( msk->units().x() * increase_voxel, msk->units().y() * increase_voxel, msk->units().z() * increase_voxel );
    msk = FOPS::interpolate_map( msk, newUnit, true );
    dilateMax /= increase_voxel;
    dilateMin /= increase_voxel;
  }


  //ATENCION. En estas funciones hay un error de redondeo en el cluster
  //Limite maximo de la mascara
  vlVolume * mskH = FOPS::projectSurface( msk, dilateMax );
  //fprintf(stderr,"POINTS H:%d\n",FOPS::count_points(mskH, 0.5));

  //Limite minimo de la mascara
  vlVolume * mskL = FOPS::projectSurface( msk, dilateMin );
  //fprintf(stderr,"POINTS L:%d\n",FOPS::count_points(mskL, 0.5));

  delete msk;
  FOPS::mul( mskL, -1 );
  FOPS::add( mskH, mskL );
  delete mskL;
  msk = mskH;

  msk = FOPS::crop( msk, 0.0001, true );
  msk->getPosition( & origin_mask2 );



  //FOPS::center_masses( msk, & cx_lo_aux, & cy_lo_aux, & cz_lo_aux );

	FOPS::center_vol(msk, center);
	cx_lo_aux=center[0];
	cy_lo_aux=center[1];
	cz_lo_aux=center[2];
	//printf("MASK center 1: %f %f %f\n",cx_lo_aux,  cy_lo_aux, cz_lo_aux);
	//printf("MASK origin 1: %f %f %f\n",origin_mask2.x(),  origin_mask2.y(), origin_mask2.z());
	//printf("MASK center 2: %f %f %f\n",cx_lo_aux+origin_mask2.x(), cy_lo_aux+ origin_mask2.y(), cz_lo_aux+ origin_mask2.z());

  //Desplazamiento de la mascara con respecto al volumen
  mask_offset[0] = (int)floor( origin_mask1.x() - origin_mask2.x()  / voxSize);
  mask_offset[1] = (int)floor( origin_mask1.y() - origin_mask2.y()  / voxSize);
  mask_offset[2] = (int)floor( origin_mask1.z() - origin_mask2.z()  / voxSize);

	// printf("MASK Offset 3: %d %d %d\n",  mask_offset[0],    mask_offset[1],   mask_offset[2]);


  if(msk->dim().x()>=msk->dim().y() && msk->dim().x()>=msk->dim().z())
  	limitMax_mask = msk->dim().x() / 2 + msk->dim().x() % 2;

  if(msk->dim().y()>=msk->dim().x() && msk->dim().y()>=msk->dim().z())
  	limitMax_mask = msk->dim().y() / 2 + msk->dim().y() % 2;

  if(msk->dim().z()>=msk->dim().y() && msk->dim().z()>=msk->dim().x())
  	limitMax_mask = msk->dim().z() / 2 + msk->dim().z() % 2;

  limitMax = ( int )( ceil( ( float )limitMax_mask * increase_voxel ) );
   // fprintf(stderr,"vol final: %d %d %d\n",msk->dim().x(),msk->dim().y(),msk->dim().z());
  // FOPS::writeFile( msk, "maski.sit" );
}

/*
Mask::Mask(Macromolecule *ligand, float radiusMax_lig_amstrongs, int bw, EVolumes *evol,float limitMinMask,float limitMaxMask)
{

	float voxSize= evol->get_voxSize();

	int voxel_lig_in[2], voxel_lig_out[2], voxel_zero_layer[2];
	float voxel_lig_out2[2];
	int radiusMax_lig_voxel = (int)floor((radiusMax_lig_amstrongs) / voxSize);
	float dilateMax,dilateMin;
	int dilate_pad;
	vlPoint3f origin_mask1, origin_mask2;
	int msk_dim_max;
	int limitMax_mask; //Distancia maxima de la mascara
	float center[3];

  //calculo de las dimensiones maxima y minima del ligando
  increase_voxel = 1;
  //Si el tamño del ligando es muy grande se aumenta el tamaño de voxel para calcular dimensiones
  if ( radiusMax_lig_amstrongs * 2 > 300 )
  {
    increase_voxel = ( radiusMax_lig_amstrongs * 2 ) / 300.0;
  }


  int Mavoxel_lig_out2 = 0;
  for (int i=1;i<2;i++) {

	  Tcoor original_center;
	  float euler[3], invert_original_center[3];

	  //Compute center
	  ligand->geoCenter( original_center );
	  invert_original_center[0] = original_center[0] * ( -1.0 );
	  invert_original_center[1] = original_center[1] * ( -1.0 );
	  invert_original_center[2] = original_center[2] * ( -1.0 );
	  //fprintf(stdout,"emt_pdb> Center at %f %f %f\n",original_center[0],original_center[1],original_center[2]);

	  //fprintf(stdout,"emt_pdb> Moving PDB.wait a moment...\n");

	  //Movement to the center of coordinates (necessary for rotation)
	  //ligand->moveAll( invert_original_center );
	 // printf("%s> original center: %f %f %f\n",argv[0],original_center[0],original_center[1],original_center[2]);

	  //Rotation
	  euler[0]= 2*(-0.5+(float)rand()/(float) RAND_MAX) * 3.1415297;
	  euler[1]= 2*(-0.5+(float)rand()/(float) RAND_MAX) * 3.1415297;
	  euler[2]= 2*(-0.5+(float)rand()/(float) RAND_MAX) * 3.1415297;
	  EulerRot *rot=new EulerRot(euler[0],euler[1],euler[2],0);
      //printf("%s> rot: %f %f %f\n",euler[0]*180/3.1415297,euler[1]*180/3.1415297,euler[2]*180/3.1415297);

	  //ligand->applyAtoms(rot);




   //fprintf( stderr, "flag2 increase_voxel=%f %f\n",increase_voxel,radiusMax_lig_amstrongs);
    vlVolume * volAux = ligand->projectSurface( voxSize * increase_voxel, 4.0 );
    //FOPS::writeFile(volAux,"surf.sit");

//    FILE *f;
//    f=fopen("kaka.sit", "w");
//
//    float buf;
//    vlPoint3ui pos;
//    vlPoint3f ori;
//    volAux->getPosition(&ori);
//
//    fprintf(f,"%f %f %f %f %d %d %d\n", volAux->units().x(), ori.x(), ori.y(), ori.z(), volAux->dim().x(),volAux->dim().y(), volAux->dim().z());
//    for(int m=0;m<volAux->dim().x();m++)
//    	for (int n=0;n<volAux->dim().y();n++)
//    		for (int k=0;k<volAux->dim().z();k++)
//    		{
//    			pos.x(m),pos.y(n),pos.z(k);
//    			volAux->getVoxel(pos, buf);
//    			fprintf(f,"%f ", buf);
//    		}
//    fclose(f);



  //FOPS::center_masses( volAux, & cx_lo_aux, & cy_lo_aux, & cz_lo_aux );
	FOPS::center_vol(volAux, center);
	cx_lo_aux=center[0];
	cy_lo_aux=center[1];
	cz_lo_aux=center[2];
	//fprintf(stderr,"center=%f, %f, %f\n",cx_lo_aux,cy_lo_aux,cz_lo_aux);

  vlSpherical * sphkk = FOPS::volumetric_sampling_slow( volAux, voxel_lig_in, voxel_lig_out, voxel_zero_layer, bw, radiusMax_lig_voxel,
  							cx_lo_aux, cy_lo_aux, cz_lo_aux,1.0 );

  //sphkk->preComputation();
	//sphkk->free_preComputation();


  if (Mavoxel_lig_out2<voxel_lig_out[0]) Mavoxel_lig_out2=voxel_lig_out[0];


  voxel_lig_out2[1] = voxel_lig_out[1]*increase_voxel;
  //voxel_lig_out2[1] = radiusMax_lig_voxel;
  voxel_lig_out2[0] = voxel_lig_out[0]*increase_voxel;

	delete sphkk;
  //FOPS::writeFile( volAux, "maski0.ccp4" );
  delete volAux;
//  fprintf( stderr, "adp_pp> Maximum size of the PDB(in amstrongs): %f\n", voxel_lig_out2[1] * voxSize );
//  fprintf( stderr, "adp_pp> Minimum size of the PDB:(in amstrongs) %f\n", voxel_lig_out2[0] * voxSize );
  }

    voxel_lig_out2[1] = voxel_lig_out[1]*increase_voxel;
    //voxel_lig_out2[1] = radiusMax_lig_voxel;
    voxel_lig_out2[0] = Mavoxel_lig_out2*increase_voxel;


    fprintf( stderr, "adp_pp> Maximum size of the PDB(in amstrongs): %f\n", voxel_lig_out2[1] * voxSize );
    fprintf( stderr, "adp_pp> Minimum size of the PDB:(in amstrongs) %f\n", voxel_lig_out2[0] * voxSize );

  //Calculo de los limites maximo y minimo de la mascara
	  dilate_pad = ( int )ceil( voxel_lig_out2[1] + 1.0 );
	  dilateMax = voxel_lig_out2[1] - ( int )ceil( limitMaxMask * voxel_lig_out2[1] );
//  dilateMin = voxel_lig_out[0] - ( int )ceil( 0.2 * voxel_lig_out[0] );
    dilateMin = voxel_lig_out2[0] - ( int )ceil( limitMinMask * voxel_lig_out2[0] );
  //dilate_pad = ( int )ceil( dilateMax + 1.0 );

    fprintf(stdout,"dilateMax=%f voxel_lig_out[1]=%f limitMaxMask=%f\n",dilateMax,voxel_lig_out2[1],limitMaxMask);
    fprintf(stdout,"dilateMin=%f voxel_lig_out[0]=%f limitMinMask=%f\n",dilateMin,voxel_lig_out2[0],limitMinMask);




    if(dilateMax<=dilateMin)
    {
    	fprintf(stdout,"Error: mask empty. lmax and lmin parameters not valid. Max limit=%f Min limit=%f\n",dilateMax,dilateMin);
    	exit(1);
    }


  //Creacion de mascara
  msk = FOPS::createMask( evol->vol_lo[0], 5.0 );//antes 4
  //FOPS::writeFile( msk, "maski.ccp4" );
  msk->getPosition( & origin_mask1 );
  //fprintf(stderr,"vol: %d %d %d\n",msk->dim().x(),msk->dim().y(),msk->dim().z());
  msk = FOPS::crop( msk, 0.001, true );
  //fprintf(stderr,"vol tras crop: %d %d %d\n",msk->dim().x(),msk->dim().y(),msk->dim().z());
  msk = FOPS::padVolume( msk, vlDim( dilate_pad, dilate_pad, dilate_pad ), true );
  //fprintf(stderr,"vol tras pad: %d %d %d\n",msk->dim().x(),msk->dim().y(),msk->dim().z());
  if ( msk->dim().x() > msk->dim().y() && msk->dim().x() > msk->dim().z() )
    msk_dim_max = msk->dim().x();
  else if ( msk->dim().y() > msk->dim().z() )
    msk_dim_max = msk->dim().y();
  else
    msk_dim_max = msk->dim().z();

  increase_voxel = 1;
  //Si la mascara es muy grande se reduce aumentando el tamaño del voxel
  if ( msk_dim_max > 300 )
  {

    // getchar();
    increase_voxel = ( float )( msk_dim_max ) / 300.0;
    vlUnit newUnit( msk->units().x() * increase_voxel, msk->units().y() * increase_voxel, msk->units().z() * increase_voxel );
    msk = FOPS::interpolate_map( msk, newUnit, true );
    dilateMax /= increase_voxel;
    dilateMin /= increase_voxel;
  }


  //ATENCION. En estas funciones hay un error de redondeo en el cluster
  //Limite maximo de la mascara
  vlVolume * mskH = FOPS::projectSurface( msk, dilateMax );
  //fprintf(stderr,"POINTS H:%d\n",FOPS::count_points(mskH, 0.5));

  //Limite minimo de la mascara
  vlVolume * mskL = FOPS::projectSurface( msk, dilateMin );
  //fprintf(stderr,"POINTS L:%d\n",FOPS::count_points(mskL, 0.5));

  delete msk;
  FOPS::mul( mskL, -1 );
  FOPS::add( mskH, mskL );
  delete mskL;
  msk = mskH;

  msk = FOPS::crop( msk, 0.0001, true );
  msk->getPosition( & origin_mask2 );



  //FOPS::center_masses( msk, & cx_lo_aux, & cy_lo_aux, & cz_lo_aux );

	FOPS::center_vol(msk, center);
	cx_lo_aux=center[0];
	cy_lo_aux=center[1];
	cz_lo_aux=center[2];
	//printf("MASK center 1: %f %f %f\n",cx_lo_aux,  cy_lo_aux, cz_lo_aux);
	//printf("MASK center 2: %f %f %f\n",center[0],  center[1], center[2]);

  //Desplazamiento de la mascara con respecto al volumen
  mask_offset[0] = (int)floor( origin_mask1.x() - origin_mask2.x()  / voxSize);
  mask_offset[1] = (int)floor( origin_mask1.y() - origin_mask2.y()  / voxSize);
  mask_offset[2] = (int)floor( origin_mask1.z() - origin_mask2.z()  / voxSize);

  if(msk->dim().x()>=msk->dim().y() && msk->dim().x()>=msk->dim().z())
  	limitMax_mask = msk->dim().x() / 2 + msk->dim().x() % 2;

  if(msk->dim().y()>=msk->dim().x() && msk->dim().y()>=msk->dim().z())
  	limitMax_mask = msk->dim().y() / 2 + msk->dim().y() % 2;

  if(msk->dim().z()>=msk->dim().y() && msk->dim().z()>=msk->dim().x())
  	limitMax_mask = msk->dim().z() / 2 + msk->dim().z() % 2;

  limitMax = ( int )( ceil( ( float )limitMax_mask * increase_voxel ) );
    fprintf(stderr,"vol final: %d %d %d\n",msk->dim().x(),msk->dim().y(),msk->dim().z());
	FOPS::writeFile( msk, "maski2.ccp4" );
}
*/

Mask::~Mask()
{
	delete msk;
}

PCollection* Mask::find_points(float stepsize_voxel, float *c_lo_voxel)
{
	int kts,jts,its,nts;
	int istep;
	float Xpoint_voxels, Ypoint_voxels, Zpoint_voxels;
	float Xpoint_voxels_mask, Ypoint_voxels_mask, Zpoint_voxels_mask;

	PCollection *pc=new PCollection(stepsize_voxel);
	Tcoor point;

	//FILE *f=fopen("kk.txt","wt");
	//fprintf(stderr,"center lo=%f, %f, %f\n",c_lo_voxel[0],c_lo_voxel[1],c_lo_voxel[2]);
	//fprintf(stderr,"center aux=%f, %f, %f\n",cx_lo_aux,cy_lo_aux,cz_lo_aux);



	for ( nts = ( int )ceil( ( limitMax + 1 ) / stepsize_voxel ); nts >= 0; nts-- )
  {
    for ( kts = -nts; kts <= nts; kts++ )
      for ( jts = -nts; jts <= nts; jts++ )
      {
        if ( abs( jts ) < nts && abs( kts ) < nts ) istep = ( nts << 1 );
        else
          istep = 1;
        for ( its = -nts; its <= nts; its += istep )
        {
          point[0] = ( ( float )its * stepsize_voxel );
          point[1] = ( ( float )jts * stepsize_voxel );
          point[2] = ( ( float )kts * stepsize_voxel );


          Xpoint_voxels_mask = point[0] / increase_voxel;
          Ypoint_voxels_mask = point[1] / increase_voxel;
          Zpoint_voxels_mask = point[2] / increase_voxel;

          point[0] += c_lo_voxel[0];
          point[1] += c_lo_voxel[1];
          point[2] += c_lo_voxel[2];


          Xpoint_voxels_mask += cx_lo_aux;
          Ypoint_voxels_mask += cy_lo_aux;
          Zpoint_voxels_mask += cz_lo_aux;


          //Si la posicion esta dentro de la mascara se explora
          if ( FOPS::inMask( msk,
               vlPoint3i( ( int )( Xpoint_voxels_mask ), ( int )( Ypoint_voxels_mask ), ( int )( Zpoint_voxels_mask ) ) ) )
               {
               		pc->Insert_point(point);
               		//fprintf(f,"point=%f %f %f\n",point[0],point[1],point[2]);
               }

				}
      }
  }
	//fclose(f);
	return pc;
}

void Mask::around(Tcoor pos, float radius)
{

	Tcoor map_pos;
	vlPoint3f orig;
	Tcoor point;
	float zero=0.0;
	float limit2=radius*radius;
	float dist;

	int x,y,z;
	msk->getPosition(&orig);
	map_pos[0]=pos[0]-orig.x();
	map_pos[1]=pos[1]-orig.y();
	map_pos[2]=pos[2]-orig.z();

	for(x=0;x<msk->dim().x();x++)
	for(y=0;y<msk->dim().y();y++)
	for(z=0;z<msk->dim().z();z++)
	{
		if(FOPS::inMask( msk,vlPoint3i(x,y,z ) ) )
		{
			point[0]=x*msk->units().x();
			point[1]=y*msk->units().x();
			point[2]=z*msk->units().x();

			dist=((map_pos[0]-point[0])*(map_pos[0]-point[0]))+
					 ((map_pos[1]-point[1])*(map_pos[1]-point[1]))+
					 ((map_pos[2]-point[2])*(map_pos[2]-point[2]));

			if(dist>limit2)
				msk->setVoxel( vlPoint3ui(x,y,z ),zero);
		}
	}




}

