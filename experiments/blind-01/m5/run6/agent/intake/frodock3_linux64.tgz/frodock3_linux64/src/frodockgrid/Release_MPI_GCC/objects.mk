################################################################################
# Automatically-generated file. Do not edit!
################################################################################

USER_OBJS :=

LIBS := -lsas_gcc -lvolume_gcc -lpdb_gcc -ltools_gcc

