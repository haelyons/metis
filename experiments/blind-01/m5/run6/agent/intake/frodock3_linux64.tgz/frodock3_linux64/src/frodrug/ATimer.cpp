#include "ATimer.h"

#ifdef _WIN32
// Windows version of the timer
void ATimer::startTimer(){
    QueryPerformanceCounter(&start);
}

void ATimer::stopTimer(){
    QueryPerformanceCounter(&stop);
}

double ATimer::getElapsedTime(){
	LARGE_INTEGER time;
	time.QuadPart = stop.QuadPart - start.QuadPart;
    return ((double)time.QuadPart /(double)frequency.QuadPart);
}

ATimer::ATimer(){
	total = 0.0;
	QueryPerformanceFrequency(&frequency);
}

#else
// Linux version of the timer
void ATimer::startTimer(){
    clock_gettime(CLOCK_REALTIME,&start);
}

void ATimer::stopTimer(){
    clock_gettime(CLOCK_REALTIME,&stop);
}

double ATimer::getElapsedTime(){
	double elapsed;
	return (double)(stop.tv_sec - start.tv_sec) + (double)(stop.tv_nsec - start.tv_nsec) / 1000000000.0;
}

ATimer::ATimer(){
	total = 0.0;
}
#endif

// Common methods between platforms
void ATimer::addElapsedTime(){
	total += getElapsedTime();
}

double ATimer::getTotalTime(){
	return total;
}

void ATimer::resetTotalTime(){
	total = 0.0;
}

