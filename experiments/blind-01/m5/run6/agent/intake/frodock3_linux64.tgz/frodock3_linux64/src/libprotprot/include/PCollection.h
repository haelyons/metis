#ifndef PCOLLECTION_H_
#define PCOLLECTION_H_


#include "libpdb/include/CommonTypes.h"

/**
 * This class stores a collection of points to translate a ligand in a prot-prot docking
 */
class PCollection {
public:
	///Collection of points
	Tcoor *points;
	///Search step
	float stepsize;
	///Number of points
	int num;

public:
	/**
	 * Constructor
	 * @param in_stepsize: Search step
	 */
	PCollection(float in_stepsize=0);
	/**
	 * Constructor. Creates the object from a file (OBSOLETE??)
	 * @param file: Input file
	 * @param max: Number of points to read from file
	 * @param in_stepsize: Search step
	 * @param voxsize: mask volume voxel size
	 * @origin: mask origin
	 */
	PCollection(char *filename,int max,Tcoor origin, float voxsize,float in_stepsize);
	/**
	 * Destructor
	 */
	~PCollection();
	/**
	 * Introduces a new position in the collection
	 * @param point: new position to introduce
	 */
	void Insert_point(Tcoor point);
	/**
	 * Returns a position stored in the collection
	 * @param pos: Position in the collection
	 * @param point: Output position
	 */
	int return_point(int pos, Tcoor point);
	/**
	 * Returns an object with a segment of thec positions
	 * @param pieces: Number of segments
	 * @param piece: Segment to return
	 */
	PCollection *split(int pieces, int piece);

	/**
	 * Stores all the information about the object in a file
	 * @param name: filename
	 */
	void writeFile(char *name);
	/**
	 * Stores all the information about the object in a file
	 * @param name: filename
	 */
	void readFile(char *name);
	/**
	 * Establishes points around a position
	 * @param x,y,z: Center position
	 * @param step: search stepsize
	 * @param inter: radius around the center position
	 */
	void around(float x, float y, float z, float step, float inter);

};

#endif /*PCOLLECTION_H_*/
