/***************************************************************************
                          vlFrm.h  -  description
                             -------------------
    begin                : Fri Oct 1 2004
    copyright            : (C) 2004 by Jose Ignacio Garzon
    email                : -D VOLUME_INCLUDED
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
#ifndef _OBJ_VLSPHH_H
#define _OBJ_VLSPHH_H

#include <fftw3.h>
//#include "s2kit10/FST_semi_memo.h"

#define Sphfloat float

#include <libvolume/include/vldefine.h>

extern void FST_semi_memo( Sphfloat *, Sphfloat *,Sphfloat *, Sphfloat *,int , Sphfloat **,
           Sphfloat *,int ,int ,fftwf_plan *,fftwf_plan *,Sphfloat * );

extern void makeweights( int ,
                Sphfloat * ) ;



extern Sphfloat **SemiNaive_Naive_Pml_Table( int ,int ,Sphfloat * ,Sphfloat * ) ;

extern int Reduced_SpharmonicTableSize( int ,int ) ;

extern int Reduced_Naive_TableSize( int ,int ) ;



/**
* Collection of dd coeficients. These coefficients are necessary for computing
* the integral IMMP
*/
class vlDCoef {
public:
  ///Simple Constructor
  vlDCoef();
  /**
  * Constructor
  *
  * @param bw2: Bandwidth
  * @param theta: Agrhhhn!
  */
  vlDCoef(int bw2, float theta);

  ///Destructor
  ~vlDCoef();
  /**
  * Return a dd coefficent for a given position
  *
  * @param l: coefficcient's Shperical harmonic
  * @param m,n: coordinates
  */
  float get(int l,int m,int n);
  /**
  * Retrun a dd Coefficient for a given position in the list
  *
  * @param index: Position in the list
  */
  float inline get(unsigned long index){  return ddd[index];};
  /**
  * Write the collection to a file
  *
  * @param out: pointer to the FILE
  */
  bool writef(char *out);
  /**
  * Read the collection to a file
  *
  * @param in: pointer to the FILE
  */
  bool readf(char *in);

private:
  ///Coefficient Buffer
  float *ddd;
  ///Bandwidth of the Sperical Harmonics
  int bw;
};

/**
* Collection of Legendre coefficients
*/
class vlLegendre{
public:
  /**
  * Simple Constructor
  */
  vlLegendre();
  /**
  * Constructor
  */
  vlLegendre(int bwp, int bxp);

/**
* Destructor
*/
  ~vlLegendre();

/**
* return a coefficient
*/
  float inline get(int l,int n,int val)
  {
    return(*(dd0+(l*(l+1)+n)+(val<<tlb)));
  }

private:
  ///Coefficient buffer
  float *dd0;
  ///Buffer data
  int bw,bx,tlb;

};


/**
 * Spherical representation class
 * It maintains a buffer with values for polar coordinates.
 *
 * It also allows the computation of associated spherical harmonics
 */
class vlSpherical
{


  public:
    /**
     * Constructor
     *
     * @param bw: Bandwidht of the representation
     * @param r: Number of spherical layers
     */
	vlSpherical(int bw,int r);
	/**
	 * Destructor
	 */
	~vlSpherical();

	/**
	 * Free and realloc the spherical buffer
	 * @param bw2: New Bandwidht of the representation
     * @param r: New Number of spherical layers
 	 */
    void reset_vlSpherical(int bw2,int r);

    /**
     * Clean the spherical buffer
     */
    void clear();

    /**
     * Returns an spherical position
     *
     * @param r: layer position
     * @param lat: latitude position (< 2*bw)
     * @param lon: Longitude position (< 2*bw)
     * @output returned value
     */
    inline Sphfloat getP(int r, int lat, int lon)
    {

      return m[r][lat*size+lon];
    };

    /**
     * sets a value in an spherical position
     *
     * @param r: layer position
     * @param lat: latitude position (< 2*bw)
     * @param lon: Longitude position (< 2*bw)
     * @param value: Value to set
     */
    inline void setP(int r, int lat, int lon, Sphfloat value)
    {
      m[r][lat*size+lon]=value;
      return;
    };

    /**
      * Returns an spherical imaginary position. Used when it is represented complex objects
      *
      * @param r: layer position
      * @param lat: latitude position (< 2*bw)
      * @param lon: Longitude position (< 2*bw)
      * @output returned value
      */
    inline Sphfloat getPI(int r, int lat, int lon)
    {

      return idata[r][lat*size+lon];
    };

    /**
     * sets a value in an spherical position. Possibly useless. Used when it is represented complex objects
     *
     * @param r: layer position
     * @param lat: latitude position (< 2*bw)
     * @param lon: Longitude position (< 2*bw)
     * @param value: Value to set
     */
    inline void setPI(int r, int lat, int lon, Sphfloat value)
    {
      idata[r][lat*size+lon]=value;
      return;
    };

    /**
     * Computes the spherical harmonics coefficients associated to a layer of the spherical representation
     *
     * @constraint: preComputation must be call before this function
     * @param r: Layer
     * @coefr: Buffer where it will be stores the real part of the coefficients. It must be initially allocated.
     * @coefi: Buffer where it will be stores the imaginary part of the coefficients. It must be initially allocated.
     */
    inline void sphCoef(int r,Sphfloat *coefr,Sphfloat *coefi)
    {

      if(!is_complex)
      	FST_semi_memo(m[r],idata[0],coefr,coefi,bw,table,workspace,1,bw,&dctPlan,&fftPlan,weights);
			else
      	FST_semi_memo(m[r],idata[r],coefr,coefi,bw,table,workspace,1,bw,&dctPlan,&fftPlan,weights);
    };

    /**
     * Free spherical harmonics associated buffers
     *
     */
    void free_preComputation();
    /**
     * Allocates spherical harmonics associated buffers. Necessary to compute coefficients
     *
     * @param isComplex: Determines if the object to represent is complex. It will allocate imaginary buffer if neccessary
     */
    void preComputation(bool isComplex=false);


  private:
    /// Real Spherical representation buffer
    Sphfloat **m;
    /// latitude/longitud lenght
    int size;
    /// spherical harmonic bandwidth
    int bw;
    /// Number of layers
    int gr;
	/// Object to rerepsent: Real/Complex
    bool is_complex;

    /// Imaginary Spherical representation buffer
    Sphfloat **idata;
    /// Auxiliary buffers
    Sphfloat *workspace,*tablespace,**table,*weights;
    /// Auxiliary fft plans
    fftwf_iodim dims[1],howmany_dims[1];
    /// Auxiliary fft plans
    fftwf_plan dctPlan,fftPlan;

};
#endif
