################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CPP_SRCS += \
../Auxiliar.cpp \
../EVolumes.cpp \
../Mask.cpp \
../PCollection.cpp \
../SCollection.cpp \
../SH_Object.cpp 

OBJS += \
./Auxiliar.o \
./EVolumes.o \
./Mask.o \
./PCollection.o \
./SCollection.o \
./SH_Object.o 

CPP_DEPS += \
./Auxiliar.d \
./EVolumes.d \
./Mask.d \
./PCollection.d \
./SCollection.d \
./SH_Object.d 


# Each subdirectory must supply rules for building sources it contributes
%.o: ../%.cpp
	@echo 'Building file: $<'
	@echo 'Invoking: Cross G++ Compiler'
	mpiCC -DVOLUME_INCLUDED -DMPI_RELEASE -I../include -I../../../src -O3 -U_FORTIFY_SOURCE -g -Wall -c -fpermissive -fno-omit-frame-pointer -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


