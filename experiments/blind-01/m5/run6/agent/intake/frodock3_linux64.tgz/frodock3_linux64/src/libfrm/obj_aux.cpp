#include "obj_aux.h"
//holacxcx

float dist(Tpolar a, Tpolar b)
{
  float x1,x2,y1,y2,z1,z2;


  x1=a.rho*sin(a.alpha) * cos(a.betha);
  x2=b.rho*sin(b.alpha) * cos(b.betha);
  y1=a.rho*sin(a.alpha) * sin(a.betha);
  y2=b.rho*sin(b.alpha) * sin(b.betha);
  z1=a.rho*cos(a.alpha);
  z2=b.rho*cos(b.alpha);


  return sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2)+(z1-z2)*(z1-z2));
  //return 0.0;
}

float polar_normal(float x)
{
  float y=x,p2=2*M_PI;

  while(y>=p2)
    y-=p2;
  while(y<0)
    y+=p2;
  return y;
}

int polar_normal(int x,int max)
{
  int y=x;
  while(y>=max)
    y-=max;
  while(y<0)
    y+=max;
  return y;
}


int entorno(float limit,Tpolar punto,float width,float initlambda,int bw, int maxRho, Tipolar *entorno,double *normdist)
{
  float rho, alpha, betha;
  int irho,rhomin,rhomax,ialpha,ibetha;
  Tpolar punto2;
  Tipolar ipunto2;
  int vecinos=0;
  int maxcapa=bw*2;
  int contalpha,contbetha;


  *normdist=0;
  //Calculo del limite superior para rho
  rhomax=(int)floor((punto.rho+limit)/width);
  if(rhomax>=maxRho)
    rhomax=maxRho-1;

  //Calculo del limite inferior para rho
  rhomin=(int)ceil((punto.rho-limit)/width);
  if(rhomin<=0)
    rhomin=1;


  //Exploración de rhos dentro del entorno
  for(irho=rhomin,rho=((float)rhomin)*width;irho<=rhomax;irho++,rho+=width)
  {

    //BUSQUEDA POR ALPHA

    //Calculo de primer valor alpha a la izquierda
    ialpha=(int)floor(punto.alpha/(initlambda/2.0));
    alpha=(float)ialpha*(initlambda/2.0);

    punto2.rho=rho;
    punto2.alpha=polar_normal(alpha);
    punto2.betha=punto.betha;
    ipunto2.rho=irho;
//    ipunto2.alpha=polar_normal(ialpha,maxcapa);
    ipunto2.alpha=ialpha;

    //Calcular distancia:
    ipunto2.dist=dist(punto,punto2);

    //EXPLORAR ALPHA POR LA IZQUIERDA
    contalpha=0;
    while(ipunto2.dist<=limit && punto2.alpha>0.0 && punto2.alpha<M_PI
          && ipunto2.alpha>0 && ipunto2.alpha<maxcapa && contalpha<maxcapa)
    {
      //BUSQUEDA POR BETHA

      //Calculo del primer valor betha a la izquierda
      ibetha=(int)floor(punto.betha/initlambda);
      betha=(float)(ibetha)*initlambda;

      punto2.betha=polar_normal(betha);
      ipunto2.betha=polar_normal(ibetha,maxcapa);

      //Calcular distancia:
      ipunto2.dist=dist(punto,punto2);

      contbetha=0;
      //EXPLORAR BETHA POR LA IZQUIERDA
      while(ipunto2.dist<=limit && contbetha<maxcapa)
      {
        //Si el punto esta dentro del entorno Almacenar como vecino
        entorno[vecinos].alpha=ipunto2.alpha;
        entorno[vecinos].betha=ipunto2.betha;
        entorno[vecinos].rho=ipunto2.rho;
        if(ipunto2.dist<0.0000001)
          ipunto2.dist=0.0000001;

        *normdist+=(double)(1.0/ipunto2.dist);
        entorno[vecinos].dist=ipunto2.dist;
        vecinos++;


        //Pasar al siguiente punto
        punto2.betha-=initlambda;
        punto2.betha=polar_normal(punto2.betha);
        ipunto2.betha--;
        ipunto2.betha=polar_normal(ipunto2.betha,maxcapa);


        //Calcular distancia:
        ipunto2.dist=dist(punto,punto2);
        //punto2.dist=0;
        contbetha++;
      }


      //Calculo del primer valor betha a la derecha
      ibetha=(int)ceil(punto.betha/initlambda);
      betha=(float)ibetha*initlambda;

      punto2.betha=polar_normal(betha);
      ipunto2.betha=polar_normal(ibetha,maxcapa);

      //Calcular distancia:
      ipunto2.dist=dist(punto,punto2);

      //EXPLORAR BETHA POR LA DERECHA
      while(ipunto2.dist<=limit && contbetha<maxcapa)
      {
        //Si el punto esta dentro del entorno Almacenar como vecino
        entorno[vecinos].alpha=ipunto2.alpha;
        entorno[vecinos].betha=ipunto2.betha;
        entorno[vecinos].rho=ipunto2.rho;
        if(ipunto2.dist<0.0000001)
          ipunto2.dist=0.0000001;

        *normdist+=(double)(1.0/ipunto2.dist);
        entorno[vecinos].dist=ipunto2.dist;
        vecinos++;


        //Pasar al siguiente punto
        punto2.betha+=initlambda;
        punto2.betha=polar_normal(punto2.betha);
        ipunto2.betha++;
        ipunto2.betha=polar_normal(ipunto2.betha,maxcapa);


        //Calcular distancia:
        ipunto2.dist=dist(punto,punto2);
        contbetha++;
      }

      //Pasar a la siguiente alpha
      (punto2.alpha)-=initlambda/2.0;
      punto2.alpha=polar_normal(punto2.alpha);
      ipunto2.alpha--;
      //ipunto2.alpha=polar_normal(ipunto2.alpha,maxcapa);

      punto2.betha=punto.betha;

      //Calcular distancia:
      ipunto2.dist=dist(punto,punto2);

      contalpha++;
    }//FIN EXPLORACION ALPHA POR LA IZQUIERDA


    //Calculo de primer valor alpha a la derecha
    ialpha=(int)ceil(punto.alpha/(initlambda/2.0));
    alpha=(int)ialpha*initlambda/2.0;

    punto2.alpha=polar_normal(alpha);
    punto2.betha=punto.betha;
    //ipunto2.alpha=polar_normal(ialpha,maxcapa);
    ipunto2.alpha=ialpha;

    //Calcular distancia:
    ipunto2.dist=dist(punto,punto2);


    //EXPLORAR ALPHA POR LA DERECHA
    while(ipunto2.dist<=limit && punto2.alpha>0.0 && punto2.alpha<M_PI
          && ipunto2.alpha>0 && ipunto2.alpha<maxcapa && contalpha<maxcapa)
   {
      //BUSQUEDA POR BETHA

      //Calculo del primer valor betha a la izquierda
      ibetha=(int)floor(punto.betha/initlambda);
      betha=ibetha*initlambda;

      punto2.betha=polar_normal(betha);
      ipunto2.betha=polar_normal(ibetha,maxcapa);

      //Calcular distancia:
      ipunto2.dist=dist(punto,punto2);
      contbetha=0;
      //EXPLORAR BETHA POR LA IZQUIERDA
      while(ipunto2.dist<=limit && contbetha<maxcapa)
      {
        //Si el punto esta dentro del entorno Almacenar como vecino
        entorno[vecinos].alpha=ipunto2.alpha;
        entorno[vecinos].betha=ipunto2.betha;
        entorno[vecinos].rho=ipunto2.rho;
        if(ipunto2.dist<0.0000001)
          ipunto2.dist=0.0000001;

        *normdist+=(double)(1.0/ipunto2.dist);
        entorno[vecinos].dist=ipunto2.dist;
        vecinos++;


        //Pasar al siguiente punto
        punto2.betha-=initlambda;
        punto2.betha=polar_normal(punto2.betha);
        ipunto2.betha--;
        ipunto2.betha=polar_normal(ipunto2.betha,maxcapa);

        //Calcular distancia:
        ipunto2.dist=dist(punto,punto2);
        contbetha++;
      }


      //Calculo del primer valor betha a la derecha
      ibetha=(int)ceil(punto.betha/initlambda);
      betha=ibetha*initlambda;

      punto2.betha=polar_normal(betha);
      ipunto2.betha=polar_normal(ibetha,maxcapa);
      //Calcular distancia:
      ipunto2.dist=dist(punto,punto2);

      //EXPLORAR BETHA POR LA DERECHA
      while(ipunto2.dist<=limit && contbetha<maxcapa)
      {
        //Si el punto esta dentro del entorno Almacenar como vecino
        entorno[vecinos].alpha=ipunto2.alpha;
        entorno[vecinos].betha=ipunto2.betha;
        entorno[vecinos].rho=ipunto2.rho;
        if(ipunto2.dist<0.0000001)
          ipunto2.dist=0.0000001;

        *normdist+=(double)(1.0/ipunto2.dist);
        entorno[vecinos].dist=ipunto2.dist;
        vecinos++;

        //Pasar al siguiente punto
        punto2.betha+=initlambda;
        punto2.betha=polar_normal(punto2.betha);
        ipunto2.betha++;
        ipunto2.betha=polar_normal(ipunto2.betha,maxcapa);
        //Calcular distancia:
        ipunto2.dist=dist(punto,punto2);
        contbetha++;
      }

      //Pasar a la siguiente alpha
      (punto2.alpha)+=initlambda/2.0;
      punto2.alpha=polar_normal(punto2.alpha);
      punto2.betha=punto.betha;
      ipunto2.alpha++;
      //ipunto2.alpha=polar_normal(ipunto2.alpha,maxcapa);
      //Calcular distancia:
      ipunto2.dist=dist(punto,punto2);
      contalpha++;
    }


  }

  return vecinos;
}
