#pragma once
#include <list>
using namespace std;

class MPIManager
{
public:
	int getMol();
	double startServer(int startMol, int endMol, float* output, int savedPeaks);
	void sendData(int mol, int savedPeaks, float *data, double dockingTime);
};

