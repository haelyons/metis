#include <stdlib.h>
#include <stdio.h>
#include "include/PCollection.h"


PCollection::PCollection(float in_stepsize)
{
	stepsize=in_stepsize;
	num=0;
	points=(Tcoor*)malloc(0);
}

PCollection::PCollection(char *filename,int max,Tcoor origin, float voxsize, float in_stepsize)
{
	FILE *file=fopen(filename,"rb");
	int total;
	int i;
	float buffer[11];
	Tcoor point;

	num=0;
	stepsize=in_stepsize;
	points=(Tcoor*)malloc(0);
	fread(&total,  sizeof(int),  1, file);

		for ( i = 0; (i < total) && ((max==-1) || (i<max)); i++)
  {
  	fread(buffer,sizeof(float),11,file);
  	point[0]=(buffer[3]-origin[0]- voxsize/2.0)/voxsize;
  	point[1]=(buffer[4]-origin[1]- voxsize/2.0)/voxsize;
  	point[2]=(buffer[5]-origin[2]- voxsize/2.0)/voxsize;

  	this->Insert_point(point);
  }




	fclose(file);
}

PCollection::~PCollection()
{
	int i;
	free(points);
}

void PCollection::Insert_point(Tcoor point)
{
	num++;
	points=(Tcoor*)realloc(points,num*sizeof(Tcoor));

	points[num-1][0]=point[0];
	points[num-1][1]=point[1];
	points[num-1][2]=point[2];
}

int PCollection::return_point(int pos, float *point)
{
	if (pos>=num)
		return -1;

	point[0]=points[pos][0];
	point[1]=points[pos][1];
	point[2]=points[pos][2];

	return 1;
}

PCollection *PCollection::split(int pieces, int piece)
{
	int number;
	int init,end;
	int rest;
	int i;

	rest = num%pieces;
	number=num/pieces;
	init=number*piece + rest;

	if(rest>piece)
	{
			number++;
			init-=rest-piece;
	}

	end=init+number;

	PCollection *p= new PCollection(stepsize);

	//fprintf(stderr,"frodock> init   end  %d  %d\n",init, end);

	for(i=init;i<end;i++)
	{
		p->Insert_point(points[i]);
	}

	return p;
}

void PCollection::writeFile(char *name)
{
	FILE *f;
	int i;

	f=fopen(name,"wt");

	fprintf(f,"stepsize=%f\n",stepsize);
	fprintf(f,"Num=%d\n",num);
	for(i=0;i<num;i++)
	{
		fprintf(f,"%f * %f * %f\n",points[i][0],points[i][1],points[i][2]);
	}

	fclose(f);
}

void PCollection::readFile(char *name)
{
	FILE *f;
	int i;
	float a,b,c;

	f=fopen(name,"rt");


	fscanf(f,"stepsize=%f\n",&stepsize);
	fscanf(f,"Num=%d\n",&num);

	points=(Tcoor*)realloc(points,sizeof(Tcoor)*num);

	for(i=0;i<num;i++)
	{
		fscanf(f,"%f * %f * %f\n",&a,&b,&c);
		points[i][0]=a;
		points[i][1]=b;
		points[i][2]=c;
	}
	fclose(f);
}

void PCollection::around(float x, float y, float z, float step, float inter)
{
	int i,j,k,total,cont;
	float posX,posY,posZ;

	posX=x-(step*(inter/2.0));
	posY=y-(step*(inter/2.0));
	posZ=z-(step*(inter/2.0));
	total=(inter+1)*(inter+1)*(inter+1);
	cont=0;

	points=(Tcoor*)realloc(points,sizeof(Tcoor)*total);
	num=total;

	for(i=0;i<=inter;i++)
		for(j=0;j<=inter;j++)
			for(k=0;k<=inter;k++)
			{
				points[cont][0]=posX+step*i;
				points[cont][1]=posY+step*j;
				points[cont][2]=posZ+step*k;
				cont++;
			}

}

