################################################################################
# Automatically-generated file. Do not edit!
################################################################################

USER_OBJS :=

LIBS :=  -lfrodock -lprotprot -lfrm  -lbessel -lpdb -lvolume -ltools

