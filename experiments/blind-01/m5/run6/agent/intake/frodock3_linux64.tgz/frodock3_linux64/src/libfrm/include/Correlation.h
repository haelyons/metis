#ifndef _CORRELATION_H
#define _CORRELATION_H

#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <fftw3.h>


#include "libtools/include/timer.h"

#include "obj_fsphh.h"

#define PI 3.1415927
#define CONV 0.017453293

extern  int seanindex(int,int,int);


typedef float twoFloat[2];


/**
* Computes the correlation between a low-resolution volume A and a spherical
* representation of another volume B. For do that it takes the next steps:
*
*  - Computes the IMMP(integralr, integrali) Integral using the precomputed
*  data of A(integralAux1) and the spherical harmonics of B (rcoeffs, icoeffs)
*
*  -From the integral the correlation matrix of both volumenes is computed
* (coef_corr) in the Fourier Domain
*
*  -Applies inverse Fourier transfor to get the correlation matrix in the real space
*
*  -Searcs the best solutions in the matrix. They are stored in a list (corr)
*
* @param bw: Bandwidth of the spherical representation
* @param integralAux1: Precomputed data from Low resolution Volume A
* @param *rcoeffs, *icoeffs: Spherical coefficients that represents the volume B
* @param rmax: Number of spherical layers that represent the volume B
* @param t_ind2: Sort Precomputed list of positions to read in the spherical harmonics data
* @param norm_lo: Precomputed low_resoplution normalization factor
* @param integralr,integralr: Buffers where the Integral is computed. Must be initializated
* @param sizeintegral: Size of the Integral buffers
* @param t_index: Sort Precomputed list of position for writing in the integral buffers
* @param vld: Precomputed ddd coefficients
* @param coef_corr: Buffer of rotational correlations. Must be initialized
* @param plan: Inverse Fourier Transform plan. Must be created
* @param coor: List of best correlations
* @param dist_cut: Distance in grades that must exist between two different rotational solutions.
* @param TotalPeaks: Maximum number of stored solutions
* @param ii,jj,kk: if different to -1, the function only returns the correlation at the given position of the Rotational correlation buffer
* @param sinInterp: If true, best correlations are interpoled between close rotations, if false the solutions are solutions in rotations in the buffer. False is only used when computing only one position
*/

 int compute_corr(
    int bw,

    //ENTRADAS PARA EL CALCULO DE INTEGRAL
    twoFloat *integralAux1,            //Buffer con la aportacion de la integral
                                       //del volumen en baja resolucion

    vlSpherical *sph_hi,               //volumen en alta en coord esfericas

    Sphfloat *rcoeffs, Sphfloat *icoeffs,  //buffers donde se alamacenan los coeficientes
                                       //harmonicos para una determinada capa
    int rmax,                          //Nº de capas esfericas a tratar de los volumenes
    int *t_ind2,                       //buffer que indica posiciones a leer de
                                       //los coeficientes harmonicos
    float norm_lo,                     //Factor de normalizacion para el volumen en baja
                                       //resolucion

    //SALIDAS DEL CALCULO DE LA INTEGRAL
    float *integralr,float *integrali, //Buffers donde se calcula la integral
    int sizeIntegral,                  //tamaño de los buffers de la integral
    int *t_index,                      //buffer que indica posiciones a escribir en la integral

    //ENTRADAS DEL CALCULO DE CORRELACIONES EN FOURIER
    vlDCoef *vld,                      //almacen de coeficientes ddd necesarios para
                                       //el calculo de las correlaciones en Fourier

    //SALIDAS DEL CALCULO DE CORRELACIONES EN FOURIER
    float *coef_corr,                  //Buffer donde se calculan las correlaciones

    //ENTRADAS PARA EL CALCULO DE LA INVERSA
    fftwf_plan plan,                   //Plan para calcular la transformada inversa

    //SALIDAS DEL CALCULO DE MEJORES SOLUCIONES
    float **corr,                       //Buffer donde se almacenan las mejores soluciones.
                                        //Actua como salida de la funcion

    float dist_cut,
    int TotalPeaks,
    int ii=-1,
    int jj=-1,
    int kk=-1,
    bool sinInterp=false
    );




/**
* Auxiliar function. Computes the correlation matrix of two volumes from the precomputed
* integral IMMP(coeffr, coeffi)
*
* @param bw: Bandwidth of spherical representation employed
* @param coeffr,coeffi: Integral buffers
* @param ddd: Precomputed ddd coefficients
* @param coef_corr: Correlation Matrix
*/
void fourier_corr(int bw, float *coeffr, float *coeffi, vlDCoef *ddd, float *coef_corr);
void split_corr(float * coef_corr,int size,int bw);

/**
* Auxiliar function. Finds out the best correlation peaks in a correlation matrix.
* It returns a list with the best solucions sort
*
* @param buff: Correlation matrix
* @param bw: Spherical bandwidth employed. Related with the size of the matrix
* @param size: Dimensional size of the matrix
* @param dist_cut: Minimum distance in angles between solutions
* @param corr: List of best solutions
* @param corm: Normalization factor of solutions
* @param MaxPeaks: Maximum number of solutions
*/
 int best_angles(float *buff,int bw,int size, float dist_cut,float *corr[],float norm,int MaxPeaks);
 int best_angles_lI(float *buff,float ***matrix,int bw,int size, float dist_cut,float *corr[],float norm,int MaxPeaks);
 int best_angles_wI( float * buff, int bw, int size, float dist_cut, float * corr[], float norm, int MaxPeaks );

/**
* Auxiliar function. Return the correlation localized in a given position of a
* correlation matrix. It can interpole or not the value of correlation
*
* @param ii,jj,kk: Position of the desired correlation in the rotational matrix
* @param buff: Correlation rotational buffer
* @param bw: Spherical bandwidth employed
* @param size: Size of the buffer
* @param *corr: correlation value returned
* @param norm: Normalization factor
* @param sinInterp: determines if interpolation is set or not
*/
void  best_angle(int ii,int jj,int kk,float *buff,int bw,int size,float *corr[],float norm,bool sinInterp=false);



/**
* Auxiliar function. Modifies a list of Translation/Rotation Correlation solutions for
* inserting new solutions for a rotation correlation list for a given translation
*
* @param corr: Rotation correlation solution list
* @param npeaks: number of solutions in the rotation list
* @param corr_max: Translation/Rotation correlation solution list
* @param nsolut: Maximum number of solutions in the Translation/rotation list
* @param ii,jj,kk: Translational position of the Rotation correlation solutions(in voxels)
* @param unit: Size of the voxels in the volume translated
* @param dist_cut_rot: Minimum rotational distance (in grades) between solutions
* @param dist_cut_trans: minimum translation distance (in amstrongs) between solutions
*/
int best_solutions( float * corr[], int npeaks, float * corr_max[], int nsolut, float ii, float jj, float kk,
                    float unit, float dist_cut_rot,float  dist_cut_trans);


/**
*  computes rotation matrix based on Euler angles psi, theta, phi in radians
*
* @param dump: Matrix correlation
* @param psi,theta,phi: angles thar determinines the matrix
*/
void get_rot_matrix (float dump[3][3], float psi, float theta, float phi);

/**
*  Returns the distance in radians between the rotations given by the Euler angles psi,theta and phi
* and the rotation stored in the given position in the given buffer
*
* @param psi,th,phi: Angles that represents the first rotation
* @param j: Position  of the second rotation
* @param corr: Buffer where the second rotation is stored
*/
float distance_eulers(float psi,float th,float phi,unsigned long j, float *corr[]);

float distance_eulers( float matrix_sol[3][3], unsigned long j, float ***matrix );

/**
*  Returns the distance between two rotations stored in a buffers
*
* @param i: Position of the first rotation
* @param j: Position of the second rotation
* @param coor: Buffer where the rotations are stored
*/
float distance_eulers(unsigned long i, unsigned long j, float *corr[]);

/**
* Returns true if two movements(rotation+translation) are too close.
* One movement B is stored in a list with the rotation and translation factors.
* The other movement A has the rotation factors in a list and the transation factors
* are given apart
*
* @param buf1: List of rotations (with correlations). The rotation of movement A is stored here
* @param buf2: List of movements (with correlations). The factors of movement B are stored here
* @param a: Position in the list of rotations of movement A
* @param b: Position in the list of factors of movement B
* @param x,y,mz: Translational factors osf movement A
* @param limit_angle: Minimum distance between rotations
* @param limit_trans: Minimum distance between translations
*/
bool distance_motions_tr( float * buf1[], float * buf2[], int a, int b,
float x, float y, float z, float limit_angle, float limit_trans );

/**
* Returns true if two movements(rotation+translation) are too close.
* Each movement(rotation+translation) is stored in a different list
*
* @param buf1: List of movementss (with correlations). The factors of movement A are stored here
* @param buf2: List of movements (with correlations). The factors of movement B are stored here
* @param a: Position in the list of factors of movement A
* @param b: Position in the list of factors of movement B
* @param limit_angle: Minimum distance between rotations
* @param limit_trans: Minimum distance between translations
*/
bool distance_motions_trc( float * buf1[], float * buf2[], int a,
int b, float limit_angle, float limit_trans );


/**
* Transforms a spherical position in a cartesian position
* @param rad,alpha,betha: Rotational coordinates
* @param posx,posy,posz: cartesian coordinates returned
* @param cx,cy,cz: origin of the spherical system
*/
void shp2cart(float rad,float alpha,float betha,float *posx,float *posy,float *posz,
              float cx,float cy,float cz);




//Variables globales para el calculo de correlaciones
extern float *rcoeffs,*icoeffs,*rcoeffs2,*icoeffs2;//Buffers donde se almacenan los coeficientes asociados a los harmonicos esfericos para representar los volumenes
extern float *integralr,*integrali;                 //buffers donde se almacena la integral del producto entre ambos volumenes
extern int sizeIntegral;
extern float *coef_corr;                            //buffer donde se almacena la correlacion entre dos volumenes
extern fftwf_plan plan;                             //plan para realizar la transformada inversa de la matriz de correlaciones
//Precalculacion de correlacion
extern twoFloat *integralAux1;
extern int *t_ind2,*t_index;
//Normalizacion de correlaciones
extern float norm_hi;
extern vlDCoef *vld;

#endif
