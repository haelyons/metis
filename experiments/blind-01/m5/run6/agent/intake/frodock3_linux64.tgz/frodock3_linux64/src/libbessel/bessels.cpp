#include <stdlib.h>
#include <math.h>


#include "libpdb/include/Macromolecule.h"
#include "libpdb/include/pdbIter.h"


//*************************FUNCIONES AUXILIARES***************

extern int seanindex(int m,
              int l,
              int bw);

//**************************************************************
/**
* Bessel Function
* It returns a Bessel Coefficient
*/

double bessel_il_CF1(const int l, const double x, const double threshold)
{
  const int kmax = 2000;
  double tk   = 1.0;
  double sum  = 1.0;
  double rhok = 0.0;
  int k;

  for(k=1; k<=kmax; k++) {
    double ak = (x/(2.0*l+1.0+2.0*k)) * (x/(2.0*l+3.0+2.0*k));
    rhok = -ak*(1.0 + rhok)/(1.0 + ak*(1.0 + rhok));
    tk  *= rhok;
    sum += tk;
    if(fabs(tk/sum) < threshold) break;
  }

  return( x/(2.0*l+3.0) * sum);
}


#define GSL_LOG_DBL_EPSILON   (-3.6043653389117154e+01)
double gsl_sf_bessel_i0_scaled_e(const double x)
{
  double ax = fabs(x);

  /* CHECK_POINTER(result) */

  if(ax < 0.2) {
    const double eax = exp(-ax);
    const double y = ax*ax;
    const double c1 = 1.0/6.0;
    const double c2 = 1.0/120.0;
    const double c3 = 1.0/5040.0;
    const double c4 = 1.0/362880.0;
    const double c5 = 1.0/39916800.0;
    const double sum = 1.0 + y*(c1 + y*(c2 + y*(c3 + y*(c4 + y*c5))));
    return (eax * sum);
  }
  else if(ax < -0.5*GSL_LOG_DBL_EPSILON) {
    return ((1.0 - exp(-2.0*ax))/(2.0*ax));
  }
  else {
    return (1.0/(2.0*ax));
  }

}

#define GSL_DBL_EPSILON    2.2204460492503131e-16
#define GSL_SQRT_DBL_MIN   1.4916681462400413e-154
double bessel(int l, float x)
{
  double sgn = 1.0;
  double ax  = fabs(x);

  if(x < 0.0)
  {
    if(l%2!=0)
      sgn=-1.0;
    x = -x;
  }

  double i0_scaled;
  i0_scaled  = gsl_sf_bessel_i0_scaled_e(ax);
  double rat;
  rat = bessel_il_CF1(l, ax, GSL_DBL_EPSILON);
  double iellp1 = rat * GSL_SQRT_DBL_MIN;
  double iell   = GSL_SQRT_DBL_MIN;
  double iellm1;
  int ell;
  for(ell = l; ell >= 1; ell--) {
    iellm1 = iellp1 + (2*ell + 1)/x * iell;
    iellp1 = iell;
    iell   = iellm1;
  }
  return   (sgn * i0_scaled * (GSL_SQRT_DBL_MIN / iell));
}
//**************************************************************

//**************************************************************
//Funcion auxiliar de precalculo de coeficientes de Legendre
void AssociatedCoef(int bw,float **coef)
{
  *coef=(float*)malloc(sizeof(float)*((bw*bw)+bw)/2);
  int l,m,cont;
  float temp, temp2;
  int ind,aux;

  cont=0;
  for(l=0;l<bw;l++)
    for(m=0;m<=l;m++)
    {
      temp=1.0;
      for(ind=l-m;ind>0;ind--)
        temp*=ind;

      aux=l-m;
      temp2=temp;
      for(ind=l+m;ind>aux;ind--)
        temp2*=ind;
      (*coef)[cont]=sqrt(((2*l+1)/(4*PDB_PI))*(temp/temp2));
      cont++;
    }

}


//Legendre Function
#ifndef LNOF2
#define LNOF2 0.693147180559945309417232121458
#endif
//Calculo de la associated Legendre Function
//Funcion tomada de libftsh
//http://www.math.ohiou.edu/~mjm/research/libftsh.html
float Pmncos(int order,
            int index,
            float phi
            ){
  /** The purpose of this function is to allow us to evaluate an associated
    Legendre function at any point.
    This routine is super stabilized for all conditions.

    Martin J. Mohlenkamp, Yale University, 1997
    just like dbrtsinPmncos except for sqrt(sin) factor
    The guts of this function were grafted from dbnexthalfrtassleg April 96.


  INPUTS:  order -- the order of the associated legendre function you want.
                    In P^m_n notation this is m. order>=0
           index -- Which frequency to use, starting from the lowest legal.
                    In P^m_n notation, n is m+index.  index >=0
           phi -- The point at which to evaluate. 0< phi < PI
  OUTPUTS:  returns                   m
                                     P (cos(phi)) * const
                                      n
            The constant is set so we are L^2 normalized.
            Since the number of points to be used is not known, we cannot
            adjust for the discretization.

   NOTES:
   1. We pass type REAL to several functions which expect double.
      This should not cause trouble but still might.
**/
  float oneback,twoback;
  int s,i,sizetemp,size;
  float sofar[2],ex,why;


  /* initialize */
  /* here we generate the correct starting constant (for P^m_m).
  \sqrt{\Gamma(2 order+2) \over 2} {1 \over 2^{order}\Gamma(order+1)}
  ={1\over \sqrt{2}}\prod_{j=1}^{m} \sqrt{1 + {1\over 2j}} */
  twoback=1.0;
  for(s=1;s<=order;s++)
    twoback*=1.0 + 0.5/s;
  twoback=sqrt(twoback/2);

  /* now initialize ex, why, and the recurrence: sofar*/
  ex=cos(phi);
  why=sin(phi);
/* We are going to be very careful in our representation of the values of our
   functions. Although the recurrence is stable, it is prone to overflows
   and underflows. Rather than let the type REAL try to deal with it, we
   remove a power of 2, leaving us with values of size 1.  The exponent
   is stored in  size .*/

/* this gives us our sin() to the power order *//** 1/2 removed **/
  /* here is the size (nearest power of 2) of the power of sin*/
  if(why==0){
    if(order==0){
      sofar[0]=twoback;
      size=0;
    }else
      return 0.0;
  }else{/* okay to log */
    size= (int) (order)* log(why) /LNOF2;/** 1/2 removed **/
    /*here is the remnant, including coefficient*/
    sofar[0]=twoback * exp((order)*log(why) -size*LNOF2);/** 1/2 removed **/
    /* re-extract the size, probably unecessary*/
    sofar[0]=(float)frexp((double)sofar[0],&sizetemp);
    size+=sizetemp;
  }

  if(index==0)              /* index==0 we are done */
    return (float)ldexp((double)sofar[0],size);

  /* another special case, requires some initialization*/
  /* this is the oneback recurrence coefficient */
  oneback=2.0*sqrt((0.5+order)*(0.5+1.0/(2.0*order+1.0)));
  sofar[1]=oneback* sofar[0]*ex;

/* This renormalizes so that, on average we have size 1 */
  frexpf(fabs(sofar[0])+fabs(sofar[1]),&sizetemp);
  size+=sizetemp;
  sofar[0]=(float)ldexp((double)sofar[0],-sizetemp);
  sofar[1]=(float)ldexp((double)sofar[1],-sizetemp);

  if(index==1)              /* index==1 we are done */
    return (float)ldexp((double)sofar[1],size);

/* general case */
  for(i=2;i<=index;i++){
    /* This is the main recurrence.  First we compute the coefficients,
       then compute and load in the values */
    oneback=2*sqrt((1.0+(order-0.5)/i)*(1.0-(order-0.5)/(2.0*order+i)));
    twoback=-sqrt((1-1.0/i)*(1-1.0/(2*order+i))
                  *(1+4.0/(2*i+2*order-3)));
    sofar[i%2]=oneback*ex*sofar[(i-1)%2]+twoback*sofar[(i-2)%2];
    /* This renormalizes so that, on average we have size 1 */
    frexp(fabs(sofar[0])+fabs(sofar[1]),&sizetemp);
    size+=sizetemp;
    sofar[0]=ldexp(sofar[0],-sizetemp);
    sofar[1]=ldexp(sofar[1],-sizetemp);
  }

  return (float)ldexp((double)sofar[index%2],size);
}

//Calculo de la associated Legendre Function
//empleando la funcion de Legendre plgndr
//Funcion sacada de Numerical Recipes pag. 254
float plgndr(int l, int m,float x,float *coef)
{
  float fact,pll,pmm,pmmp1,somx2;
  int i,ll;
  int posC=(l*l+l)/2+m;

  if(m<0|| m>l || fabs(x)>1.0)
  {
    fprintf(stderr,"ERROR in Associated Legendre Polynomial\n");
    return -1.0;
  }

  pmm=1.0;
  if(m>0)
  {
    somx2=sqrt((1.0-x)*(1.0+x));
    fact=1.0;
    for(i=1;i<=m;i++)
    {
      pmm*= -fact*somx2;
      fact+=2.0;
    }
  }
  if(l==m)
  {
    return pmm*coef[posC];
  }
  else
  {
    pmmp1=x*(2*m+1)*pmm;
    if(l==(m+1))
    {
      return pmmp1*coef[posC];
    }
    else
    {
      for(ll=m+2;ll<=l;ll++)
      {
        pll=(x*(2*ll-1)*pmmp1-(ll+m-1)*pmm)/(ll-m);
        pmm=pmmp1;
        pmmp1=pll;
      }
    }
    return (pll*coef[posC]);
  }
}

//**************************************************************

//Compute a sperical harmonic of order lm in the polar coordinates (beta,landa)
void computeSH(int l, int m,float theta, float lambda, float sol[2],float *coef)
{


  //If m negative same as positive
  bool trans=false;
  if(m<0)
  {
    m*=-1;
    trans=true;
  }

  //DIFERENTES MODOS DE CALCULO DE LA ASSOCIATED LEGENDRE FUNCTION
  // cosine=cos(theta);
  // if (cosine>0.99999999)
  //  cosine=1.0;
  // if (cosine<-0.99999999)
  //  cosine=-1.0;
  //float term1=gsl_sf_legendre_sphPlm(l,m,cosine);

  if(theta>=PDB_PI)
	theta-=0.000001;
  float term1=Pmncos(m,l-m,theta)/2.5066;
  if(m%2!=0)
    term1*=-1.0;

  //float term1=plgndr(l,m,cosine,coef);
  //printf("term1=%f\n",term1);
  //FIN DE MODOS DE CALCULO


  //Computation of the real part
  sol[0]= (cos(m*lambda)*term1);
  sol[1]= (sin(m*lambda)*term1);
  if(trans)
  {
    sol[1]*=-1;

    if(m%2!=0)
    {
      sol[0]*=-1;
      sol[1]*=-1;
    }
  }

}


//Computes the agregation in spherical coefficients of a gaussian centered in polar coordinates (betaC,landaC,rhoC) in a distance r
void gaussian_agregation(float thetaC,float lambdaC,float rhoC, float r,float alpha,float c, int bw, float *coeffr,float *coeffi, float *preC )
{
  float term1,term2;
  float coef[2],aux;
  int i=0;
  //Constant term

  term1=4*PDB_PI*exp(-alpha*pow((r-rhoC),2))*c;

  //Constant term in the computation of the bessel functions
  term2=2*alpha*rhoC*r;


  //Every possible order of harmonic spherics
  for (int l=0;l<bw;l++)
  {
    //Bessel funtion coefficient

    aux=term1;
    if(term2!=0.0 || l!=0)
        //aux*=gsl_sf_bessel_il_scaled(l,term2);
        aux*=bessel(l,term2);

    if(aux!=0)
     for (int m=0;m<=l;m++)
     {
      //Computation of the coefficient associated to the harmonic
      //the harmonic evaluated in the center of the gaussian
      computeSH(l,m,thetaC,lambdaC,coef,preC);

      i=seanindex(m,l,bw);

      coeffr[i]+=coef[0]*aux;
      coeffi[i]-=coef[1]*aux;

     }
  }

}

void cart2sph(float *rad,float *theta,float *lambda,float posx,float posy,float posz,
              float cx,float cy,float cz)
{

 float X=posx-cx, Y=posy-cy, Z=posz-cz;

 *rad     = sqrt(X*X + Y*Y + Z*Z);
 *theta   = acos(Z/(*rad)); //co-latitud
 *lambda  = atan2(Y,X);//Longitud

}


//*************************FIN FUNCIONES AUXILIARES***************

void ShCoeff(Macromolecule *pdb,float r,float *coefr,float *coefi,int bw,float *preC)
{
   pdbIter *iter1=new pdbIter(pdb);
   float radius,mass;
   Atom*at;
   Element *e;
   float theta,lambda,rho;
   float alpha,c;
   Tcoor pos;
   float a=1.9;
   float bw2=bw*bw;

  memset(coefr,0,(unsigned int)(sizeof(float)*(bw2+bw)/2));
  memset(coefi,0,(unsigned int)(sizeof(float)*(bw2+bw)/2));
   for(iter1->pos_atom=0;!iter1->gend_atom();iter1->next_atom())
   {

      at=iter1->get_atom();
      e=at->getElement();
      radius=e->vdw;
      mass=e->weight;
      at->getPosition(pos);
      alpha=(a*a)/(radius*radius);
      c=(mass*a*a*a)/(radius*radius*radius*pow(PDB_PI,3.0/2.0));

      cart2sph(&rho,&theta,&lambda,pos[0],pos[1],pos[2],0,0,0);

      gaussian_agregation(theta,lambda,rho, r,alpha,c, bw,coefr,coefi,preC );
   }
  delete iter1;
}

void ShCoeff(Macromolecule *pdb,float sigma,float r,float *coefr,float *coefi,int bw,float *preC)
{
   pdbIter *iter1=new pdbIter(pdb);
   float mass;
   Atom*at;
   float theta,lambda,rho;
   float alpha,c;
   Tcoor pos;
   float bw2=bw*bw;
   float aux;
  memset(coefr,0,(unsigned int)(sizeof(float)*(bw2+bw)/2));
  memset(coefi,0,(unsigned int)(sizeof(float)*(bw2+bw)/2));
   for(iter1->pos_atom=0;!iter1->gend_atom();iter1->next_atom())
   {

      at=iter1->get_atom();
      at->getPosition(pos);
      mass=12.0;
      aux=sqrt(2.0*PDB_PI)*sigma;
      alpha=(1.0)/(aux*aux);
      c=(mass)/(aux*aux*aux);

      cart2sph(&rho,&theta,&lambda,pos[0],pos[1],pos[2],0,0,0);

      gaussian_agregation(theta,lambda,rho, r,alpha,c, bw,coefr,coefi,preC );
   }
  delete iter1;
}

void ShCoeff_gauss(Macromolecule *pdb,float r,float *coefr,float *coefi,int bw,float *preC)
{
   float sigma;
   pdbIter *iter1=new pdbIter(pdb);
   float radius;
   Atom*at;
   float theta,lambda,rho;
   float alpha,c;
   Tcoor pos;
   float bw2=bw*bw;


  memset(coefr,0,(unsigned int)(sizeof(float)*(bw2+bw)/2));
  memset(coefi,0,(unsigned int)(sizeof(float)*(bw2+bw)/2));
   for(iter1->pos_atom=0;!iter1->gend_atom();iter1->next_atom())
   {

      at=iter1->get_atom();
      at->getPosition(pos);
      sigma=at->getPdbocc();
      alpha=(1.0)/(2*sigma*sigma);
      c=1;//-1.0*at->getPdbfact();
      radius=2*sigma;

      cart2sph(&rho,&theta,&lambda,pos[0],pos[1],pos[2],0,0,0);

      if(radius>fabs(rho-r))
        gaussian_agregation(theta,lambda,rho, r,alpha,c, bw,coefr,coefi,preC );
   }
  delete iter1;
}




