#include <iostream>
#include "MPIManager.h"
#include <mpi.h>

using namespace std;

double MPIManager::startServer(int startMol, int endMol, float* output, int savedPeaks)
{
	
	int tmpRecv;
	int id;
	int size;
	double tempTime;
	MPI_Comm_rank(MPI_COMM_WORLD, &id);
	MPI_Comm_size(MPI_COMM_WORLD, &size);
	size--;
	int endSignalSent = 0;
	double *time = new double[size];
	for (int i=0; i<size; i++){
		time[i]=0.0;
	}

	int mol=startMol;
	int completed=0;
	MPI_Status status;
	int source, type;
	while(completed<endMol-startMol){
		// Tag 1 -> Molecule request
		// Tag 2 -> Data reception
		MPI_Recv(&tmpRecv, 1, MPI_INT, MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD,&status);
		source = status.MPI_SOURCE;
		//cout << "Thread " << source-1 <<" is active" << endl << flush;
		type = status.MPI_TAG;
		switch(type){
			case 1:
				if(mol<endMol){
					// Send molecule number
					MPI_Send(&mol,1,MPI_INT,source,type,MPI_COMM_WORLD);
					//cout << "Sent mol " << mol << " to node " << source << endl << flush;
					mol++;
					cout << (mol*100)/(float)(endMol) << "% done            \r" <<flush;
				}else{
					// Send end signal
					int end = -1;
					MPI_Send(&end,1,MPI_INT,source,1,MPI_COMM_WORLD);
					endSignalSent++;
					//cout << "Sent end signal to node " << source << endl << flush;
				}
				break;
			case 2:
				// Data reception
				MPI_Recv(&output[tmpRecv*savedPeaks*9], savedPeaks*9, MPI_FLOAT, source, 2, MPI_COMM_WORLD,&status);
				// Docking time reception
				MPI_Recv(&tempTime, 1, MPI_DOUBLE, source, 2, MPI_COMM_WORLD,&status);
				time[source-1] += tempTime;
				completed++;
				//cout << "Received data of mol " << tmpRecv+1 << " from node " << source <<  " -> " << completed << " molecules completed\n" << flush;
				break;
		}
	}
	
	while(endSignalSent != size){
		MPI_Recv(&tmpRecv, 1, MPI_INT, MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD,&status);
		source = status.MPI_SOURCE;
		int end = -1;
		MPI_Send(&end,1,MPI_INT,source,1,MPI_COMM_WORLD);
		endSignalSent++;
	}

	double longestTime = time[0];
	for (int i=1; i<size; i++){
		if(time[i]>longestTime){
			longestTime = time[i];
		}
	}
	for (int i=0; i<size; i++){
		cout << "Node " << i << " time: " << time[i] << endl << flush;
	}
	delete [] time;
	return longestTime;
}

int MPIManager::getMol()
{
	MPI_Status status;
	static MPI_Request sendReq;
	static MPI_Request recvReq;
	static int sendActive=0;
	static int recvActive=0;
	static int tmpSend=0;
	static int tmpRecv=0;
	static int numWaits=0; // Number of times the node waits
	static int molComputed=0; // Number of molecules computed
	int mol;
	int finished;

	// Check status of requests
	if(recvActive){
		if(sendActive){
			// If there is any send, it finishes
			MPI_Test(&sendReq,&finished,&status);
			if(!finished){
				MPI_Wait(&sendReq,&status);
				numWaits++;
			}
			sendActive=0;
		}
		// If there is any recv request, data is read here
		MPI_Test(&recvReq,&finished,&status);
		if(!finished){
			MPI_Wait(&recvReq,&status);
			numWaits++;
		}
		recvActive=0;
		// At this point any receive is finished
		mol = tmpRecv;
		if(mol>=0){
			MPI_Isend(&tmpSend,1,MPI_INT,0,1,MPI_COMM_WORLD,&sendReq);
			sendActive=1;
			MPI_Irecv(&tmpRecv,1,MPI_INT,0,1,MPI_COMM_WORLD,&recvReq);
			recvActive=1;
			molComputed++;
		}
	}else{
		// First reference
		MPI_Send(&tmpSend,1,MPI_INT,0,1,MPI_COMM_WORLD);
		MPI_Recv(&tmpRecv,1,MPI_INT,0,1,MPI_COMM_WORLD,&status);
		mol = tmpRecv;
		if(mol>=0){
			//cout << "Asking server for another reference (first time)\n" << flush;
			MPI_Isend(&tmpSend,1,MPI_INT,0,1,MPI_COMM_WORLD,&sendReq);
			sendActive=1;
			MPI_Irecv(&tmpRecv,1,MPI_INT,0,1,MPI_COMM_WORLD,&recvReq);
			recvActive=1;
			molComputed++;
		}
	}
	if(mol<0){ // Print stats
		int id;
		MPI_Comm_rank(MPI_COMM_WORLD, &id);
		printf("Node %d computed %d molecules | Stalls %d times\n", id, molComputed, numWaits);
	}
	return mol;
}

void MPIManager::sendData(int mol, int savedPeaks, float *data, double dockingTime)
{
	MPI_Send(&mol,1,MPI_INT,0,2,MPI_COMM_WORLD);
	MPI_Send(data,savedPeaks*9,MPI_FLOAT,0,2,MPI_COMM_WORLD);
	MPI_Send(&dockingTime,1,MPI_DOUBLE,0,2,MPI_COMM_WORLD);
}