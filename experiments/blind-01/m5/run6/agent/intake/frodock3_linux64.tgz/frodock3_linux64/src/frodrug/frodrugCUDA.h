//#include <cuda_runtime.h>

struct PreSH{
	int num_atoms;
	float max_radius;
	int rho_max;
	float *posx,*posy,*posz;
	//Real and imaginary Spherical Coefficients
	float ***sol_r;
	float ***sol_i;

	// atom dependant variables
	//float *radius;
	float *li;
	float *li2;
	int *type;
	int *rho_down_index;
	int *rho_up_index;
	float *fup;
	float *fdown;
	int *dsx; //

};
const int MAX_LIGAND_ATOMS=128;
void ligToGPU(PreSH *preSH_data, int bw, float *dSolR, float *dSolI);
void createIntegralDrugCUDA(float *dCoeffr, float *dCoeffi,int bw, int num_atoms,int grid_weight, int sizeSpherical, int sizeSomething,float *dMcoefr,float *dMcoefi,float *dSolR,float *dSolI, int num);
void fourierCorrCUDA(int bw, float* dCoeffr, float* dCoeffi, float* dDdd, float* dCoefCorr, int num);
void searchCorrCUDA(int bw, float *in,float *dCorr,float* dPsi,float* dTh, float* dPhi, int num);