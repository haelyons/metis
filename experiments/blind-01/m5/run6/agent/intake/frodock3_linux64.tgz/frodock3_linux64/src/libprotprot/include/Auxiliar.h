#ifndef AUXILIAR_H_
#define AUXILIAR_H_

#ifndef NUM_POT
#define NUM_POT 50
#endif

typedef struct 	/* estructura anónima */
{
  float x,y,z;
  int r,i,j;
} spherical_point;

/**
 * Creation of a spherical objects from tridimensional volumes that represent different values related to a macromolecule.
 * Each spherical object will store a projecxtion of a value
 * The spherical objects will adapt its dimensions to the volume
 * The spherical objects are inverted, so positive values are negatives and negatives are positives. This is necessary for the external docking computation
 * It must be called after pre_volumetric_sampling() function. the positions to project are precomputed.
 *
 *@param vol: reference volume structure. It provides pointers to the different value volumes (weight, charge, ASA and desolvcation potential)
 *@param eval: Shows which spherical objects must be computed (true)
 *@param rmax: Number of the maximum layer in the spherical representation. It is computed from all the necessary values
 *@param rmin: Number of the minimum layer in the spherical representation. It is computed from all the necessary values
 *@param bw: Bandwidth. Grade of the spherical harmonic base
 *@param maxext: Maximum number of necessary layers for each volume value
 *@param cx,cy,cz: center position of the spherical representations (in voxels)
 *@param sph2: Initialized and empty spherical objects to fill up with the projections
 *@param sps: Precomputed collection of spherical positions to project
 *@param num: Number of precomputed positions
 */
vlSpherical ** volumetric_samplingN2( vlVolume ** vol,bool *eval, int * rmax, int * rmin, int bw, int *maxext, float cx, float cy, float cz,
     vlSpherical ** sph2,spherical_point *sps, int num );


/**
 * Creation of the collection of spherical positions where volume properties are projected.
 * It must be called once before calling volumetric_samplingN2
 *@param bw: Bandwidth. Grade of the spherical harmonic base
 *@param maxext: Maximum number of layers in the spherical representation
 *@param rho: Distance between layers in voxels
 *@param sps: Output. Computed collection of spherical positions to project
 *@return Number of precomputed positions
 */
int pre_volumetric_sampling(int bw,int maxext,float rho,spherical_point **sps);



/**
 * Computes the Integral in the Fourier space necessary to compute the correation
 *
 *@param integrali: buffer to store the imaginary part of the integral
 *@param integralr: buffer to store the real part of the integral
 *@param sph: spherical projection of one of the object to correlate
 *@param Mcoefr,Mcoefi: buffer to keep the spherical coefficients of the sph object
 *@param bw: Bandwidth. Grade of the spherical harmonic base
 *@param rmax: Number of the maximum layer in the spherical representation.
 *@param rmin: Number of the minimum layer in the spherical representation.
 *@param steprho: Distance between layers in amstrongs
 *@param SH_layerr,SH_layeri : Precomputed spherical harmonics of the second object to correlate
 *@param radius: radius of the layers in the second object
 */
void createIntegral(float *integrali, float *integralr,vlSpherical *sph,float **Mcoefr,float **Mcoefi,int bw, int rmax,int rmin,float steprho,float **SH_layerr,float **SH_layeri,float *radius);


#endif /*AUXILIAR_H_*/
