#ifndef _OBJECT_AUX_H
#define _OBJECT_AUX_H


#include "libvolume/include/floatops.h"

#define gidz_general(posz,posy,posx,dimy,dimx) ((posz)*(dimx)*(dimy)+(posy)*(dimx)+(posx))

/**
* Spherical coordinates
*/
typedef struct {
  float alpha,betha,rho;
} Tpolar;


typedef struct {
  int alpha,betha,rho;
  float dist;
} Tipolar;

float polar_normal(float x);
int polar_normal(int x,int max);
float polar_normal(float x);
int entorno(float limit,Tpolar punto,float width,float initlambda,int bw, int maxRho, Tipolar *entorno,double *normdist);
#endif
