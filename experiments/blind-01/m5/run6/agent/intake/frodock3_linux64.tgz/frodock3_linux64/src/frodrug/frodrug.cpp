#ifndef LNOF2
#define LNOF2 0.693147180559945309417232121458f
#endif

#ifdef MPI_RELEASE
#include <mpi.h>
#include "MPIManager.h"
#endif

#include <float.h>
#include <cuda_runtime.h>
#include <cuda_profiler_api.h>
#include <cufft.h>
#include <list>

#include <libvolume/include/floatops.h>
#include <libpdb/include/Macromolecule.h>
#include <libpdb/include/pdbIter.h>
#include "libfrm/include/obj_vlsphh.h"
#include "libfrm/include/obj_fsphh.h"
#include "libbessel/include/bessels.h"
#include "libfrm/include/Correlation.h"
#include "libprotprot/include/SCollection.h"
#include "libprotprot/include/PCollection.h"
#include "libprotprot/include/SH_Object.h"


#include "ATimer.h"
#include "frodrugCUDA.h"
#include "PointVoxel.h"

//
// to put dsx h file
//
string atom_ligprot[66]={
	"B",     //0
	"Br.0",  //1
	"Br.i",  //2
	"C.1",   //3
	"C.2",   //4
	"C.3",   //5
	"C.3p",  //6
	"C.3q",  //7
	"C.3s",  //8
	"C.3t",  //9
	"C.am",  //10
	"C.ar",  //11
	"C.ar6", //12
	"C.ar6x",//13
	"C.arp", //14
	"C.co2", //15
	"C.guh", //16
	"C.o",   //17
	"Ca",    //18
	"Cl.0",  //19
	"Cl.i",  //20
	"Co",    //21
	"Cu",    //22
	"F.0",   //23
	"F.i",   //24
	"Fe",    //25
	"I.i",   //26
	"Mg",    //27
	"N.1",   //28
	"N.2n",  //29
	"N.2p",  //30
	"N.2s",  //31
	"N.3n",  //32
	"N.3p",  //33
	"N.3s",  //34
	"N.4h",  //35
	"N.4q",  //36
	"N.aa",  //37
	"N.aat", //38
	"N.amp", //39
	"N.ams", //40
	"N.amt", //41
	"N.ar2", //42
	"N.ar3", //43
	"N.ar3h",//44
	"N.ar6", //45
	"N.arp", //46
	"N.guh", //47
	"N.o2",  //48
	"N.oh",  //49
	"N.sams",//50
	"Ni",    //51
	"O.3ac", //52
	"O.3es", //53
	"O.3et", //54
	"O.3oh", //55
	"O.carb",//56
	"O.co2", //57
	"O.h2o", //58
	"O.n",   //59
	"O.o",   //60
	"P.3",   //61
	"P.o",   //62
	"S.3",   //63
	"S.o",   //64
	"Zn"     //65
};

string atom_fconv[158]={
	"Hac",      //0
	"Honh",     //1
	"Hn",       //2
	"Ho",       //3
	"H0",       //4
	"Car6p",    //5
	"Car6x",    //6
	"Car6",     //7
	"Carp",     //8
	"Carx",     //9
	"Car",      //10
	"C2r3o",    //11
	"C2r3x",    //12
	"C3r3x",    //13
	"C2r3",     //14
	"C3r3",     //15
	"C1n",      //16
	"C1p",      //17
	"C1s",      //18
	"Cco2h",    //19
	"Cco2",     //20
	"Ces",      //21
	"Chal",     //22
	"Cam",      //23
	"Co",       //24
	"Cs",       //25
	"Cgu",      //26
	"Cguh",     //27
	"Cmi",      //28
	"Cmih",     //29
	"Cn",       //30
	"C2p",      //31
	"C2s",      //32
	"C2t",      //33
	"Cet",      //34
	"Cohp",     //35
	"Cohs",     //36
	"Coht",     //37
	"C3n",      //38
	"C3p",      //39
	"C3s",      //40
	"C3t",      //41
	"C3q",      //42
	"Nar6p",    //43
	"Nar6",     //44
	"Narp",     //45
	"Nar2",     //46
	"Nar3",     //47
	"Nar3h",    //48
	"Nr3",      //49
	"Naz",      //50
	"N1",       //51
	"No2",      //52
	"Nohac",    //53
	"Noh",      //54
	"Nims",     //55
	"Nimt",     //56
	"Namp",     //57
	"Nams",     //58
	"Namt",     //59
	"Nsamp",    //60
	"Nsams",    //61
	"Nsamt",    //62
	"Ngu1",     //63
	"Ngu2",     //64
	"Nguh",     //65
	"Nmi1",     //66
	"Nmi2",     //67
	"Nmih",     //68
	"Naap",     //69
	"Naas2",    //70
	"Naas3",    //71
	"Naat2",    //72
	"Naat3",    //73
	"N2n",      //74
	"N2p",      //75
	"N2s",      //76
	"N3n",      //77
	"N3p",      //78
	"N3s",      //79
	"N3t",      //80
	"N4q",      //81
	"N4h",      //82
	"Oar",      //83
	"Or3",      //84
	"Oh2o",     //85
	"On",       //86
	"Onoh",     //87
	"O2co2",    //88
	"O2es",     //89
	"O2hal",    //90
	"Oam",      //91
	"Oco2",     //92
	"O2po",     //93
	"O2so",     //94
	"O2p",      //95
	"O2s",      //96
	"O3po",     //97
	"O3so",     //98
	"Ocarb",    //99
	"Oo",       //100
	"O3ac",     //101
	"Oph",      //102
	"O3oh",     //103
	"O3es",     //104
	"O3eta",    //105
	"O3et",     //106
	"Sar",      //107
	"Sr3",      //108
	"Sthi",     //109
	"So",       //110
	"So2h",     //111
	"So3h",     //112
	"So4h",     //113
	"So2",      //114
	"So3",      //115
	"So4",      //116
	"S2",       //117
	"Ssh",      //118
	"Ss",       //119
	"S3",       //120
	"Pr3",      //121
	"Po",       //122
	"Po2h",     //123
	"Po3h",     //124
	"Po4h",     //125
	"Po2",      //126
	"Po3",      //127
	"Po4",      //128
	"P3",       //129
	"F0",       //130
	"Cl0",      //131
	"Br0",      //132
	"I0",       //133
	"Fi",       //134
	"Cli",      //135
	"Bri",      //136
	"Ii",       //137
	"Li",        //138
	"Na",        //139
	"Mg",        //140
	"Al",        //141
	"Si",        //142
	"K",         //143
	"Ca",        //144
	"Crth",     //145
	"Croh",     //146
	"Mn",        //147
	"Fe",        //148
	"Co",        //149
	"Cu",        //150
	"Zn",        //151
	"Se",        //152
	"Mo",        //153
	"Sn",        //154
	"Ni",        //155
	"Hg",        //156
	"B",         //157
};

//TABLA INICIAL PARA CAMBIAR LOS ATOMOS DEL FCONV PARA EL LIGANDO
int atom_change[158]={
	66, //"X",     //0
	66, //"X",     //1
	66, //"X",     //2
	66, //"X",     //3
	66, //"X",     //4
	14, //"C.arp", //5
	13, //"C.ar6x",//6
	12, //"C.ar6", //7
	14, //"C.arp", //8
	11, //"C.ar",  //9
	11, //"C.ar",  //10
	17, //"C.o",   //11
	4, //"C.2",   //12
	5, //"C.3",   //13
	4, //"C.2",   //14
	5, //"C.3",   //15
	3, //"C.1",   //16
	3, //"C.1",   //17
	3, //"C.1",   //18
	15, //"C.co2h",//19
	15, //"C.co2", //20
	17, //"C.o",   //21
	17, //"C.o",   //22
	10, //"C.am",  //23
	17, //"C.o",   //24
	17, //"C.o",   //25
	16, //"C.guh", //26
	16, //"C.guh", //27
	16, //"C.guh", //28
	16, //"C.guh", //29
	4, //"C.2",   //30
	4, //"C.2",   //31
	4, //"C.2",   //32
	4, //"C.2",   //33
	5, //"C.3",   //34
	8, //"C.3s",  //35
	9, //"C.3t",  //36
	7, //"C.3q",  //37
	5, //"C.3 ",  //38
	6, //"C.3p",  //39
	8, //"C.3s",  //40
	9, //"C.3t",  //41
	7, //"C.3q",  //42
	46, //"N.arp", //43
	45, //"N.ar6", //44
	46, //"N.arp", //45
	42, //"N.ar2", //46
	43, //"N.ar3", //47
	44, //"N.ar3h",//48
	34, //"N.3s",  //49
	28, //"N.1",   //50
	28, //"N.1",   //51
	48, //"N.o2",  //52
	40, //"N.ams", //53
	49, //"N.oh",  //54
	40, //"N.ams", //55
	41, //"N.amt", //56
	39, //"N.amp", //57
	40, //"N.ams", //58
	41, //"N.amt", //59
	50, //"N.sams",//60
	50, //"N.sams",//61
	41, //"N.amt", //62
	47, //"N.guh", //63
	47, //"N.guh", //64
	47, //"N.guh", //65
	47, //"N.guh", //66
	47, //"N.guh", //67
	47, //"N.guh", //68
	37, //"N.aa",  //69
	37, //"N.aa",  //70
	37, //"N.aa",  //71
	38, //"N.aat", //72
	38, //"N.aat", //73
	29, //"N.2n",  //74
	30, //"N.2p",  //75
	31, //"N.2s",  //76
	32, //"N.3n",  //77
	33, //"N.3p",  //78
	34, //"N.3s",  //79
	34, //"N.3t",  //80
	36, //"N.4q",  //81
	35, //"N.4h",  //82
	54, //"O.3et", //83
	54, //"O.3et", //84
	58, //"O.h2o", //85
	59, //"O.n",   //86
	52, //"O.3ac", //87
	57, //"O.2co2",//88
	56, //"O.carb",//89
	56, //"O.carb",//90
	56, //"O.carb",//91
	57, //"O.co2", //92
	56, //"O.carb",//93
	56, //"O.carb",//94
	57, //"O.co2", //95
	57, //"O.co2", //96
	54, //"O.3et", //97
	54, //"O.3et", //98
	56, //"O.carb",//99
	60, //"O.o",   //100
	52, //"O.3ac", //101
	55, //"O.3oh", //102
	55, //"O.3oh", //103
	53, //"O.3es", //104
	54, //"O.3et", //105
	54, //"O.3et", //106
	63, //"S.3",   //107
	63, //"S.3",   //108
	64, //"S.2",   //109
	64, //"S.o",   //110
	64, //"S.o",   //111
	64, //"S.o",   //112
	64, //"S.o",   //113
	64, //"S.o",   //114
	64, //"S.o",   //115
	64, //"S.o",   //116
	64, //"S.2",   //117
	63, //"S.sh",	//118
	63, //"S.3",   //119
	63, //"S.3",   //120
	61, //"P.3",   //121
	62, //"P.o",   //122
	62, //"P.o",   //123
	62, //"P.o",   //124
	62, //"P.o",   //125
	62, //"P.o",   //126
	62, //"P.o",   //127
	62, //"P.o",   //128
	61, //"P.3",   //129
	23, //"F.0",   //130
	19, //"Cl.0",  //131
	1, //"Br.0",  //132
	26, //"I.0",   //133
	24, //"F.i",   //134
	20, //"Cl.i",  //135
	2, //"Br.i",  //136
	26, //"I.i",   //137
	66, //"X",     //138
	66, //"X",	   //139
	27, //"Mg",	   //140
	66, //"X",	   //141
	66, //"X",	   //142
	66, //"X",     //143
	18, //"Ca",    //144
	66, //"X",     //145
	66, //"X",     //146
	66, //"X",     //147
	25, //"Fe",    //148
	21, //"Co",    //149
	22, //"Cu",    //150
	65, //"Zn",    //151
	66, //"X",     //152
	66, //"X",     //153
	66, //"X",     //154
	51, //"Ni",    //155
	66, //"X",     //156
	0, //"B",     //157
};

#include <cmdl/CmdLine.h>
using namespace TCLAP;


#define MAX_NUM_MAPS 50
//#define MAX_LIGAND_ATOMS 120
double CUDATime = 0.0; // JUST FOR PROFILING. REMOVE ME WHEN TESTED
int id = 0; // MPI Node
//Parameters
char in_maps[MAX_NUM_MAPS] [500];
//input pdbs
char in_lig_pdb[100];
char in_lig_pdb_ref[100];
char in_rec_pdb[100];
char in_output[100];//output file
int  in_bw=16;
float in_vw;
float in_ew;
float in_er=1.3;
float in_box_l=10;
int   in_limit_max_layer;
float in_ligand_max_length;
float in_radius_max_length;
float in_width=1.0;
float in_box_s=1.0;
float in_sw=1.0;
float in_hw=1.0;
float in_th=-1;
bool  in_saveT;
int in_conv;
float in_eaux[MAX_NUM_MAPS-4];
int pot_type[MAX_NUM_MAPS-4];
int in_max_pot=0;
int num_maps;
ATimer CUDAComputeTimer;
bool CUDAFlag;

//struct PreSH{
//	int num_atoms;
//	float max_radius;
//	int rho_max;
//	float *posx,*posy,*posz;
//	//Real and imaginary Spherical Coefficients
//	float ***sol_r;
//	float ***sol_i;
//
//	// atom dependant variables
//	//float *radius;
//	float *li;
//	float *li2;
//	int *type;
//	int *rho_down_index;
//	int *rho_up_index;
//	float *fup;
//	float *fdown;
//	int *dsx; //
//
//};

// constants....
float *SHC1, **SHC3, **SHC2;
float *TCOS,*TSIN;

extern void cart2sph(float *rad,float *theta,float *lambda,float posx,float posy,float posz, float cx,float cy,float cz);

void parseOptions( int argc, char * * argv )
{
	string temp;
	CmdLine cmd( argv[0], "   ", "4.0" );
	char pot_name[100];

	try
	{
		// Define required arguments no labeled
		//
		UnlabeledValueArg < string > rec_pdb( "recept_pdb", "receptor pdb input filename", "default", "recept_pdb" );
		cmd.add( rec_pdb );

		UnlabeledValueArg < string > pdb( "drug_pdb", "drug pdb input filename", "default", "drug_pdb" );
		cmd.add( pdb );

		//
		// Define labeled arguments
		//
		ValueArg < string > output( "o", "out", "Solutions output filename (default: frodock_output.dat).", false, "frodock_output.dat", "string" );
		cmd.add( output );

		ValueArg < string > pot( "p", "pot", "Potentials file", false, "", "string" );
		cmd.add( pot );

		ValueArg < float > vw( "W", "vw", "Van der Waals term weight (default: 1.0).", false, 1.0, "float" );
		cmd.add( vw );

		ValueArg < string > vdwC( "w", "", "vdw potential file (default: Created from receptor pdb file).", false, "", "string" );
		cmd.add( vdwC );

		ValueArg < string > elec( "e", "elec", "electrostatic potential file (default: Created from receptor pdb file).", false, "", "string" );
		cmd.add( elec );

		ValueArg < float > ew( "E", "ew", "Electrostatic term weight (default: 0.0).", false, 0.0, "float" );
		cmd.add( ew );

		ValueArg < int > bw( "","bw", "Bandwidth of the spherical harmonic representation. Define rotational stepsize (default: 16. Rotational stepsize ~11º) ",false, 16, "int" );
		cmd.add( bw );

		ValueArg < float > box_l( "","box_l", "Box length (10.0) ",false, 10.0, "int" );
		cmd.add( box_l );

		ValueArg < float > box_s( "","box_s", "Box stepsize (1) ",false, 1.0, "float" );
		cmd.add( box_s );

		ValueArg < float > lw( "","lw", "Layer width (1) ",false, 1.0, "float" );
		cmd.add( lw );

		ValueArg < float > er( "","er", " Factor radius for generating initial search positions ",false, 1.3, "float" );
		cmd.add( er );

		ValueArg < int > conv( "c","conv", "Atom convention [0: CHARMM, 1: ICM 2: Sybyl] ",false, 2, "float" );
		cmd.add( conv );

		ValueArg < string > desol( "d", "desolv", "Desolvation potential maps for receptor .", false,"", "string" );
		cmd.add( desol );

		ValueArg < float > sw( "D", "dw", "Desolvation term weight (default: 0.5).", false, 0.5, "float" );
		cmd.add( sw );

		ValueArg < string > hydro( "", "hydro", "Hydrophobic potential maps for receptor.", false,"", "string" );
		cmd.add( hydro );

		ValueArg < float > hw( "", "hw", "Hydrophobic term weight (default: 0.5).", false, 0.5, "float" );
		cmd.add( hw );

		ValueArg<int> nc("","nc", "aa name convention of the aminoacid atoms ( iupac(0), pdb(1))",false,0,"int");
		cmd.add( nc );

		ValueArg < float > th( "","th", "Electrostatic potential threshold (default: No threshold) ",false, -1.0, "float" );
		cmd.add( th );

		SwitchArg saveT("s","save", "Save translational point is a pdb file", false);
		cmd.add( saveT );

		SwitchArg gpu("g","GPU", "Enable GPU", false);
		cmd.add( gpu );

		ValueArg<string> fref("","ref", "Reference ligand to compute center and Rmax",false,"","string");
		cmd.add( fref );

		// Parse the command line.
		cmd.parse( argc, argv );

		//copy parameters to global variables
		strcpy( in_lig_pdb, ( ( temp = pdb.getValue() ).c_str() ) );
		strcpy(in_rec_pdb, ( ( temp = rec_pdb.getValue() ).c_str() ) );

		if (fref.isSet())
			strcpy(in_lig_pdb_ref,((temp=fref.getValue()).c_str()));


		strcpy(in_output,(temp=output.getValue()).c_str());
		strcpy( in_maps[0], ( ( temp = vdwC.getValue() ).c_str() ) );
		//strcpy( in_maps[1], ( ( temp = elec.getValue() ).c_str() ) );
		//strcpy( in_maps[2], ( ( temp = desol.getValue() ).c_str() ) );
		strcpy( in_maps[1], ( ( temp = hydro.getValue() ).c_str() ) );

		in_bw=bw.getValue();
		in_box_l=box_l.getValue();
		in_box_s= box_s.getValue();
		in_width=lw.getValue();
		in_vw=vw.getValue();
		in_ew= ew.getValue();//*(9.0/0.3);
		in_er=er.getValue();
		in_conv=nc.getValue();
		in_sw= sw.getValue();
		in_hw= hw.getValue();
		in_th= th.getValue();

		if(saveT.isSet()){
			in_saveT=true;
		}else{
			in_saveT=false;
		}

		if(gpu.isSet()){
			CUDAFlag=true;
		}else{
			CUDAFlag=false;
		}


		in_max_pot=0;
		if(pot.isSet())
		{
			strcpy(pot_name,( ( temp = pot.getValue() ).c_str() ) );
			FILE *faux;
			int i;
			bool end_pot=false;
			faux=fopen(pot_name,"rt");

			if(faux==NULL)
			{
				fprintf(stderr,"Error: -p file argument cannot be read: %s\n",pot_name);
				exit(1);
			}

			i=4;
			do{

				if( fscanf(faux,"%s %f %d\n",&(in_maps[i]),&(in_eaux[i-4]), &(pot_type[i-4])) != EOF)
				{
					//fprintf(stderr,"%s \n%f %d\n",in_maps[i],in_eaux[i-4], pot_type[i-4]);
					i++;
				}
				else
					end_pot=true;

				if(feof(faux))
					end_pot=true;

			}while(!end_pot);
			in_max_pot=i-4;
			fclose(faux);
		}


	}
	catch ( ArgException & e )
	{
		cout << "  Error->" << e.error() << " " << e.argId() << endl;
	}

	//cmd.~CmdLine();

}

/**
* Interpolates a volume in a spherical representation. The spherical
* representation has the center in a given point
* It is the slow version of the algorithm. It computes radius information about
* the external maximum/minimum radius, the internal maximum/minimum radius and
* maximum/minimum zero readius.
*
* @param vol: Volume to interpolate
* @param in: external radius. Maximum and minimum radius of the external surface
* @param bw: Bandwidth of the spherical representation
* @param maxext: Maximum number of layers allowed
* @param cx,cy,cz: Center of the spherical representation
* @param sph2: Shperical object that stores the representation. If NULL the method creates a new object
* @param rho: Distance between layers
*/
vlSpherical *volumetric_sampling_slow_drug(vlVolume *vol, int in[], int bw, int maxext,float cx, float cy,float cz,float rho,vlSpherical *sph2)
{
	/* performs the sampling in spherical coordinates */

	int i, j, r, size;
	float stsl, stcl, ct, theta, st;
	float lambda,initlambda;
	float x, y, z;
	float a, b, c;
	int x1, y1, z1;
	float f111, f112, f121, f122, f211, f212, f221, f222;
	float aux;
	int g_extx, g_exty, g_extz;
	int g_extx1, g_exty1, g_extz1;
	vlSpherical *sph;

	int bw_1,bw_12,bw1,bw12,index_stsl,index_stcl;

	//Valores predeterminados
	size=(bw<<1);
	bw_1=bw-1;
	bw_12=bw_1*bw_1;
	bw1=bw+1;
	bw12=bw1*bw1;
	index_stsl=((bw_1)*(4*bw_12-1)/3);
	index_stcl=((bw_1)*(4*bw_12-1)/3);

	/* creacion del objeto que representa al volumen en coordenadas esfericas */
	if(sph2==NULL)
		sph= new vlSpherical(bw,maxext);
	else
		sph=sph2;

	g_extx=vol->dim().x(); g_extx1= g_extx -1;
	g_exty=vol->dim().y(); g_exty1= g_exty -1;
	g_extz=vol->dim().z(); g_extz1= g_extz -1;


	in[0]=maxext;
	in[1]=0;



	initlambda=M_PI/bw;
	for(i=0;i<size;i++) /* i represents latitude values */
	{
		theta= 0.5*M_PI*(i+0.5)/bw;
		st=sin(theta)*rho; ct=cos(theta)*rho;
		for(j=0,lambda=0; j<size;j++,lambda+=initlambda)         /* j represents longitude values */
		{
			stsl=st*sin(lambda);

			stcl=st*cos(lambda);
			for(r=0, x = cx, y=cy, z=cz;r<maxext;r++, x+=stcl, y+=stsl, z+=ct)
			{
				if(x<0.0 || x>=g_extx1 || y<0.0 || y>=g_exty1 || z<0.0 || z>=g_extz1) {
					for(;r<maxext;r++)
						sph->setP(r,i,j,0.0);
					break;
				}

				/* interpolation */
				x1=floor(x); y1=floor(y); z1=floor(z);
				a=x-x1; b=y-y1; c=z-z1;
				f111=vol->getVoxelSpecial(z1*g_extx*g_exty + y1*g_extx + x1);
				f112=vol->getVoxelSpecial((z1+1)*g_extx*g_exty + y1*g_extx + x1);
				f121=vol->getVoxelSpecial(z1*g_extx*g_exty + (y1+1)*g_extx + x1);
				f122=vol->getVoxelSpecial((z1+1)*g_extx*g_exty + (y1+1)*g_extx + x1);
				f211=vol->getVoxelSpecial(z1*g_extx*g_exty + y1*g_extx + x1+1);
				f212=vol->getVoxelSpecial((z1+1)*g_extx*g_exty + y1*g_extx + x1+1);
				f221=vol->getVoxelSpecial(z1*g_extx*g_exty + (y1+1)*g_extx + x1+1);
				f222=vol->getVoxelSpecial((z1+1)*g_extx*g_exty + (y1+1)*g_extx + x1+1);

				aux=((1-a)*((1-b)*((1-c)*f111+c*f112)+b*((1-c)*f121+c*f122))+a *((1-b)*((1-c)*f211+c*f212)+b*((1-c)*f221+c*f222)) );
				sph->setP(r,i,j,-aux);
			}
		}
	}



	for(i=0;i<size;i++){
		for(j=0;j<size;j++)
		{

			for(r=0;r<maxext;r++)
				if(sph->getP(r,i,j)!=0.0){
					if(r< in[0]) in[0]=r;
					if(r> in[1]) in[1]=r;
					//break;
				}
		}
	}

	return sph;
}

/**
* Computes the Integral in the Fourier space necessary to compute the correlation
*
*@param integrali: buffer to store the imaginary part of the integral
*@param integralr: buffer to store the real part of the integral
*@param sph: spherical projection of one of the object to correlate
*@param Mcoefr,Mcoefi: buffer to keep the spherical coefficients of the sph object
*@param bw: Bandwidth. Grade of the spherical harmonic base
*@param rmax: Number of the maximum layer in the spherical representation.
*@param rmin: Number of the minimum layer in the spherical representation.
*@param steprho: Distance between layers in amstrongs
*@param mol: Macromolecule
*@param center: Center of the spherical representation of the Macromolecule
*@param associatedC: precomputed d coefficients.
*@param cont_ind: Number of positions in integral buffer
*@param ind_coef: Collection of positions in spherical coeficients
*@param ind_i_p: Collection of positions in Integral Buffer (+(l-n))
*@param ind_i_n: Collection of positions in Integral Buffer (-(l-n))
*/
void pre_Integral(int bw, int *cont_ind,  int **ind_coef, int **ind_i_p , int **ind_i_n)
{

	int l,tl,n,m,i=0;
	int init;
	*cont_ind=0;

	for(l=0, tl=0;l<bw;l++, tl+=2)
	{
		for(n=l;n<=tl;n++)
		{
			for(m=l;m<=tl;m++)
			{
				*cont_ind=*cont_ind+1;
			}
		}
	}


	(*ind_coef)=(int*)malloc(sizeof(int)* (*cont_ind));
	(*ind_i_p)=(int*)malloc(sizeof(int)* (*cont_ind));
	(*ind_i_n)=(int*)malloc(sizeof(int)* (*cont_ind));
	int j=0;
	for(l=0, tl=0;l<bw;l++, tl+=2)
	{
		init=(l*(tl*tl-1)/3 + (l*l) )/2 ;

		for(m=l;m<=tl;m++)
		{
			for(n=l;n<=tl;n++)
			{
				(*ind_coef)[j]=seanindex(m-l,l,bw);
				(*ind_i_p)[i]=(init+(m-l)*(tl+1))+l+(n-l);
				(*ind_i_n)[i]=(init+(m-l)*(tl+1))+l-(n-l);
				i++;
			}
			j++;
		}
	}

}

void pre_IntegralBack(int bw, int *cont_ind,  int **ind_coef, int **ind_i_p , int **ind_i_n)
{

	int l,tl,n,m,i=0;
	int init;
	*cont_ind=0;

	for(l=0, tl=0;l<bw;l++, tl+=2)
	{
		for(n=l;n<=tl;n++)
		{
			for(m=l;m<=tl;m++)
			{
				*cont_ind=*cont_ind+1;
			}
		}
	}


	(*ind_coef)=(int*)malloc(sizeof(int)* (*cont_ind));
	(*ind_i_p)=(int*)malloc(sizeof(int)* (*cont_ind));
	(*ind_i_n)=(int*)malloc(sizeof(int)* (*cont_ind));

	for(l=0, tl=0;l<bw;l++, tl+=2)
	{
		init=(l*(tl*tl-1)/3 + (l*l) )/2 ;
		for(n=l;n<=tl;n++)
		{
			for(m=l;m<=tl;m++)
			{
				(*ind_coef)[i]=seanindex(m-l,l,bw);
				(*ind_i_p)[i]=(init+(m-l)*(tl+1))+l+(n-l);
				(*ind_i_n)[i]=(init+(m-l)*(tl+1))+l-(n-l);
				i++;
			}
		}
	}

}

void createIntegral_drug(float *integrali, float *integralr,float **Mcoefr,float **Mcoefi,int bw,int *ind_coef, int *ind_i_p , int *ind_i_n,PreSH *preSH_data, float grid_weight,int grid_type)
{

	int l,m,n,tl,i,j;
	float sphericali, sphericalr;
	float AA,BB,CC,DD, e_weight;
	float SH[2];
	float fup,fdown;
	int rho_down_index,rho_up_index;

	/*  float factor=0;
	for(j=0;j<preSH_data->num_atoms;j++)
	factor+=grid_weight*preSH_data->li[j];

	factor/=preSH_data->num_atoms;
	factor=1.0;
	*/
	for(j=0;j<preSH_data->num_atoms;j++)
	{

		e_weight=grid_weight*preSH_data->li[j];
		if (grid_type==1)
			e_weight=grid_weight*preSH_data->li2[j];
		// e_weight=1.0;

		// lineal interpolation
		//		rho_down_index=(int)floor(preSH_data->radius[j]);
		//		rho_up_index=rho_down_index+1;
		//		fup=1- (rho_up_index-preSH_data->radius[j]);
		//		fdown=1-fup;
		rho_down_index=preSH_data->rho_down_index[j];
		rho_up_index=preSH_data->rho_up_index[j];
		fup=preSH_data->fup[j];
		fdown=preSH_data->fdown[j];
		//float flayer=(preSH_data->rho_max*preSH_data->rho_max);
		//fprintf(stdout,"atm> %d %f %d-%d %f-%f\n", j, e_weight,rho_down_index, rho_up_index,fup,fdown);
		// fprintf(stdout,"atm> %f\n", Mcoefr[18][ind_coef[100]]);
		i=0; int coefInd=0;
		if(e_weight!=0)
		{
			for(l=0, tl=0;l<bw;l++, tl+=2)
			{
				for(m=l;m<=tl;m++)
				{
					sphericalr=(fdown)*Mcoefr[rho_down_index][ind_coef[coefInd]]+(fup)*Mcoefr[(int)rho_up_index][ind_coef[coefInd]];
					sphericali=(fdown)*Mcoefi[rho_down_index][ind_coef[coefInd]]+(fup)*Mcoefi[(int)rho_up_index][ind_coef[coefInd]];

					for(n=0;n<=l;n++)
					{
						SH[0]=preSH_data->sol_r[j][n][l-n]*e_weight;
						SH[1]=preSH_data->sol_i[j][n][l-n]*e_weight;

						AA=SH[0]*sphericalr;
						BB=SH[1]*sphericali;
						CC=SH[1]*sphericalr;
						DD=SH[0]*sphericali;

						*(integralr+ind_i_p[i]) +=AA-BB;
						*(integrali+ind_i_p[i]) +=CC+DD;
						if(n!=0)
						{
							if(n%2!=0)
							{
								*(integralr+ind_i_n[i]) +=(-AA)-BB;
								*(integrali+ind_i_n[i]) +=CC-DD;
							}
							else
							{
								*(integralr+ind_i_n[i]) +=AA+BB;
								*(integrali+ind_i_n[i]) +=(-CC)+DD;
							}
						}
						i++;
					}
					coefInd++;
				} 
			}
		}
	}
}

void createIntegral_drugBackup(float *integrali, float *integralr,float **Mcoefr,float **Mcoefi,int bw,int *ind_coef, int *ind_i_p , int *ind_i_n,PreSH *preSH_data, float grid_weight,int grid_type)
{

	int l,m,n,tl,i,j;
	float sphericali, sphericalr;
	float AA,BB,CC,DD, e_weight;
	float SH[2];
	float fup,fdown;
	int rho_down_index,rho_up_index;

	/*  float factor=0;
	for(j=0;j<preSH_data->num_atoms;j++)
	factor+=grid_weight*preSH_data->li[j];

	factor/=preSH_data->num_atoms;
	factor=1.0;
	*/
	for(j=0;j<preSH_data->num_atoms;j++)
	{

		e_weight=grid_weight*preSH_data->li[j];
		if (grid_type==1)
			e_weight=grid_weight*preSH_data->li2[j];
		// e_weight=1.0;

		// lineal interpolation
		//		rho_down_index=(int)floor(preSH_data->radius[j]);
		//		rho_up_index=rho_down_index+1;
		//		fup=1- (rho_up_index-preSH_data->radius[j]);
		//		fdown=1-fup;
		rho_down_index=preSH_data->rho_down_index[j];
		rho_up_index=preSH_data->rho_up_index[j];
		fup=preSH_data->fup[j];
		fdown=preSH_data->fdown[j];
		//float flayer=(preSH_data->rho_max*preSH_data->rho_max);
		//fprintf(stdout,"atm> %d %f %d-%d %f-%f\n", j, e_weight,rho_down_index, rho_up_index,fup,fdown);
		// fprintf(stdout,"atm> %f\n", Mcoefr[18][ind_coef[100]]);
		i=0;
		if(e_weight!=0)
			for(l=0, tl=0;l<bw;l++, tl+=2)
			{
				for(n=0;n<=l;n++)
				{
					//Old version for SH computation
					//computeSH(l,n-l, theta, lambda, SH,associatedC);
					SH[0]=preSH_data->sol_r[j][n][l-n]*e_weight;
					SH[1]=preSH_data->sol_i[j][n][l-n]*e_weight;

					for(m=l;m<=tl;m++)
					{

						sphericalr=(fdown)*Mcoefr[rho_down_index][ind_coef[i]]	+(fup)*Mcoefr[(int)rho_up_index][ind_coef[i]];
						sphericali=(fdown)*Mcoefi[rho_down_index][ind_coef[i]]	+(fup)*Mcoefi[(int)rho_up_index][ind_coef[i]];

						AA=SH[0]*sphericalr;
						BB=SH[1]*sphericali;
						CC=SH[1]*sphericalr;
						DD=SH[0]*sphericali;

						*(integralr+ind_i_p[i]) +=AA-BB;
						*(integrali+ind_i_p[i]) +=CC+DD;
						if(n!=0)
						{
							if(n%2!=0)
							{
								*(integralr+ind_i_n[i]) +=(-AA)-BB;
								*(integrali+ind_i_n[i]) +=CC-DD;
							}
							else
							{
								*(integralr+ind_i_n[i]) +=AA+BB;
								*(integrali+ind_i_n[i]) +=(-CC)+DD;
							}
						}
						i++;

					}
				}
			}

	}


}


void precompute_SH(int bw,float theta, float lambda, PreSH *preSH_data,int atom)
{
	int l,m;
	//	float *tcos,*tsin;

	float ex,why;
	float sofar[2];
	int index,size,sizetemp;
	float aux,oneback,twoback;
	bool jump;

	//	tcos=(float*)malloc(sizeof(float)*bw);
	//	tsin=(float*)malloc(sizeof(float)*bw);


	if(theta >=M_PI)
		theta-=0.000000001;

	TCOS[0]=1.0; // cos(0.0);
	TSIN[0]=0.0; // sin(0.0);

	for(l=1;l<bw;l++)
	{   ex=l*lambda;
	TCOS[l]=cos(ex);
	TSIN[l]=sin(ex);

	}


	for(l=1;l<bw;l++)
	{
		memset(preSH_data->sol_r[atom][l],0,sizeof(float)*(bw-l));
		memset(preSH_data->sol_i[atom][l],0,sizeof(float)*(bw-l));
	}

	ex=cos(theta);
	why=sin(theta);


	for(m=0;m<bw;m++)
	{
		jump=false;

		if(why==0)
		{
			if(m==0)
			{
				sofar[0]=SHC1[0];
				size=0;
			}
			else
				jump=true;

		}
		else
		{
			size=(int) (m)*log(why) /LNOF2;
			sofar[0]=SHC1[m]*exp((m)*log(why) - size*LNOF2);
			sofar[0]=(float)frexp((double)sofar[0],&sizetemp);
			size+=sizetemp;
		}

		if(!jump)
		{
			//case index==0
			aux=(float)ldexp((double)sofar[0],size)/2.5066;
			if(m%2!=0)
				aux*=-1.0;
			preSH_data->sol_r[atom][m][0]=TCOS[m]*aux;
			preSH_data->sol_i[atom][m][0]=TSIN[m]*aux;

			//case index==1
			oneback=2.0*sqrt((0.5+m)*(0.5+1.0/(2.0*m+1.0)));
			sofar[1]=oneback*sofar[0]*ex;
			frexpf(fabs(sofar[0])+fabs(sofar[1]),&sizetemp);
			size+=sizetemp;
			sofar[0]=(float)ldexp((double)sofar[0],-sizetemp);
			sofar[1]=(float)ldexp((double)sofar[1],-sizetemp);
			aux=(float)ldexp((double)sofar[1],size)/2.5066;
			if(m%2!=0)
				aux*=-1.0;
			if(m!=bw-1){
				preSH_data->sol_r[atom][m][1]=TCOS[m]*aux;
				preSH_data->sol_i[atom][m][1]=TSIN[m]*aux;
			}

			for(index=2;index<(bw-m);index++)
			{
				//oneback=2*sqrt((1.0+(m-0.5)/index)*(1.0-(m-0.5)/(2.0*m+index)));
				//twoback=-sqrt((1-1.0/index)*(1-1.0/(2*m+index)) * (1+4.0/(2*index+2*m-3)));
				oneback=SHC2[m][index];
				twoback=SHC3[m][index];
				sofar[index%2]=oneback*ex*sofar[(index-1)%2]+twoback*sofar[(index-2)%2];
				frexp(fabs(sofar[0])+fabs(sofar[1]),&sizetemp);
				size+=sizetemp;
				sofar[0]=ldexp(sofar[0],-sizetemp);
				sofar[1]=ldexp(sofar[1],-sizetemp);
				aux=(float)ldexp((double)sofar[index%2],size)/2.5066;
				if(m%2!=0)
					aux*=-1.0;
				preSH_data->sol_r[atom][m][index]=TCOS[m]*aux;
				preSH_data->sol_i[atom][m][index]=TSIN[m]*aux;

			}
		}
	}
}

vlVolume *ray_tracer(vlVolume *volume, bool closest)
{

	vlVolume *result;
	//Kernel Laplaciano


	float voxel, voxel1, voxel2,voxel3;
	int stepx,stepy,stepz;
	int offset, offset1, offset2;


	float avox = volume->units().x();
	float dray = 100.0; //tamaño rayo
	if(closest)
		dray = 20.0;
	int limvox = ceil(dray/avox);

	int shell1=2,shell0=1;
	int cont=0;
	int i,j,k,b,c;
	int x_m=0, y_m=0, z_m=0;
	float ray_x_mod=0.0, ray_y_mod=0.0, ray_z_mod=0.0;
	float lim_x=0.0, lim_y=0.0, lim_z=0.0;
	int previousvoxel[3];
	int vecino_i=0;
	int vecino_j=0;
	int vecino_k=0;
	int vect_i, vect_j, vect_k;
	float val;
	stepx=volume->stepping().x();
	stepy=volume->stepping().y();
	stepz=volume->stepping().z();
	vlDim dim=volume->dim();
	float norma1;

	//Memory buffers
	int ray[98][3]; // 1st
	int ray_0[26][3];
	float ray_unit[98][3];
	int next2[98][3];
	double delta2[98][3];
	double espacio2[98][3];
	double espacio2_m[98][3];
	int ***voxelf;
	float **distance;


	//Filling ray_0
	cont=0;
	for(i=-shell0;i<=shell0;i++)
	{
		for(int j=-shell0;j<=shell0;j++)
		{
			for(int k=-shell0;k<=shell0;k++)
				if( !(i==0 && j==0 && k==0) )
				{
					ray_0[cont][0]=i ;
					ray_0[cont][1]=j ;
					ray_0[cont][2]=k ;

					cont++;
				}
		}
	}

	//Filling ray
	cont=0;
	for( i=-shell1;i<=shell1;i++)
	{
		for( j=-shell1;j<=shell1;j++)
		{
			for( k=-shell1;k<=shell1;k++)
				if( (i==2 || i==-2 || j==2 || j==-2 || k==2 || k==-2)) //&& (ii%2==1 || ii%2==-1 || jj%2==1 || jj%2==-1 || kk%2==1 || kk%2==-1) )
				{
					ray[cont][0]=i ;
					ray[cont][1]=j ;
					ray[cont][2]=k ;
					cont++;
				}
		}
	}

	//Filling ray_unit
	for( i=0;i<98;i++)
	{
		norma1=sqrt( (float)((ray[i][0]*ray[i][0])+(ray[i][1]*ray[i][1])+(ray[i][2]*ray[i][2])) );
		ray_unit[i][0]=ray[i][0]/norma1;
		ray_unit[i][1]=ray[i][1]/norma1;
		ray_unit[i][2]=ray[i][2]/norma1;
	}
	//Filling next2, delta2 & espacio2
	for ( i=0; i<98; i++)
	{
		for ( j=0; j<3; j++)
		{
			if (ray_unit[i][j]>0.0)
				next2[i][j]=1.0;
			else
				next2[i][j]=-1.0;

			if (ray_unit[i][j]==0.0)
			{
				delta2[i][j]=0.0;
				espacio2[i][j]=1000;
			}
			else
			{
				delta2[i][j]=(avox*1.0)/(ray_unit[i][j]);
				espacio2[i][j]=(avox/2.0)/(ray_unit[i][j]);
			}
			if (espacio2[i][j]>=0)
				espacio2_m[i][j]=espacio2[i][j];
			else
			{
				espacio2_m[i][j]=-espacio2[i][j];
				delta2[i][j]=-delta2[i][j];
			}
		}
	}


	//Allocating memory for voxelf and distance
	voxelf=(int***)malloc(sizeof(int**)*98);
	distance=(float**)malloc(sizeof(float*)*98);
	for ( j=0; j<98; j++)
	{
		voxelf[j]=(int**)malloc(sizeof(int*)*3*limvox);
		distance[j]=(float*)malloc(sizeof(float)*3*limvox);
		for ( k=0; k<3*limvox; k++)
		{
			voxelf[j][k]=(int*)malloc(sizeof(int)*3);
			voxelf[j][k][0]=0;
			voxelf[j][k][1]=0;
			voxelf[j][k][2]=0;
			distance[j][k]=FLT_MAX;
		}
	}


	//Filling voxelf
	for (i=0; i<98; i++)
	{
		j=0;
		do{
			if(j==0)
				previousvoxel[0]=previousvoxel[1]=previousvoxel[2]=0;
			else
			{
				previousvoxel[0]=voxelf[i][j-1][0];
				previousvoxel[1]=voxelf[i][j-1][1];
				previousvoxel[2]=voxelf[i][j-1][2];
			}

			if (espacio2_m[i][0]<espacio2_m[i][1])
			{
				if (espacio2_m[i][0]>espacio2_m[i][2])
				{
					voxelf[i][j][2]=previousvoxel[2]+next2[i][2];
					espacio2_m[i][2]=espacio2_m[i][2]+delta2[i][2];

					voxelf[i][j][0]=previousvoxel[0];
					voxelf[i][j][1]=previousvoxel[1];
				}
				else if(espacio2_m[i][0]==espacio2_m[i][2])
				{
					voxelf[i][j][2]=previousvoxel[2]+next2[i][2];
					espacio2_m[i][2]=espacio2_m[i][2]+delta2[i][2];

					voxelf[i][j][0]=previousvoxel[0]+next2[i][0];
					espacio2_m[i][0]=espacio2_m[i][0]+delta2[i][0];

					voxelf[i][j][1]=previousvoxel[1];
				}
				else
				{
					voxelf[i][j][0]=previousvoxel[0]+next2[i][0];
					espacio2_m[i][0]=espacio2_m[i][0]+delta2[i][0];

					voxelf[i][j][1]=previousvoxel[1];
					voxelf[i][j][2]=previousvoxel[2];
				}
			}
			else if(espacio2_m[i][0]>espacio2_m[i][1])
			{
				if(espacio2_m[i][1]>espacio2_m[i][2])
				{
					voxelf[i][j][2]=previousvoxel[2]+next2[i][2];
					espacio2_m[i][2]=espacio2_m[i][2]+delta2[i][2];

					voxelf[i][j][0]=previousvoxel[0];
					voxelf[i][j][1]=previousvoxel[1];
				}
				else if(espacio2_m[i][1]==espacio2_m[i][2])
				{
					voxelf[i][j][2]=previousvoxel[2]+next2[i][2];
					espacio2_m[i][2]=espacio2_m[i][2]+delta2[i][2];

					voxelf[i][j][1]=previousvoxel[1]+next2[i][1];
					espacio2_m[i][1]=espacio2_m[i][1]+delta2[i][1];

					voxelf[i][j][0]=previousvoxel[0];
				}
				else
				{
					voxelf[i][j][1]=previousvoxel[1]+next2[i][1];
					espacio2_m[i][1]=espacio2_m[i][1]+delta2[i][1];

					voxelf[i][j][0]=previousvoxel[0];
					voxelf[i][j][2]=previousvoxel[2];
				}
			}
			else
			{
				if (espacio2_m[i][0]==espacio2_m[i][1])
				{
					if(espacio2_m[i][0]==espacio2_m[i][2])
					{
						voxelf[i][j][2]=previousvoxel[2]+next2[i][2];
						espacio2_m[i][2]=espacio2_m[i][2]+delta2[i][2];

						voxelf[i][j][1]=previousvoxel[1]+next2[i][1];
						espacio2_m[i][1]=espacio2_m[i][1]+delta2[i][1];

						voxelf[i][j][0]=previousvoxel[0]+next2[i][0];
						espacio2_m[i][0]=espacio2_m[i][0]+delta2[i][0];
					}
					else if(espacio2_m[i][0]<espacio2_m[i][2])
					{
						voxelf[i][j][1]=previousvoxel[1]+next2[i][1];
						espacio2_m[i][1]=espacio2_m[i][1]+delta2[i][1];

						voxelf[i][j][0]=previousvoxel[0]+next2[i][0];
						espacio2_m[i][0]=espacio2_m[i][0]+delta2[i][0];

						voxelf[i][j][2]=previousvoxel[2];
					}
					else
					{
						voxelf[i][j][2]=previousvoxel[2]+next2[i][2];
						espacio2_m[i][2]=espacio2_m[i][2]+delta2[i][2];

						voxelf[i][j][0]=previousvoxel[0];
						voxelf[i][j][1]=previousvoxel[1];
					}
				}
			}


			x_m=abs(voxelf[i][j][0]);
			y_m=abs(voxelf[i][j][1]);
			z_m=abs(voxelf[i][j][2]);

			ray_x_mod=fabsf(ray_unit[i][0]);
			ray_y_mod=fabsf(ray_unit[i][1]);
			ray_z_mod=fabsf(ray_unit[i][2]);

			lim_x=(limvox-avox)*ray_x_mod;
			lim_y=(limvox-avox)*ray_y_mod;
			lim_z=(limvox-avox)*ray_z_mod;
			//fprintf(stdout,"j=%d lim=%d\n",j,3*limvox);
			j++;

		}while( ((float)x_m<=(lim_x)) &&  ((float)y_m<=(lim_y)) && ((float)z_m<=(lim_z)) );
	}

	// precalculate distances
	for (i=0; i<98; i++)
	{
		for ( k=0; k<3*limvox; k++)
		{
			if (  (voxelf[i][k][0]!=0) || (voxelf[i][k][1]!=0) || (voxelf[i][k][2]!=0) )
			{
				//fprintf(stdout,"flag0 %d %d\n",i,k);

				distance[i][k]=avox*sqrt((float)((voxelf[i][k][0])*(voxelf[i][k][0]) + (voxelf[i][k][1])*(voxelf[i][k][1]) +(voxelf[i][k][2])*(voxelf[i][k][2])));


			}
		}
	}
	result=new vlVolume (volume);
	result->clear(0.0);

	for(i=0;i<dim.x();i++)
		for(j=0;j<dim.y();j++)
			for( k=0;k<dim.z();k++)
			{
				offset = (i*stepx)+(j*stepy)+(k*stepz);
				voxel= volume->getVoxelSpecial(offset);
				if ( voxel > 0.5 ) // si hay prote
				{
					//Checking that voxel is superficial
					for (c=0; c<26; c++)
					{

						vecino_i=(i+ray_0[c][0]);
						vecino_j=(j+ray_0[c][1]);
						vecino_k=(k+ray_0[c][2]);

						if ( (vecino_i>=dim.x()) || (vecino_i<0) || (vecino_j>=dim.y()) || (vecino_j<0) || (vecino_k>=dim.z()) || (vecino_k<0) )
						{
							vecino_i=0;
							vecino_j=0;
							vecino_k=0;
						}

						offset1 = (vecino_i*stepx)+(vecino_j*stepy)+(vecino_k*stepz);
						voxel1= volume->getVoxelSpecial(offset1);

						/*if(voxel1!=1.0 && voxel1!=0.0)
						{
						fprintf(stdout,"Voxel incorrecto: %6.6f\n",voxel1);
						}*/

						if ( voxel1 < 0.1 )
						{
							//Voxel is superficial, launch rays
							c=26;

							for (int a=0; a<98; a++)
							{
								for (b=0; b<3*limvox; b++)//cambiar 10
								{
									//printf("B=%d\n",b);
									if (  (voxelf[a][b][0]==0) && (voxelf[a][b][1]==0) && (voxelf[a][b][2]==0) )
									{
										vect_i=0;
										vect_j=0;
										vect_k=0;
									}
									else
									{
										vect_i=i+voxelf[a][b][0];
										vect_j=j+voxelf[a][b][1];
										vect_k=k+voxelf[a][b][2];
									}

									if ( (vect_i>=dim.x())|| (vect_j>=dim.y()) || (vect_k>=dim.z()) )
									{
										vect_i=0;
										vect_j=0;
										vect_k=0;
									}
									if ( (vect_i<0)|| (vect_j<0) || (vect_k<0) )
									{
										vect_i=0;
										vect_j=0;
										vect_k=0;
									}


									offset2 = (vect_i*stepx)+(vect_j*stepy)+(vect_k*stepz);
									voxel2= result->getVoxelSpecial(offset2);
									voxel3= volume->getVoxelSpecial(offset2);
									//val=(float)b+1.0;
									val=distance[a][b]; // distancia

									if(voxel3==0.0 )
									{
										if( closest && (val<voxel2 || voxel2==0) )
										{
											result->setVoxelSpecial(offset2,val);
										}
										else
											if(!closest && (val>voxel2 || voxel2==0))
											{
												result->setVoxelSpecial(offset2,val);
											}
									}
									else
										b=3*limvox;


								}

							}
						}
					}

				}

			}

			//Free voxelf
			for (j=0; j<98; j++)
			{
				for (int k=0; k<3*limvox; k++)
				{
					free(voxelf[j][k]);
				}
				free(voxelf[j]);
				free(distance[j]);
			}
			free(voxelf);
			free(distance);


			return result;
}

vlVolume *ray_tracer_inner(vlVolume *volume, vlVolume *mask)
{

	vlVolume *result;
	//Kernel Laplaciano


	float voxel, voxel1, voxel2,voxel3;
	int stepx,stepy,stepz;
	int offset, offset1, offset2;


	float avox = volume->units().x();
	float dray = 100.0; //tamaño rayo

	int limvox = ceil(dray/avox);

	int shell1=2,shell0=1;
	int cont=0;
	int i,j,k,b,c;
	int x_m=0, y_m=0, z_m=0;
	float ray_x_mod=0.0, ray_y_mod=0.0, ray_z_mod=0.0;
	float lim_x=0.0, lim_y=0.0, lim_z=0.0;
	int previousvoxel[3];
	int vecino_i=0;
	int vecino_j=0;
	int vecino_k=0;
	int vect_i, vect_j, vect_k;
	float val;
	stepx=volume->stepping().x();
	stepy=volume->stepping().y();
	stepz=volume->stepping().z();
	vlDim dim=volume->dim();
	float norma1;
	bool crash;

	//Memory buffers
	int ray[98][3]; // 1st
	int ray_0[26][3];
	float ray_unit[98][3];
	int next2[98][3];
	double delta2[98][3];
	double espacio2[98][3];
	double espacio2_m[98][3];
	int ***voxelf;
	float **distance;


	//Filling ray_0
	cont=0;
	for(i=-shell0;i<=shell0;i++)
	{
		for(int j=-shell0;j<=shell0;j++)
		{
			for(int k=-shell0;k<=shell0;k++)
				if( !(i==0 && j==0 && k==0) )
				{
					ray_0[cont][0]=i ;
					ray_0[cont][1]=j ;
					ray_0[cont][2]=k ;

					cont++;
				}
		}
	}

	//Filling ray
	cont=0;
	for( i=-shell1;i<=shell1;i++)
	{
		for( j=-shell1;j<=shell1;j++)
		{
			for( k=-shell1;k<=shell1;k++)
				if( (i==2 || i==-2 || j==2 || j==-2 || k==2 || k==-2)) //&& (ii%2==1 || ii%2==-1 || jj%2==1 || jj%2==-1 || kk%2==1 || kk%2==-1) )
				{
					ray[cont][0]=i ;
					ray[cont][1]=j ;
					ray[cont][2]=k ;
					cont++;
				}
		}
	}

	//Filling ray_unit
	for( i=0;i<98;i++)
	{
		norma1=sqrt( (float)((ray[i][0]*ray[i][0])+(ray[i][1]*ray[i][1])+(ray[i][2]*ray[i][2])) );
		ray_unit[i][0]=ray[i][0]/norma1;
		ray_unit[i][1]=ray[i][1]/norma1;
		ray_unit[i][2]=ray[i][2]/norma1;
	}
	//Filling next2, delta2 & espacio2
	for ( i=0; i<98; i++)
	{
		for ( j=0; j<3; j++)
		{
			if (ray_unit[i][j]>0.0)
				next2[i][j]=1.0;
			else
				next2[i][j]=-1.0;

			if (ray_unit[i][j]==0.0)
			{
				delta2[i][j]=0.0;
				espacio2[i][j]=1000;
			}
			else
			{
				delta2[i][j]=(avox*1.0)/(ray_unit[i][j]);
				espacio2[i][j]=(avox/2.0)/(ray_unit[i][j]);
			}
			if (espacio2[i][j]>=0)
				espacio2_m[i][j]=espacio2[i][j];
			else
			{
				espacio2_m[i][j]=-espacio2[i][j];
				delta2[i][j]=-delta2[i][j];
			}
		}
	}


	//Allocating memory for voxelf and distance
	voxelf=(int***)malloc(sizeof(int**)*98);
	distance=(float**)malloc(sizeof(float*)*98);
	for ( j=0; j<98; j++)
	{
		voxelf[j]=(int**)malloc(sizeof(int*)*3*limvox);
		distance[j]=(float*)malloc(sizeof(float)*3*limvox);
		for ( k=0; k<3*limvox; k++)
		{
			voxelf[j][k]=(int*)malloc(sizeof(int)*3);
			voxelf[j][k][0]=0;
			voxelf[j][k][1]=0;
			voxelf[j][k][2]=0;
		}
	}


	//Filling voxelf
	for (i=0; i<98; i++)
	{
		j=0;
		do{
			if(j==0)
				previousvoxel[0]=previousvoxel[1]=previousvoxel[2]=0;
			else
			{
				previousvoxel[0]=voxelf[i][j-1][0];
				previousvoxel[1]=voxelf[i][j-1][1];
				previousvoxel[2]=voxelf[i][j-1][2];
			}

			if (espacio2_m[i][0]<espacio2_m[i][1])
			{
				if (espacio2_m[i][0]>espacio2_m[i][2])
				{
					voxelf[i][j][2]=previousvoxel[2]+next2[i][2];
					espacio2_m[i][2]=espacio2_m[i][2]+delta2[i][2];

					voxelf[i][j][0]=previousvoxel[0];
					voxelf[i][j][1]=previousvoxel[1];
				}
				else if(espacio2_m[i][0]==espacio2_m[i][2])
				{
					voxelf[i][j][2]=previousvoxel[2]+next2[i][2];
					espacio2_m[i][2]=espacio2_m[i][2]+delta2[i][2];

					voxelf[i][j][0]=previousvoxel[0]+next2[i][0];
					espacio2_m[i][0]=espacio2_m[i][0]+delta2[i][0];

					voxelf[i][j][1]=previousvoxel[1];
				}
				else
				{
					voxelf[i][j][0]=previousvoxel[0]+next2[i][0];
					espacio2_m[i][0]=espacio2_m[i][0]+delta2[i][0];

					voxelf[i][j][1]=previousvoxel[1];
					voxelf[i][j][2]=previousvoxel[2];
				}
			}
			else if(espacio2_m[i][0]>espacio2_m[i][1])
			{
				if(espacio2_m[i][1]>espacio2_m[i][2])
				{
					voxelf[i][j][2]=previousvoxel[2]+next2[i][2];
					espacio2_m[i][2]=espacio2_m[i][2]+delta2[i][2];

					voxelf[i][j][0]=previousvoxel[0];
					voxelf[i][j][1]=previousvoxel[1];
				}
				else if(espacio2_m[i][1]==espacio2_m[i][2])
				{
					voxelf[i][j][2]=previousvoxel[2]+next2[i][2];
					espacio2_m[i][2]=espacio2_m[i][2]+delta2[i][2];

					voxelf[i][j][1]=previousvoxel[1]+next2[i][1];
					espacio2_m[i][1]=espacio2_m[i][1]+delta2[i][1];

					voxelf[i][j][0]=previousvoxel[0];
				}
				else
				{
					voxelf[i][j][1]=previousvoxel[1]+next2[i][1];
					espacio2_m[i][1]=espacio2_m[i][1]+delta2[i][1];

					voxelf[i][j][0]=previousvoxel[0];
					voxelf[i][j][2]=previousvoxel[2];
				}
			}
			else
			{
				if (espacio2_m[i][0]==espacio2_m[i][1])
				{
					if(espacio2_m[i][0]==espacio2_m[i][2])
					{
						voxelf[i][j][2]=previousvoxel[2]+next2[i][2];
						espacio2_m[i][2]=espacio2_m[i][2]+delta2[i][2];

						voxelf[i][j][1]=previousvoxel[1]+next2[i][1];
						espacio2_m[i][1]=espacio2_m[i][1]+delta2[i][1];

						voxelf[i][j][0]=previousvoxel[0]+next2[i][0];
						espacio2_m[i][0]=espacio2_m[i][0]+delta2[i][0];
					}
					else if(espacio2_m[i][0]<espacio2_m[i][2])
					{
						voxelf[i][j][1]=previousvoxel[1]+next2[i][1];
						espacio2_m[i][1]=espacio2_m[i][1]+delta2[i][1];

						voxelf[i][j][0]=previousvoxel[0]+next2[i][0];
						espacio2_m[i][0]=espacio2_m[i][0]+delta2[i][0];

						voxelf[i][j][2]=previousvoxel[2];
					}
					else
					{
						voxelf[i][j][2]=previousvoxel[2]+next2[i][2];
						espacio2_m[i][2]=espacio2_m[i][2]+delta2[i][2];

						voxelf[i][j][0]=previousvoxel[0];
						voxelf[i][j][1]=previousvoxel[1];
					}
				}
			}

			x_m=abs(voxelf[i][j][0]);
			y_m=abs(voxelf[i][j][1]);
			z_m=abs(voxelf[i][j][2]);

			ray_x_mod=fabsf(ray_unit[i][0]);
			ray_y_mod=fabsf(ray_unit[i][1]);
			ray_z_mod=fabsf(ray_unit[i][2]);

			lim_x=(limvox-avox)*ray_x_mod;
			lim_y=(limvox-avox)*ray_y_mod;
			lim_z=(limvox-avox)*ray_z_mod;
			//fprintf(stdout,"j=%d lim=%d\n",j,3*limvox);
			j++;

		}while( ((float)x_m<=(lim_x)) &&  ((float)y_m<=(lim_y)) && ((float)z_m<=(lim_z)) );
	}

	for (i=0; i<98; i++)
	{
		for ( k=0; k<3*limvox; k++)
		{
			if (  (voxelf[i][k][0]!=0) || (voxelf[i][k][1]!=0) || (voxelf[i][k][2]!=0) )
			{
				//fprintf(stdout,"flag0 %d %d\n",i,k);

				distance[i][k]=avox*sqrt((float)((voxelf[i][k][0])*(voxelf[i][k][0]) + (voxelf[i][k][1])*(voxelf[i][k][1]) +(voxelf[i][k][2])*(voxelf[i][k][2])));

			}
		}
	}
	result=new vlVolume (volume);
	result->clear(0.0);

	for(i=0;i<dim.x();i++)
		for(j=0;j<dim.y();j++)
			for( k=0;k<dim.z();k++)
			{
				offset = (i*stepx)+(j*stepy)+(k*stepz);
				//voxel= volume->getVoxelSpecial(offset);
				voxel= mask->getVoxelSpecial(offset);
				if ( voxel > 0.0 )
				{
					//Checking that voxel is superficial
					for (c=0; c<26; c++)
					{

						vecino_i=(i+ray_0[c][0]);
						vecino_j=(j+ray_0[c][1]);
						vecino_k=(k+ray_0[c][2]);

						if ( (vecino_i>=dim.x()) || (vecino_i<0) || (vecino_j>=dim.y()) || (vecino_j<0) || (vecino_k>=dim.z()) || (vecino_k<0) )
						{
							vecino_i=0;
							vecino_j=0;
							vecino_k=0;
						}

						offset1 = (vecino_i*stepx)+(vecino_j*stepy)+(vecino_k*stepz);
						voxel1= volume->getVoxelSpecial(offset1);

						/*if(voxel1!=1.0 && voxel1!=0.0)
						{
						fprintf(stdout,"Voxel incorrecto: %6.6f\n",voxel1);
						}*/

						if ( voxel1 < 0.1 )
						{
							//Voxel is superficial, launch rays
							c=26;

							for (int a=0; a<98; a++)
							{
								crash=false;
								for (b=0; b<3*limvox; b++)//cambiar 10
								{
									//printf("B=%d\n",b);
									if (  (voxelf[a][b][0]==0) && (voxelf[a][b][1]==0) && (voxelf[a][b][2]==0) )
									{
										vect_i=0;
										vect_j=0;
										vect_k=0;
									}
									else
									{
										vect_i=i+voxelf[a][b][0];
										vect_j=j+voxelf[a][b][1];
										vect_k=k+voxelf[a][b][2];
									}

									if ( (vect_i>=dim.x())|| (vect_j>=dim.y()) || (vect_k>=dim.z()) )
									{
										vect_i=0;
										vect_j=0;
										vect_k=0;
									}
									if ( (vect_i<0)|| (vect_j<0) || (vect_k<0) )
									{
										vect_i=0;
										vect_j=0;
										vect_k=0;
									}


									offset2 = (vect_i*stepx)+(vect_j*stepy)+(vect_k*stepz);
									voxel2= result->getVoxelSpecial(offset);
									voxel3= volume->getVoxelSpecial(offset2);
									//val=(float)b+1.0;
									val=distance[a][b];

									if(voxel3!=0.0 )
									{
										if(voxel2<val)
										{
											result->setVoxelSpecial(offset,val);
										}
										b=(3*limvox);
										crash=true;
									}

								}
								if(!crash)
								{
									val=1000;
									result->setVoxelSpecial(offset,val);
									a=98;
								}

							}
						}
					}
					/*voxel2= result->getVoxelSpecial(offset);
					if(voxel2==0)
					{
					fprintf(stdout,"Punto cerrado\n");
					}*/

				}

			}

			//Free voxelf
			for (j=0; j<98; j++)
			{
				for (int k=0; k<3*limvox; k++)
				{
					free(voxelf[j][k]);
				}
				free(voxelf[j]);
				free(distance[j]);
			}
			free(voxelf);
			free(distance);
			return result;
}

void createSH(Macromolecule *mol, int bw, float steprho,PreSH *preSH_data)
{
	Atom *at;
	Element *e;
	float rho,rho_max=0,theta,lambda,rho_index;
	double centx=0,centy=0, centz=0;
	float X, Y, Z;
	float px[MAX_LIGAND_ATOMS],py[MAX_LIGAND_ATOMS], pz[MAX_LIGAND_ATOMS];
	Tcoor pos;
	int i, cont=0;
	char atname[6];
	//   fprintf(stdout,"frodrug> VS1\n");
	mol->initAll();
	do
	{
		at=mol->getCurrentAtom();
		at->getPosition(pos);
		e=at->getElement();
		strcpy(atname,at->getPdbName());
		// fprintf(stdout,"atm> %d %d %f %f %f %d\n", cont, e->symbol, pos[0],pos[1],pos[2], preSH_data->dsx[contwh-1]);
		if (e->symbol!=H)
		{
			// VDW
			preSH_data->li[cont]=e->weight;
			centx += (px[cont]=pos[0]);
			centy += (py[cont]=pos[1]);
			centz += (pz[cont]=pos[2]);
			//fprintf(stdout,"atm> %d [%s] %f %f %f %f %f %f\n", cont,at->getElement(), e->weight, e->vdw, preSH_data->li[cont], pos[0],pos[1],pos[2]);
			// hydro
			if ((e->symbol==C || e->symbol==F ||e->symbol==BR ||e->symbol==I ||e->symbol==CL ))
				preSH_data->li2[cont]=12;  //e->weight;// in_hw;
			else
				preSH_data->li2[cont]=0;

			int i;
			for (i=0; i<=157; i++)
				if (strcmp (atname,atom_fconv[i].c_str())==0)
				{
					preSH_data->dsx[cont]=atom_change[i];
					i=999;
					// fprintf(stderr, " Warning=[%s] [%s]recognized\n", atname,at->getPdbName() );
				}

				if (i!=1000) {
					preSH_data->dsx[cont]=66;
					//fprintf(stdout, " Warning=-%s- not recognized -> removed\n", atname,at->getPdbName());
				}

				// pair-wise
				cont++;
		}



	} while(mol->nextAtom());


	if ( cont > 0 )
	{
		centx/= ( float )cont;
		centy/= ( float )cont;
		centz/= ( float )cont;
	}
	/*	float cx,cy,cz;
	cx=cy=cz=0;
	for(i=0;i<cont;i++) {
	cx+=px[i]-centx;
	cy+=py[i]-centy;
	cz+=pz[i]-centz;
	} */

	// center
	preSH_data->num_atoms=cont;
	// fprintf(stdout,"cont-h= %d  %f %f %f  %f %f %f\n", cont, centx, centy, centz,cx,cy,cz);

	for(i=0;i<cont;i++) {
		// transform into spherical coord
		// cart2sph(&rho,&theta,&lambda,pos[0],pos[1],pos[2],0,0,0);
		X=px[i]-centx; Y=py[i]-centy; Z=pz[i]-centz;
		// fprintf(stdout,"atm> %d %f %f %f %f\n", i, preSH_data->li[i], X,Y,Z);
		rho    =  sqrt(X*X + Y*Y + Z*Z);
		theta   = acos(Z/rho); //co-latitud
		lambda  = atan2(Y,X);//Longitud

		if (rho> rho_max) rho_max=rho;
		precompute_SH(bw,theta, lambda,preSH_data,i);
		rho_index=rho/steprho;
		//		preSH_data->radius[i]=rho_index;
		preSH_data->posx[i]=X;
		preSH_data->posy[i]=Y;
		preSH_data->posz[i]=Z;
		//fprintf(stdout,"atm> XYZ  %f %f %f \n", X, Y, Z );

		preSH_data->rho_down_index[i]=(int)floor(rho_index);
		preSH_data->rho_up_index[i]=preSH_data->rho_down_index[i]+1;

		preSH_data->fup[i]=1- (preSH_data->rho_up_index[i]-rho_index);
		preSH_data->fdown[i]=1-preSH_data->fup[i];


	}
	preSH_data->rho_max= ceil(rho_max/steprho);
	preSH_data->max_radius = rho_max;
	//fprintf(stdout,"\n SH %d %f %d   \n %f %f %f\n",preSH_data->num_atoms, preSH_data->max_radius, preSH_data->rho_max,
	//		centx, centy, centz);


	//	mol->initAll();
	//	do
	//	{
	//		at=mol->getCurrentAtom();
	//		at->getPosition(pos);
	//		e=at->getElement();
	//		//fprintf(stdout,"Element:%s fact=%f \n",e->name,at->getPdbfact());
	//		cart2sph(&rho,&theta,&lambda,pos[0],pos[1],pos[2],0,0,0);
	//
	//		rho_index=rho/steprho;
	//
	//		precompute_SH(bw,theta, lambda,preSH_data,cont);
	//		preSH_data->radius[cont]=rho_index;
	//
	//		cont++;
	//	}while(mol->nextAtom());

}

void sph_to_sh(vlSpherical *sph, float **rcoeffsV, float **icoeffsV, int in_size_spherical[])
{
	int i;

	//if (in_size_spherical[0]==0)
	//in_size_spherical[0]=1;
	for(i=in_size_spherical[0];i<in_size_spherical[1];i++)
	{
		//fprintf(stdout,"i=%d rmax=%d\n",i,rmax);
		sph->sphCoef(i,rcoeffsV[i],icoeffsV[i]);
	}
}

void write_receptor_layers(FILE *f, int in_size_spherical[], float **rcoeffsV,float **icoeffsV, int size_layer)
{
	int l;
	//fprintf(stdout,"%d %d\n",in_size_spherical[0],in_size_spherical[1]);

	fwrite( in_size_spherical, sizeof(int), 2, f );
	for(l=in_size_spherical[0];l<in_size_spherical[1];l++)
	{
		fwrite(rcoeffsV[l],sizeof(float),size_layer,f );
		fwrite(icoeffsV[l],sizeof(float),size_layer,f );
	}
}


void read_receptor_layers(FILE *f, int in_size_spherical[], float **rcoeffsV,float **icoeffsV, int size_layer)
{
	int l;
	fread( in_size_spherical, sizeof(int), 2, f );
	//fprintf(stdout,"%d %d\n",in_size_spherical[0],in_size_spherical[1]);
	for(l=in_size_spherical[0];l<in_size_spherical[1];l++)
	{
		fread(rcoeffsV[l],sizeof(float),size_layer,f );
		fread(icoeffsV[l],sizeof(float),size_layer,f );
	}
}

void write_SH_ligand(Macromolecule *ligand,PreSH preSH_data,int bw,int limit_max_layer, float in_width)
{
	int l,init,n,j;
	Atom *at;
	Element *e;
	int layer;
	float *associatedC;
	float contR,contI;
	float pos[3],sol[2],rho,theta,lambda;

	float **SH_layerr,**SH_layeri,*radius;
	SH_layerr=(float**)malloc(sizeof(float*)*limit_max_layer);
	SH_layeri=(float**)malloc(sizeof(float*)*limit_max_layer);
	radius=(float*)malloc(sizeof(float)*limit_max_layer);
	AssociatedCoef(bw,&associatedC);
	// aa_pdb2pqr();
	for(l=0;l<limit_max_layer;l++)
	{
		SH_layerr[l]=(float*)malloc(sizeof(float)*(bw*bw+bw)/2);
		SH_layeri[l]=(float*)malloc(sizeof(float)*(bw*bw+bw)/2);
		memset(SH_layerr[l],0,sizeof(float)*(bw*bw+bw)/2);
		memset(SH_layeri[l],0,sizeof(float)*(bw*bw+bw)/2);
	}

	ligand->initAll();

	for(j=0;j<ligand->get_num_atoms();j++)
	{
		contR=contI=0;
		//		radius[j]=floor(preSH_data.radius[j]);
		//		layer=(int)radius[j];
		layer=preSH_data.rho_down_index[j];
		at=ligand->getCurrentAtom();
		e=at->getElement();
		at->getPosition(pos);
		cart2sph(&rho,&theta,&lambda,pos[0],pos[1],pos[2],0,0,0);
		//fprintf(stderr,"atom: %f %f %f %d\n",rho,theta,lambda, layer);
		//layer=(int)radius[j]
		//fprintf(stderr,"atom: %d(%s) %d %f\n",j,at->getName(),layer,radius[j]);
		radius[j]=layer;
		init=0;
		for(l=0;l<bw;l++){
			init+=l;
			for(n=0;n<=l;n++){
				//fprintf(stderr,"%d %d %d %f %f\n",j,l,l-n,preSH_data.sol_r[j][n][l-n],preSH_data.sol_i[j][n][l-n]);
				SH_layerr[layer][init+n]+=(preSH_data.sol_r[j][n][l-n]*1.0)/(layer*in_width*layer*in_width);
				SH_layeri[layer][init+n]+=(preSH_data.sol_i[j][n][l-n]*1.0)/(layer*in_width*layer*in_width);
				computeSH(l,n, theta, lambda, sol,associatedC);
				//SH_layerr[layer][init+n]+=sol[0]*1.0;
				//SH_layeri[layer][init+n]+=sol[1]*1.0;
				contR+=preSH_data.sol_r[j][n][l-n]*1.0;
				contI+=preSH_data.sol_i[j][n][l-n]*1.0;
				//fprintf(stderr,"%f=%f %f=%f \n",preSH_data.sol_r[j][n][l-n]*1.0,sol[0],preSH_data.sol_i[j][n][l-n]*1.0,sol[1]);

			}
		}
		ligand->nextAtom();
		//fprintf(stderr,"%f %f\n",contR,contI);
	}

	vlVolume *kk;
	kk=ligand->createVolumeCentered(0.2);
	kk->clear(0.0);
	// fprintf(stderr,"rho=%f\n",in_width);
	writeSH(kk,SH_layerr,SH_layeri,radius,in_width,limit_max_layer,bw,associatedC);
	ligand->writeMol2("kk.mol2");
	FOPS::writeFile(kk,"lig.sit");
	delete kk;
	// getchar();

}

void printMemoryGPU(char* string=""){
	static size_t freeLast=0;
	size_t free,total;
	cudaMemGetInfo(&free,&total);
	free /= 1024*1024;
	total /= 1024*1024;
	if(freeLast==0){
		freeLast=free;
	}
	cout << "Total: " << total << " MB | Free: " << free << " MB | " << string << " | " << freeLast - free << " MB less since last check\n" << flush;
	freeLast=free;
}
//float* dockingCUDA(int bw, float* ddd,PCollection *points, float**** rcoeffsV, float**** icoeffsV,float *grid_weight, int numLayers,pdbIter *iterMol, int startMol,float voxsize,
//	vlPoint3f origin,float** score,int *tipo_atomP,float *coor_atomP,int N_coor_atomP,int **tipo){
//		ATimer t1;
//		cudaError cErr;
//		cufftResult fftError;
//		//cudaSetDevice(1);
//		//dim3 interpolationGrid(num,bw+1,4);
//		//dim3 interpolationBlock(2*bw,1,bw/2);
//		//dim3 searchGrid(num/256+1,1,1);
//		//dim3 searchBlock(256,1,1);
//
//		// Device memory
//		float *dCoeffr=0;
//		float *dCoeffi=0;
//		float *dDdd=0;
//		float *dCoefCorr=0;
//		float *dCoefCorrTarget=0;
//		float *dCorr=0;
//		float *dPsi=0;
//		float *dTh=0;
//		float *dPhi=0;
//		float *dMcoefr=0;
//		float *dMcoefi=0;
//		float *dSolR=0;
//		float *dSolI=0;
//		cufftHandle plan;
//		cufftHandle planEnd;
//
//		// Host memory
//		float *corr=0;
//		float *psi=0;
//		float *th=0;
//		float *phi=0;
//		float *corrFinal=0;
//		float *psiFinal=0;
//		float *thFinal=0;
//		float *phiFinal=0;
//		float *hDdd=0;
//		float *hMcoefr=0;
//		float *hMcoefi=0;
//		//float *hNPTempCoeffR=0; // For integral reorder
//		//float *hNPTempCoeffI=0; // For integral reorder
//		//float *hTempCoeffR=0; // For integral reorder
//		//float *hTempCoeffI=0; // For integral reorder
//
//		int sizeIntegral = bw * ( 4 * bw * bw - 1 ) / 3;
//		int sizeCoeff = ((((bw-1)*(4*(bw-1)*(bw-1)-1)/3+(bw-1)*(bw-1))/2)+(bw-1)*(2*(bw-1)+1))+(bw-1)+(bw-1)+1;
//		int correlation_buffer_size = 2*bw * 2*bw * 2*(bw+1);
//		int correlation_target_buffer_size = 2*bw * 2*bw * 2*bw;
//
//		Macromolecule *ligand = new Macromolecule( "Ligand" );
//		int num = points->num;
//		int fftDims [] = {32, 32, 32};
//		int FFTPack = num;
//
//		int sizeLayer = (bw*bw+bw)/2;
//		/*for(int i=0;i< bw;i++){
//		sizeLayer += bw-i;
//		}*/
//
//		// PreSH init
//		int numLigands=0;
//		for(iterMol->pos_molecule=startMol; !iterMol->gend_molecule(); iterMol->next_molecule()){
//			numLigands++;
//		}
//		PreSH *preSH_data = new PreSH[numLigands];
//		for(int mol=0;mol<numLigands;mol++){
//			preSH_data[mol].sol_r=(float***)malloc(sizeof(float**)*MAX_LIGAND_ATOMS);
//			preSH_data[mol].sol_i=(float***)malloc(sizeof(float**)*MAX_LIGAND_ATOMS);
//			preSH_data[mol].fup=(float*)malloc(sizeof(float)*MAX_LIGAND_ATOMS);
//			preSH_data[mol].fdown=(float*)malloc(sizeof(float)*MAX_LIGAND_ATOMS);
//			preSH_data[mol].rho_up_index=(int*)malloc(sizeof(int)*MAX_LIGAND_ATOMS);
//			preSH_data[mol].rho_down_index=(int*)malloc(sizeof(int)*MAX_LIGAND_ATOMS);
//			preSH_data[mol].type=(int*)malloc(sizeof(int)*MAX_LIGAND_ATOMS);
//			preSH_data[mol].li=(float*)malloc(sizeof(float)*MAX_LIGAND_ATOMS);
//			preSH_data[mol].li2=(float*)malloc(sizeof(float)*MAX_LIGAND_ATOMS);
//			preSH_data[mol].dsx=(int*)malloc(sizeof(int)*MAX_LIGAND_ATOMS);
//			preSH_data[mol].posx=(float*)malloc(sizeof(float)*MAX_LIGAND_ATOMS);
//			preSH_data[mol].posy=(float*)malloc(sizeof(float)*MAX_LIGAND_ATOMS);
//			preSH_data[mol].posz=(float*)malloc(sizeof(float)*MAX_LIGAND_ATOMS);
//			for(int h=0;h<MAX_LIGAND_ATOMS;h++)	{
//				preSH_data[mol].sol_r[h]=(float**)malloc(sizeof(float*)*in_bw);
//				preSH_data[mol].sol_i[h]=(float**)malloc(sizeof(float*)*in_bw);
//				for(int i=0;i<in_bw;i++){
//					preSH_data[mol].sol_r[h][i]=(float*)malloc(sizeof(float)*(in_bw-i));
//					preSH_data[mol].sol_i[h][i]=(float*)malloc(sizeof(float)*(in_bw-i));
//					memset(preSH_data[mol].sol_r[h][i],0,sizeof(float)*(in_bw-i));
//					memset(preSH_data[mol].sol_i[h][i],0,sizeof(float)*(in_bw-i));
//				}
//			}
//		}
//
//		int totalPeaks;
//		int saved_peaks=15;
//		int explored_peaks=50;
//
//		totalPeaks=saved_peaks*numLigands;
//		float *soutput;
//		soutput=(float*)malloc(sizeof(float)*totalPeaks*9);
//
//		float *soutputP;
//		soutputP=(float*)malloc(sizeof(float)*explored_peaks*9);
//
//		// Sync events init
//		cudaEvent_t *syncEvents = new cudaEvent_t[numLigands];
//		for(int ev=0;ev<numLigands;ev++){
//			cudaEventCreate(&syncEvents[ev]);
//		}
//
//		// Device init
//		//printMemoryGPU();
//		initGPU();
//		//cudaDeviceProp deviceProp;
//		//cudaGetDeviceProperties(&deviceProp,0);
//		printMemoryGPU("Antes de reservar CUFFT");
//		fftError = cufftPlanMany(&plan,3,fftDims,NULL,1,0,NULL,1,0,CUFFT_C2R,FFTPack);
//		if(fftError != CUFFT_SUCCESS){
//			cout << "Error creating gpu FFT plan\n";
//			exit(-1);
//		}
//		fftError = cufftSetCompatibilityMode(plan,CUFFT_COMPATIBILITY_NATIVE);
//		if(fftError != CUFFT_SUCCESS){
//			cout << "Error setting gpu FFT plan compatibility\n";
//			exit(-1);
//		}
//		if(num%FFTPack>0){
//			fftError = cufftPlanMany(&planEnd,3,fftDims,NULL,1,0,NULL,1,0,CUFFT_C2R,num%FFTPack);
//			if(fftError != CUFFT_SUCCESS){
//				cout << "Error creating gpu FFT end plan\n";
//				exit(-1);
//			}
//			fftError = cufftSetCompatibilityMode(planEnd,CUFFT_COMPATIBILITY_NATIVE);
//			if(fftError != CUFFT_SUCCESS){
//				cout << "Error setting gpu FFT end plan compatibility\n";
//				exit(-1);
//			}
//		}
//		printMemoryGPU("Despues de reservar CUFFT");
//
//		cudaMalloc(&dCoefCorr,sizeof(float)*correlation_buffer_size*((num/32+1)*32)); // Solo device
//		//cudaMalloc(&dCoefCorr,sizeof(float)*correlation_buffer_size*num); // Solo device
//		cudaMalloc(&dCoefCorrTarget,sizeof(float)*correlation_target_buffer_size*num);// Solo device
//		cudaMalloc(&dCoeffr,sizeof(float)*sizeCoeff*((num/32+1)*32));// Solo device
//		cudaMalloc(&dCoeffi,sizeof(float)*sizeCoeff*((num/32+1)*32));// Solo device
//		//cudaMalloc(&dCoeffr,sizeof(float)*sizeCoeff*num);// Solo device
//		//cudaMalloc(&dCoeffi,sizeof(float)*sizeCoeff*num);// Solo device
//		cudaMalloc(&dCorr,sizeof(float)*num*(bw+1)); // Device -> Host
//		cudaMalloc(&dPsi,sizeof(float)*num*(bw+1)); // Device -> Host
//		cudaMalloc(&dTh,sizeof(float)*num*(bw+1)); // Device -> Host
//		cudaMalloc(&dPhi,sizeof(float)*num*(bw+1)); // Device -> Host
//		cudaMalloc(&dDdd,sizeof(float)*sizeIntegral); // Host -> Device (una vez)
//		cudaMalloc(&dMcoefr,sizeof(float)*num*numLayers*sizeLayer); // Host -> Device (una vez)
//		cudaMalloc(&dMcoefi,sizeof(float)*num*numLayers*sizeLayer); // Host -> Device (una vez)
//		cudaMalloc(&dSolR,sizeof(float)*bw*bw*MAX_LIGAND_ATOMS); // Host -> Device (muchas veces)
//		cudaMalloc(&dSolI,sizeof(float)*bw*bw*MAX_LIGAND_ATOMS); // Host -> Device (muchas veces)
//
//		//hTempCoeffR = new float[sizeCoeff*((num/32+1)*32)];// Temp integral R for reorder
//		//hTempCoeffI = new float[sizeCoeff*((num/32+1)*32)];// Temp integral I for reorder
//		//cudaMallocHost(&hNPTempCoeffR,sizeof(float)*sizeCoeff*((num/32+1)*32));// Temp integral R for reorder
//		//cudaMallocHost(&hNPTempCoeffI,sizeof(float)*sizeCoeff*((num/32+1)*32));// Temp integral I for reorder
//		cudaMallocHost(&hDdd,sizeof(float)*sizeIntegral);
//		cudaMallocHost(&hMcoefr,sizeof(float)*num*numLayers*sizeLayer);
//		cudaMallocHost(&hMcoefi,sizeof(float)*num*numLayers*sizeLayer);
//		/*cudaMallocHost(&corr,numLigands*num*(bw+1)*sizeof(float));
//		cudaMallocHost(&psi,numLigands*num*(bw+1)*sizeof(float));
//		cudaMallocHost(&th,numLigands*num*(bw+1)*sizeof(float));
//		cudaMallocHost(&phi,numLigands*num*(bw+1)*sizeof(float));*/
//		cudaMallocHost(&corr,numLigands*num*(bw/2+1)*sizeof(float));// With IMPROVED search
//		cudaMallocHost(&psi,numLigands*num*(bw/2+1)*sizeof(float));
//		cudaMallocHost(&th,numLigands*num*(bw/2+1)*sizeof(float));
//		cudaMallocHost(&phi,numLigands*num*(bw/2+1)*sizeof(float));
//
//		corrFinal = new float[numLigands*num];
//		psiFinal = new float[numLigands*num];
//		thFinal = new float[numLigands*num];
//		phiFinal = new float[numLigands*num];
//		printMemoryGPU("Despues de reservar el resto");
//		//for(int a=0;a < num; a++){
//		//	for(int b=0; b < numLayers; b++){
//		//		memcpy(hMcoefr + a*numLayers*sizeLayer + b*sizeLayer ,rcoeffsV[0][a][b],sizeLayer*sizeof(float));
//		//		memcpy(hMcoefi + a*numLayers*sizeLayer + b*sizeLayer ,icoeffsV[0][a][b],sizeLayer*sizeof(float));
//		//	}
//		//}
//		// TEST - DATA REORDER - TEST - DATA REORDER - TEST - DATA REORDER - TEST - DATA REORDER - TEST - DATA REORDER
//		for(int a=0;a < num; a++){
//			for(int b=0; b < numLayers; b++){
//				int baseIndex = a*numLayers*sizeLayer + b*sizeLayer;
//				int writeIndex=0;
//				for(int l=0;l<bw;l++){
//					for(int m=0;m<=l;m++){
//						int readIndex = m*bw-((m*(m-1))/2)+(l-m);
//						hMcoefr[baseIndex + writeIndex] = rcoeffsV[0][a][b][readIndex];
//						hMcoefi[baseIndex + writeIndex] = icoeffsV[0][a][b][readIndex];
//						writeIndex++;
//					}
//				}
//				//memcpy(hMcoefr + a*numLayers*sizeLayer + b*sizeLayer ,rcoeffsV[0][a][b],sizeLayer*sizeof(float));
//				//memcpy(hMcoefi + a*numLayers*sizeLayer + b*sizeLayer ,icoeffsV[0][a][b],sizeLayer*sizeof(float));
//			}
//		}
//		// TEST - DATA REORDER - TEST - DATA REORDER - TEST - DATA REORDER - TEST - DATA REORDER - TEST - DATA REORDER
//		memcpy(hDdd,ddd,sizeof(float)*sizeIntegral);
//		cudaMemcpyAsync(dDdd,hDdd,sizeof(float)*sizeIntegral,cudaMemcpyHostToDevice);
//		cudaMemcpyAsync(dMcoefr,hMcoefr,sizeof(float)*num*numLayers*sizeLayer,cudaMemcpyHostToDevice);
//		cudaMemcpyAsync(dMcoefi,hMcoefi,sizeof(float)*num*numLayers*sizeLayer,cudaMemcpyHostToDevice);
//
//		ATimer tTotal;
//		tTotal.startTimer();
//		// Docking
//		for(iterMol->pos_molecule=startMol; !iterMol->gend_molecule(); iterMol->next_molecule()) {
//			//for(iterMol->pos_molecule=50; !iterMol->gend_molecule(); iterMol->next_molecule()) {
//			printf("frodrug CUDA> Lig %5d ", iterMol->pos_molecule);
//			t1.startTimer();
//			ligand->eraseAll();
//			ligand->add((SMol *) iterMol->get_molecule());
//
//			// time2.restart();
//
//			if(ligand->num_atoms()>MAX_LIGAND_ATOMS){
//				fprintf(stdout,"Warning %d\n", ligand->num_atoms());
//				//      PENDING a realloc if bigger
//			}
//
//			//PRECALCULATION OF SPHERICAL REPRESENTATION OF THE LIGAND
//			createSH(ligand, bw, 0.5f,&preSH_data[iterMol->pos_molecule-1]);
//			if (preSH_data[iterMol->pos_molecule-1].rho_max>numLayers) {
//				fprintf(stdout,"\nfrodrug> Warning layer %d %d\n", preSH_data[iterMol->pos_molecule-1].rho_max, numLayers);
//				preSH_data[iterMol->pos_molecule-1].rho_max=numLayers;
//			}
//
//
//			// TEST - TEST - TEST - TEST - TEST - TEST - TEST - TEST
//			float original_center[3],inverse_original_center[3];
//			ligand->deleteHYDS();
//			ligand->geoCenter(original_center);
//			inverse_original_center[0]=original_center[0]*-1.0;
//			inverse_original_center[1]=original_center[1]*-1.0;
//			inverse_original_center[2]=original_center[2]*-1.0;
//			ligand->moveAll(inverse_original_center);
//			float maxDist = ligand->maxLength()/2.0f;
//			//printf("maxR: %2.4f ",maxDist);
//			// TEST - TEST - TEST - TEST - TEST - TEST - TEST - TEST
//			//t1.startTimer();
//
//			ligToGPU(&preSH_data[iterMol->pos_molecule-1],bw,dSolR,dSolI);
//			createIntegralDrugCUDA(dCoeffr,dCoeffi,bw,preSH_data[iterMol->pos_molecule-1].num_atoms,grid_weight[0], numLayers, sizeLayer,dMcoefr, dMcoefi,dSolR,dSolI,num);
//			//float* hostIntegral = new float[sizeCoeff*num];
//			//cudaMemcpy(hostIntegral,dCoeffr,sizeCoeff*num,cudaMemcpyDeviceToHost);
//			//return hostIntegral;
//
//			// TEST CODE - INTEGRAL REORDER - TEST CODE - INTEGRAL REORDER - TEST CODE - INTEGRAL REORDER - TEST CODE - INTEGRAL REORDER - TEST CODE - INTEGRAL REORDER
//			//cudaMemcpy(hNPTempCoeffR,dCoeffr,sizeof(float)*sizeCoeff*((num/32+1)*32),cudaMemcpyDeviceToHost);// Temp integral R for reorder
//			//cudaMemcpy(hNPTempCoeffI,dCoeffi,sizeof(float)*sizeCoeff*((num/32+1)*32),cudaMemcpyDeviceToHost);// Temp integral I for reorder
//			//memcpy(hTempCoeffR,hNPTempCoeffR,sizeof(float)*sizeCoeff*((num/32+1)*32));
//			//memcpy(hTempCoeffI,hNPTempCoeffI,sizeof(float)*sizeCoeff*((num/32+1)*32));
//			//// Reordering
//			//int indexReorder=0;
//			//for(int index = 0; index < sizeCoeff; index++){
//			//	for(int integral = 0;integral < (num/32+1)*32;integral++){
//			//		hNPTempCoeffR[indexReorder] = hTempCoeffR[integral * sizeCoeff + index];
//			//		hNPTempCoeffI[indexReorder] = hTempCoeffI[integral * sizeCoeff + index];
//			//		indexReorder++;
//			//	}
//			//}
//			//cudaMemcpy(dCoeffr,hNPTempCoeffR,sizeof(float)*sizeCoeff*((num/32+1)*32),cudaMemcpyHostToDevice);
//			//cudaMemcpy(dCoeffi,hNPTempCoeffI,sizeof(float)*sizeCoeff*((num/32+1)*32),cudaMemcpyHostToDevice);
//			// TEST CODE - INTEGRAL REORDER - TEST CODE - INTEGRAL REORDER - TEST CODE - INTEGRAL REORDER - TEST CODE - INTEGRAL REORDER - TEST CODE - INTEGRAL REORDER
//
//			cudaMemset(dCoefCorr,0,sizeof(float)*correlation_buffer_size*num);
//			fourierCorrCUDA(bw,dCoeffr,dCoeffi,dDdd,dCoefCorr, num);
//
//			for(int i=0; i<num/FFTPack; i++){
//				fftError = cufftExecC2R(plan,(cufftComplex*)(dCoefCorr+i*correlation_buffer_size*FFTPack),(cufftReal*)(dCoefCorrTarget+i*correlation_target_buffer_size*FFTPack));
//				if(fftError != CUFFT_SUCCESS){
//					cout << "Error executing CUFFT, as ever\n";
//					exit(-1);
//				}
//			}
//			if(num%FFTPack>0){
//				fftError = cufftExecC2R(planEnd,(cufftComplex*)(dCoefCorr+(num/FFTPack)*correlation_buffer_size*FFTPack),(cufftReal*)(dCoefCorrTarget+(num/FFTPack)*correlation_target_buffer_size*FFTPack));
//				if(fftError != CUFFT_SUCCESS){
//					cout << "Error executing END CUFFT, as ever\n";
//					exit(-1);
//				}
//			}
//
//			searchCorr680CUDA(bw,dCoefCorrTarget,dCorr,dPsi, dTh, dPhi, num);
//			//interpolationK<<<interpolationGrid,interpolationBlock>>>(bw,dCoefCorrTarget,dCoefCorr);
//			//maxCorrK<<<searchGrid,searchBlock>>>(bw, dCoefCorr, dCoefCorrTarget, dCorr,dPsi, dTh, dPhi, num);
//			// TEST CODE -------------------------------------------------------------
//			//float* testMem = new float[correlation_target_buffer_size*num];
//			//cudaMemcpy(testMem,dCoefCorr,sizeof(float)*correlation_target_buffer_size*num,cudaMemcpyDeviceToHost);
//			//for(int i=0;i<correlation_target_buffer_size*num;i+=5){
//			//	if(testMem[i]!=0){
//			//		printf("%f\n",testMem[i]);
//			//	}
//			//}
//			//exit(0);
//			// TEST CODE -------------------------------------------------------------
//
//			//                                                 (bw+1)              (bw+1)
//			//cudaMemcpyAsync(corr+(iterMol->pos_molecule-1)*num*(bw/2+1),dCorr,num*(bw/2+1)*sizeof(float),cudaMemcpyDeviceToHost);
//			//cudaMemcpyAsync(psi+(iterMol->pos_molecule-1)*num*(bw/2+1),dPsi,num*(bw/2+1)*sizeof(float),cudaMemcpyDeviceToHost);
//			//cudaMemcpyAsync(th+(iterMol->pos_molecule-1)*num*(bw/2+1),dTh,num*(bw/2+1)*sizeof(float),cudaMemcpyDeviceToHost);
//			//cudaMemcpy(phi+(iterMol->pos_molecule-1)*num*(bw/2+1),dPhi,num*(bw/2+1)*sizeof(float),cudaMemcpyDeviceToHost);
//			cudaMemcpyAsync(corr+(iterMol->pos_molecule-1)*num,dCorr,num*sizeof(float),cudaMemcpyDeviceToHost);
//			cudaMemcpyAsync(psi+(iterMol->pos_molecule-1)*num,dPsi,num*sizeof(float),cudaMemcpyDeviceToHost);
//			cudaMemcpyAsync(th+(iterMol->pos_molecule-1)*num,dTh,num*sizeof(float),cudaMemcpyDeviceToHost);
//			cudaMemcpy(phi+(iterMol->pos_molecule-1)*num,dPhi,num*sizeof(float),cudaMemcpyDeviceToHost);
//
//			// Proccess output
//			for(int c=0;c<num;c++){
//				float best = 0;
//				int index = -1;        //bw
//				//for(int slice=0;slice<=bw/2;slice++){   //(bw+1)   (bw+1)
//				//	if(corr[(iterMol->pos_molecule-1)*num*(bw/2+1)+c*(bw/2+1)+slice]>best){
//				//		index = (iterMol->pos_molecule-1)*num*(bw/2+1)+c*(bw/2+1)+slice;
//				//		best = corr[(iterMol->pos_molecule-1)*num*(bw/2+1)+c*(bw/2+1)+slice];
//				//	}
//				//}
//				for(int slice=0;slice<=0;slice++){
//					if(corr[(iterMol->pos_molecule-1)*num+c]>best){
//						index = (iterMol->pos_molecule-1)*num+c;
//						best = corr[(iterMol->pos_molecule-1)*num+c];
//					}
//				}
//				if(index != -1){
//					corrFinal[(iterMol->pos_molecule-1)*num+c] = corr[index];
//					psiFinal[(iterMol->pos_molecule-1)*num+c] = psi[index];
//					thFinal[(iterMol->pos_molecule-1)*num+c] = th[index];
//					phiFinal[(iterMol->pos_molecule-1)*num+c] = phi[index];
//				}else{
//					corrFinal[(iterMol->pos_molecule-1)*num+c] = 0;
//					psiFinal[(iterMol->pos_molecule-1)*num+c] = 0;
//					thFinal[(iterMol->pos_molecule-1)*num+c] = 0;
//					phiFinal[(iterMol->pos_molecule-1)*num+c] = 0;
//				}
//			}
//			float best = 0;
//			int index = -1;
//			for(int c=0;c<num;c++){
//				if(corrFinal[(iterMol->pos_molecule-1)*num+c]>best){
//					index = (iterMol->pos_molecule-1)*num+c;
//					best = corrFinal[(iterMol->pos_molecule-1)*num+c];
//				}
//			}
//			//cout << "Best corr: " << best << " psi: " << psiFinal[index] << " th: " << thFinal[index]<< " phi: " << phiFinal[index] << endl << flush;
//
//			//cudaMemcpy(corrFinal,dCorr,sizeof(float)*num,cudaMemcpyDeviceToHost);
//			//cudaMemcpy(psiFinal,dPsi,sizeof(float)*num,cudaMemcpyDeviceToHost);
//			//cudaMemcpy(thFinal,dTh,sizeof(float)*num,cudaMemcpyDeviceToHost);
//			//cudaMemcpy(phiFinal,dPhi,sizeof(float)*num,cudaMemcpyDeviceToHost);
//
//			//t1.stopTimer();
//			//cErr = cudaDeviceSynchronize();
//			//if(cErr != cudaSuccess){
//			//	cout << "CUDA Error : " << cudaGetErrorString(cErr) << endl;
//			//	exit(-1);
//			//}
//			//printf("Time: %.18f\n",t1.getElapsedTime());
//			memset(soutputP,0,sizeof(float)*explored_peaks*9);
//			Tcoor point;
//			for (int i = 0; i < num; i++ ){
//				int lowestIndex=0;
//				float lowestValue=FLT_MAX;
//				for(int h=0;h<explored_peaks;h++){
//					if(soutputP[h*9]<lowestValue){
//						lowestIndex = h;
//						lowestValue = soutputP[h*9];
//					}
//				}
//				if(corrFinal[(iterMol->pos_molecule-1)*num+i]>lowestValue){
//					points->return_point(i,point);
//					soutputP[lowestIndex*9]=corrFinal[(iterMol->pos_molecule-1)*num+i];
//					soutputP[lowestIndex*9+1]=psiFinal[(iterMol->pos_molecule-1)*num+i] * 180 / M_PI;
//					soutputP[lowestIndex*9+2]=thFinal[(iterMol->pos_molecule-1)*num+i] * 180 / M_PI;
//					soutputP[lowestIndex*9+3]=phiFinal[(iterMol->pos_molecule-1)*num+i] * 180 / M_PI;
//					soutputP[lowestIndex*9+4]=point[0] * voxsize + origin.x() + voxsize/2.0;
//					soutputP[lowestIndex*9+5]=point[1] * voxsize + origin.y() + voxsize/2.0;
//					soutputP[lowestIndex*9+6]=point[2] * voxsize + origin.z() + voxsize/2.0;
//					soutputP[lowestIndex*9+7]=iterMol->pos_molecule-1;
//				}
//				//cout << "Lowest index: " << lowestIndex << endl << flush;
//			}
//
//			// Sort by corr REMOVE THIS WHEN TESTED
//			for (int h=0; h<explored_peaks; h++){
//				for (int k=h+1; k<explored_peaks; k++) {
//					int solh=h*9;
//					int solk=k*9;
//					if (soutputP[solk]>soutputP[solh]) {
//						for (int i=0; i<9; i++) {
//							float soltemp=soutputP[solh+i];
//							soutputP[solh+i]=soutputP[solk+i];
//							soutputP[solk+i]=soltemp;
//						}
//
//					}
//				}
//			}
//
//			//
//			// Dsx
//			//
//			float sin_psi;
//			float cos_psi;
//			float sin_theta;
//			float cos_theta;
//			float sin_phi;
//			float cos_phi;
//			float matrix[3][3],dist,buffer[3];;
//			float coor_atomL_origen[3];
//
//			int solm;
//			float dist_score;
//			int int_dist_score, par_lig, par_prot, tipo_final ;
//			float dsx_score=0,  dsx_min=9999, Lx, Ly, Lz;
//			for (int h=0; h<explored_peaks; h++){
//				dsx_score=0;
//				solm=h*9;
//				buffer[0]=soutputP[solm+1]*M_PI/180.0;
//				buffer[1]=soutputP[solm+2]*M_PI/180.0;
//				buffer[2]=soutputP[solm+3]*M_PI/180.0;
//
//				sin_psi = sin(buffer[0]);
//				cos_psi = cos(buffer[0]);
//				sin_theta= sin(buffer[1]);
//				cos_theta= cos(buffer[1]);
//				sin_phi=sin(buffer[2]);
//				cos_phi=cos(buffer[2]);
//
//				matrix[0][0]= cos_psi*cos_phi - cos_theta*sin_phi*sin_psi;
//				matrix[0][1]= cos_psi*sin_phi + cos_theta*cos_phi*sin_psi;
//				matrix[0][2]= sin_psi*sin_theta;
//				matrix[1][0]= -sin_psi*cos_phi - cos_theta*sin_phi*cos_psi;
//				matrix[1][1]= -sin_psi*sin_phi + cos_theta*cos_phi*cos_psi;
//				matrix[1][2]= cos_psi*sin_theta;
//				matrix[2][0]= sin_theta*sin_phi;
//				matrix[2][1]= -sin_theta*cos_phi;
//				matrix[2][2]= cos_theta;
//
//				for (int i=0; i<preSH_data[iterMol->pos_molecule-1].num_atoms; i++) { // ligando
//					coor_atomL_origen[0]=preSH_data[iterMol->pos_molecule-1].posx[i];
//					coor_atomL_origen[1]=preSH_data[iterMol->pos_molecule-1].posy[i];
//					coor_atomL_origen[2]=preSH_data[iterMol->pos_molecule-1].posz[i];
//
//					// rotation
//					Lx= coor_atomL_origen[0]*matrix[0][0] + coor_atomL_origen[1]*matrix[0][1] + coor_atomL_origen[2]*matrix[0][2];
//					Ly= coor_atomL_origen[0]*matrix[1][0] + coor_atomL_origen[1]*matrix[1][1] + coor_atomL_origen[2]*matrix[1][2];
//					Lz= coor_atomL_origen[0]*matrix[2][0] + coor_atomL_origen[1]*matrix[2][1] + coor_atomL_origen[2]*matrix[2][2];
//
//					// translation
//					Lx+=soutputP[solm+4];
//					Ly+=soutputP[solm+5];
//					Lz+=soutputP[solm+6];
//
//					par_lig=preSH_data[iterMol->pos_molecule-1].dsx[i];
//
//					if ( par_lig!=66 ){
//						for (int j=0; j<N_coor_atomP; j++){
//							dist=(((Lx-coor_atomP[3*j+0])*(Lx-coor_atomP[3*j+0]))+((Ly-coor_atomP[3*j+1])*(Ly-coor_atomP[3*j+1]))+((Lz-coor_atomP[3*j+2])*(Lz-coor_atomP[3*j+2])) );
//							if (dist<=36){
//								dist_score=sqrt(dist)*100;
//								int_dist_score=(int)dist_score;
//								par_prot=tipo_atomP[j];
//								tipo_final=tipo[par_lig][par_prot];
//								if ( tipo_final!=66 ){
//									dsx_score+=score[tipo_final][(int_dist_score+1)]+(dist_score-(int_dist_score+1))*( (score[tipo_final][(int_dist_score+1)]-score[tipo_final][int_dist_score]));
//								}
//							}
//						}
//					}
//				}
//
//				soutputP[solm+8]=dsx_score;
//				if(dsx_score<dsx_min){
//					dsx_min=dsx_score;
//				}
//			}
//
//			//fprintf(stdout," Rm %2d N %3d-> %6.2f dsx %6.2f min %6.2f\n",preSH_data[iterMol->pos_molecule-1].rho_max, preSH_data[iterMol->pos_molecule-1].num_atoms,soutputP[0], soutputP[8], dsx_min);
//
//			int solh, solk;
//			float soltemp;
//			// ** sort by dsx
//			for (int h=0; h<explored_peaks; h++){
//				for (int k=h+1; k<explored_peaks; k++) {
//					solh=h*9;
//					solk=k*9;
//					if (soutputP[solk+8]<soutputP[solh+8]) {
//						for (int i=0; i<9; i++) {
//							soltemp=soutputP[solh+i];
//							soutputP[solh+i]=soutputP[solk+i];
//							soutputP[solk+i]=soltemp;
//						}
//
//					}
//				}
//			}
//
//			for (int h=0; h<saved_peaks; h++) {
//				solh=((iterMol->pos_molecule-1)*saved_peaks+h)*9;
//				for (int i=0; i<9; i++) {
//					soutput[solh+i]=soutputP[h*9+i];
//				}
//			}
//			t1.stopTimer();
//			fprintf(stdout," %.2f Avg %.5f Rm %2d N %3d-> %6.2f dsx %6.2f\n",t1.getElapsedTime(),t1.getElapsedTime()/points->num,preSH_data[iterMol->pos_molecule-1].rho_max, preSH_data[iterMol->pos_molecule-1].num_atoms,soutputP[0], soutputP[8]);
//		}
//
//		cErr = cudaDeviceSynchronize();
//		if(cErr != cudaSuccess){
//			cout << "CUDA Error : " << cudaGetErrorString(cErr) << endl;
//			exit(-1);
//		}
//		tTotal.stopTimer();
//		printf("Total time: %.18f\n",tTotal.getElapsedTime());
//		return soutput;
//}

float* dockingCUDA_SingleLigand(int bw, float* ddd,list<PointVoxel> listOfPoints, float *grid_weight, int numLayers,SMol* mol, float voxsize,vlPoint3f origin,float** score,int *tipo_atomP,float *coor_atomP,int N_coor_atomP,int **tipo, int molNumber){
		ATimer t1;
		
		cudaError cErr;
		cufftResult fftError;

		static bool init = true; // Init flag (true = needs to be initialised)

		// Device memory
		static float *dCoeffr=0;
		static float *dCoeffi=0;
		static float *dDdd=0;
		static float *dCoefCorr=0;
		static float *dCoefCorrTarget=0;
		static float *dCorr=0;
		static float *dPsi=0;
		static float *dTh=0;
		static float *dPhi=0;
		static float *dMcoefr=0;
		static float *dMcoefi=0;
		static float *dSolR=0;
		static float *dSolI=0;
		static cufftHandle plan;
		static cufftHandle planEnd;

		// Host memory
		static float *corr=0;
		static float *psi=0;
		static float *th=0;
		static float *phi=0;
		static float *hDdd=0;
		static float *hMcoefr=0;
		static float *hMcoefi=0;
		static Macromolecule *ligand = 0;
		static PreSH *preSH_data = 0;
		static float *soutput = 0;
		static float *soutputP = 0;

		// Constants used (can be converted to static at anytime)
		int sizeIntegral = bw * ( 4 * bw * bw - 1 ) / 3;
		int sizeCoeff = ((((bw-1)*(4*(bw-1)*(bw-1)-1)/3+(bw-1)*(bw-1))/2)+(bw-1)*(2*(bw-1)+1))+(bw-1)+(bw-1)+1;
		int correlation_buffer_size = 2*bw * 2*bw * 2*(bw+1);
		int correlation_target_buffer_size = 2*bw * 2*bw * 2*bw;
		int num = listOfPoints.size();
		int fftDims [] = {32, 32, 32};
		int FFTPack = num/6;
		//int FFTPack = num/10;
		int sizeLayer = (bw*bw+bw)/2;
		int savedPeaks=15;
		int explored_peaks=50;
		int spp = 1; // Solutions per point

		if(init){
			init = false;
			ligand = new Macromolecule( "Ligand" );

			// PreSH init
			preSH_data = new PreSH;
			preSH_data->sol_r=(float***)malloc(sizeof(float**)*MAX_LIGAND_ATOMS);
			preSH_data->sol_i=(float***)malloc(sizeof(float**)*MAX_LIGAND_ATOMS);
			preSH_data->fup=(float*)malloc(sizeof(float)*MAX_LIGAND_ATOMS);
			preSH_data->fdown=(float*)malloc(sizeof(float)*MAX_LIGAND_ATOMS);
			preSH_data->rho_up_index=(int*)malloc(sizeof(int)*MAX_LIGAND_ATOMS);
			preSH_data->rho_down_index=(int*)malloc(sizeof(int)*MAX_LIGAND_ATOMS);
			preSH_data->type=(int*)malloc(sizeof(int)*MAX_LIGAND_ATOMS);
			preSH_data->li=(float*)malloc(sizeof(float)*MAX_LIGAND_ATOMS);
			preSH_data->li2=(float*)malloc(sizeof(float)*MAX_LIGAND_ATOMS);
			preSH_data->dsx=(int*)malloc(sizeof(int)*MAX_LIGAND_ATOMS);
			preSH_data->posx=(float*)malloc(sizeof(float)*MAX_LIGAND_ATOMS);
			preSH_data->posy=(float*)malloc(sizeof(float)*MAX_LIGAND_ATOMS);
			preSH_data->posz=(float*)malloc(sizeof(float)*MAX_LIGAND_ATOMS);
			for(int h=0;h<MAX_LIGAND_ATOMS;h++)	{
				preSH_data->sol_r[h]=(float**)malloc(sizeof(float*)*in_bw);
				preSH_data->sol_i[h]=(float**)malloc(sizeof(float*)*in_bw);
				for(int i=0;i<in_bw;i++){
					preSH_data->sol_r[h][i]=(float*)malloc(sizeof(float)*(in_bw-i));
					preSH_data->sol_i[h][i]=(float*)malloc(sizeof(float)*(in_bw-i));
					memset(preSH_data->sol_r[h][i],0,sizeof(float)*(in_bw-i));
					memset(preSH_data->sol_i[h][i],0,sizeof(float)*(in_bw-i));
				}
			}
			soutput=(float*)malloc(sizeof(float)*savedPeaks*9);
			soutputP=(float*)malloc(sizeof(float)*explored_peaks*9);
			//printMemoryGPU("Antes de reservar CUFFT");
			fftError = cufftPlanMany(&plan,3,fftDims,NULL,1,0,NULL,1,0,CUFFT_C2R,FFTPack);
			if(fftError != CUFFT_SUCCESS){
				cerr << "[" << id << "] Error creating gpu FFT plan\n";
				exit(-1);
			}
			fftError = cufftSetCompatibilityMode(plan,CUFFT_COMPATIBILITY_NATIVE);
			if(fftError != CUFFT_SUCCESS){
				cerr << "[" << id << "] Error setting gpu FFT plan compatibility\n";
				exit(-1);
			}
			if(num%FFTPack>0){
				fftError = cufftPlanMany(&planEnd,3,fftDims,NULL,1,0,NULL,1,0,CUFFT_C2R,num%FFTPack);
				if(fftError != CUFFT_SUCCESS){
					cerr << "[" << id << "] Error creating gpu FFT end plan\n";
					exit(-1);
				}
				fftError = cufftSetCompatibilityMode(planEnd,CUFFT_COMPATIBILITY_NATIVE);
				if(fftError != CUFFT_SUCCESS){
					cerr << "[" << id << "] Error setting gpu FFT end plan compatibility\n";
					exit(-1);
				}
			}
			//printMemoryGPU("Despues de reservar CUFFT");
			cudaMalloc(&dCoefCorr,sizeof(float)*correlation_buffer_size*((num/32+1)*32)); // Solo device
			cudaMalloc(&dCoefCorrTarget,sizeof(float)*correlation_target_buffer_size*num);// Solo device
			cudaMalloc(&dCoeffr,sizeof(float)*sizeCoeff*((num/32+1)*32));// Solo device
			cudaMalloc(&dCoeffi,sizeof(float)*sizeCoeff*((num/32+1)*32));// Solo device
			cudaMemset(dCoeffr,0,sizeof(float)*sizeCoeff*((num/32+1)*32));
			cudaMemset(dCoeffi,0,sizeof(float)*sizeCoeff*((num/32+1)*32));
			cudaMalloc(&dCorr,num*spp*sizeof(float)); // Device -> Host
			cudaMalloc(&dPsi,num*spp*sizeof(float)); // Device -> Host
			cudaMalloc(&dTh,num*spp*sizeof(float)); // Device -> Host
			cudaMalloc(&dPhi,num*spp*sizeof(float)); // Device -> Host
			cudaMalloc(&dDdd,sizeof(float)*sizeIntegral); // Host -> Device (una vez)
			cudaMalloc(&dMcoefr,sizeof(float)*num*numLayers*sizeLayer); // Host -> Device (una vez)
			cudaMalloc(&dMcoefi,sizeof(float)*num*numLayers*sizeLayer); // Host -> Device (una vez)
			cudaMalloc(&dSolR,sizeof(float)*bw*bw*MAX_LIGAND_ATOMS); // Host -> Device (muchas veces)
			cudaMalloc(&dSolI,sizeof(float)*bw*bw*MAX_LIGAND_ATOMS); // Host -> Device (muchas veces)

			cudaMallocHost(&hDdd,sizeof(float)*sizeIntegral);
			cudaMallocHost(&hMcoefr,sizeof(float)*num*numLayers*sizeLayer);
			cudaMallocHost(&hMcoefi,sizeof(float)*num*numLayers*sizeLayer);
			cudaMallocHost(&corr,num*spp*sizeof(float));// With IMPROVED search
			cudaMallocHost(&psi,num*spp*sizeof(float));
			cudaMallocHost(&th,num*spp*sizeof(float));
			cudaMallocHost(&phi,num*spp*sizeof(float));

			//printMemoryGPU("Despues de reservar el resto");
			memcpy(hDdd,ddd,sizeof(float)*sizeIntegral);
			cudaMemcpyAsync(dDdd,hDdd,sizeof(float)*sizeIntegral,cudaMemcpyHostToDevice);

			// These arrays below are already reordered before uploading
			// Reorder space data to use it in GPU
			list<PointVoxel>::iterator it = listOfPoints.begin();
			for(int a=0;a < num; a++){
				for(int b=0; b < numLayers; b++){
					int baseIndex = a*numLayers*sizeLayer + b*sizeLayer;
					int writeIndex=0;
					for(int l=0;l<bw;l++){
						for(int m=0;m<=l;m++){
							int readIndex = m*bw-((m*(m-1))/2)+(l-m);
							hMcoefr[baseIndex + writeIndex] = it->getSHRe()[b][readIndex];
							hMcoefi[baseIndex + writeIndex] = it->getSHIm()[b][readIndex];
							writeIndex++;
						}
					}
				}
				it++;
			}

			// Copy space data to GPU
			cudaMemcpyAsync(dMcoefr,hMcoefr,sizeof(float)*num*numLayers*sizeLayer,cudaMemcpyHostToDevice);
			cudaMemcpyAsync(dMcoefi,hMcoefi,sizeof(float)*num*numLayers*sizeLayer,cudaMemcpyHostToDevice);
		}

		

		ATimer tTotal;
		tTotal.startTimer();
		// Docking
		if (id==0) printf("frodrug CUDA> Lig %5d ", molNumber);
		t1.startTimer();
		ligand->eraseAll();
		ligand->add(mol);

		if(ligand->num_atoms()>MAX_LIGAND_ATOMS){
			if (id==0) fprintf(stdout,"Warning %d\n", ligand->num_atoms());
		}

		//PRECALCULATION OF SPHERICAL REPRESENTATION OF THE LIGAND
		createSH(ligand, bw, 0.5f,preSH_data);
		if(preSH_data->rho_max>numLayers) {
			if (id==0) fprintf(stdout,"\nfrodrug> Warning layer %d %d\n", preSH_data->rho_max, numLayers);
			preSH_data->rho_max=numLayers;
		}


		// Find max radii for the ligand
		float center[3];
		ligand->deleteHYDS();
		ligand->geoCenter(center);
		center[0]*= -1.0;
		center[1]*= -1.0;
		center[2]*= -1.0;
		ligand->moveAll(center);
		float ligMaxR = ligand->maxLength()/2.0f;
		//printf("ligMaxR: %2.4f ",ligMaxR);
		int numThisLig = 0;
		for(list<PointVoxel>::iterator it = listOfPoints.begin(); it!=listOfPoints.end(); it++){
			float distanceToSurface = it->getValueClose();
			if(distanceToSurface > ligMaxR){
				break;
			}
			numThisLig++;
		}
		//numThisLig = num;
		//printf("numThisLig: %d ",numThisLig);
		//t1.startTimer();
		CUDAComputeTimer.startTimer();
		ligToGPU(preSH_data,bw,dSolR,dSolI);
		//cudaMemset(dCoeffr,0,sizeof(float)*sizeCoeff*((num/32+1)*32));
		//cudaMemset(dCoeffi,0,sizeof(float)*sizeCoeff*((num/32+1)*32));
		cudaMemset(dCoefCorr,0,sizeof(float)*correlation_buffer_size*num);
		createIntegralDrugCUDA(dCoeffr,dCoeffi,bw,preSH_data->num_atoms,grid_weight[0], numLayers, sizeLayer,dMcoefr,dMcoefi,dSolR,dSolI,num);
		//if(molNumber==4){
		//	writeRawData("dCoeffr.raw",dCoeffr, sizeCoeff*numThisLig,dataOnGPU);
		//	writeRawData("dCoeffi.raw",dCoeffi, sizeCoeff*numThisLig,dataOnGPU);
		//}
		fourierCorrCUDA(bw,dCoeffr,dCoeffi,dDdd,dCoefCorr,numThisLig);
		/*if(molNumber==5){
			writeRawData("dCoefCorr.raw",dCoefCorr, correlation_buffer_size*numThisLig,dataOnGPU);
		}*/
		for(int i=0; i<num/FFTPack; i++){
			fftError = cufftExecC2R(plan,(cufftComplex*)(dCoefCorr+i*correlation_buffer_size*FFTPack),(cufftReal*)(dCoefCorrTarget+i*correlation_target_buffer_size*FFTPack));
			if(fftError != CUFFT_SUCCESS){
				cerr << "[" << id << "] Error executing CUFFT\n";
				exit(-1);
			}
		}
		if(num%FFTPack>0){
			fftError = cufftExecC2R(planEnd,(cufftComplex*)(dCoefCorr+(num/FFTPack)*correlation_buffer_size*FFTPack),(cufftReal*)(dCoefCorrTarget+(num/FFTPack)*correlation_target_buffer_size*FFTPack));
			if(fftError != CUFFT_SUCCESS){
				cerr << "[" << id << "] Error executing CUFFT\n";
				exit(-1);
			}
		}

		searchCorrCUDA(bw,dCoefCorrTarget,dCorr,dPsi, dTh, dPhi, numThisLig);

		cudaMemcpyAsync(corr,dCorr,numThisLig*spp*sizeof(float),cudaMemcpyDeviceToHost);
		cudaMemcpyAsync(psi,dPsi,numThisLig*spp*sizeof(float),cudaMemcpyDeviceToHost);
		cudaMemcpyAsync(th,dTh,numThisLig*spp*sizeof(float),cudaMemcpyDeviceToHost);
		cudaMemcpy(phi,dPhi,numThisLig*spp*sizeof(float),cudaMemcpyDeviceToHost);
		CUDAComputeTimer.stopTimer();
		CUDAComputeTimer.addElapsedTime();

		//float best = 0;
		//int index = -1;
		//for(int c=0;c<numThisLig;c++){
		//	if(corr[c]>best){
		//		index = c;
		//		best = corr[c];
		//	}
		//}
		//cout << "Best corr: " << best << " psi: " << psi[index] << " th: " << th[index]<< " phi: " << phi[index] << endl << flush;

		//t1.stopTimer();
		//cErr = cudaDeviceSynchronize();
		//if(cErr != cudaSuccess){
		//	cout << "CUDA Error : " << cudaGetErrorString(cErr) << endl;
		//	exit(-1);
		//}
		//printf("Time: %.18f\n",t1.getElapsedTime());
		memset(soutputP,0,sizeof(float)*explored_peaks*9);
	
		list<PointVoxel>::iterator it = listOfPoints.begin();
		
		for (int i = 0; i < numThisLig; i++ ){
			for(int s = 0; s < spp; s++){
				int lowestIndex=0;
				float lowestValue=FLT_MAX;
				for(int h=0;h<explored_peaks;h++){
					if(soutputP[h*9]<lowestValue){
						lowestIndex = h;
						lowestValue = soutputP[h*9];
					}
				}
				if(corr[i*spp+s]>lowestValue){
					soutputP[lowestIndex*9]=corr[i*spp+s];
					soutputP[lowestIndex*9+1]=psi[i*spp+s] * 180 / M_PI;
					soutputP[lowestIndex*9+2]=th[i*spp+s] * 180 / M_PI;
					soutputP[lowestIndex*9+3]=phi[i*spp+s] * 180 / M_PI;
					soutputP[lowestIndex*9+4]=it->getX() * voxsize + origin.x() + voxsize/2.0;
					soutputP[lowestIndex*9+5]=it->getY() * voxsize + origin.y() + voxsize/2.0;
					soutputP[lowestIndex*9+6]=it->getZ() * voxsize + origin.z() + voxsize/2.0;
					soutputP[lowestIndex*9+7]=molNumber-1;
				}
			}
			it++;
		}
		//memset(corr,0,num*spp*sizeof(float));
		// Sort by corr REMOVE THIS WHEN TESTED
		for (int h=0; h<explored_peaks; h++){
			for (int k=h+1; k<explored_peaks; k++) {
				int solh=h*9;
				int solk=k*9;
				if (soutputP[solk]>soutputP[solh]) {
					for (int i=0; i<9; i++) {
						float soltemp=soutputP[solh+i];
						soutputP[solh+i]=soutputP[solk+i];
						soutputP[solk+i]=soltemp;
					}

				}
			}
		}

		//
		// Dsx
		//
		float sin_psi;
		float cos_psi;
		float sin_theta;
		float cos_theta;
		float sin_phi;
		float cos_phi;
		float matrix[3][3],dist,buffer[3];;
		float coor_atomL_origen[3];

		int solm;
		float dist_score;
		int int_dist_score, par_lig, par_prot, tipo_final ;
		float dsx_score=0,  dsx_min=9999, Lx, Ly, Lz;
		for (int h=0; h<explored_peaks; h++){
			dsx_score=0;
			solm=h*9;
			buffer[0]=soutputP[solm+1]*M_PI/180.0;
			buffer[1]=soutputP[solm+2]*M_PI/180.0;
			buffer[2]=soutputP[solm+3]*M_PI/180.0;

			sin_psi = sin(buffer[0]);
			cos_psi = cos(buffer[0]);
			sin_theta= sin(buffer[1]);
			cos_theta= cos(buffer[1]);
			sin_phi=sin(buffer[2]);
			cos_phi=cos(buffer[2]);

			matrix[0][0]= cos_psi*cos_phi - cos_theta*sin_phi*sin_psi;
			matrix[0][1]= cos_psi*sin_phi + cos_theta*cos_phi*sin_psi;
			matrix[0][2]= sin_psi*sin_theta;
			matrix[1][0]= -sin_psi*cos_phi - cos_theta*sin_phi*cos_psi;
			matrix[1][1]= -sin_psi*sin_phi + cos_theta*cos_phi*cos_psi;
			matrix[1][2]= cos_psi*sin_theta;
			matrix[2][0]= sin_theta*sin_phi;
			matrix[2][1]= -sin_theta*cos_phi;
			matrix[2][2]= cos_theta;

			float testCount = 0.0f;
			for (int i=0; i<preSH_data->num_atoms; i++) { // ligando
				coor_atomL_origen[0]=preSH_data->posx[i];
				coor_atomL_origen[1]=preSH_data->posy[i];
				coor_atomL_origen[2]=preSH_data->posz[i];

				// rotation
				Lx= coor_atomL_origen[0]*matrix[0][0] + coor_atomL_origen[1]*matrix[0][1] + coor_atomL_origen[2]*matrix[0][2];
				Ly= coor_atomL_origen[0]*matrix[1][0] + coor_atomL_origen[1]*matrix[1][1] + coor_atomL_origen[2]*matrix[1][2];
				Lz= coor_atomL_origen[0]*matrix[2][0] + coor_atomL_origen[1]*matrix[2][1] + coor_atomL_origen[2]*matrix[2][2];

				// translation
				Lx+=soutputP[solm+4];
				Ly+=soutputP[solm+5];
				Lz+=soutputP[solm+6];

				par_lig=preSH_data->dsx[i];

				if ( par_lig!=66 ){
					for (int j=0; j<N_coor_atomP; j++){
						dist=(((Lx-coor_atomP[3*j+0])*(Lx-coor_atomP[3*j+0]))+((Ly-coor_atomP[3*j+1])*(Ly-coor_atomP[3*j+1]))+((Lz-coor_atomP[3*j+2])*(Lz-coor_atomP[3*j+2])) );
						if (dist<=36){
							dist_score=sqrt(dist)*100;
							int_dist_score=(int)dist_score;
							par_prot=tipo_atomP[j];
							tipo_final=tipo[par_lig][par_prot];
							if ( tipo_final!=66 ){
								testCount++;
								dsx_score+=score[tipo_final][(int_dist_score+1)]+(dist_score-(int_dist_score+1))*( (score[tipo_final][(int_dist_score+1)]-score[tipo_final][int_dist_score]));
							}
						}
					}
				}
			}
			//dsx_score /= testCount;
			soutputP[solm+8]=dsx_score;
			if(dsx_score<dsx_min){
				dsx_min=dsx_score;
			}
		}

		//fprintf(stdout," %.2f Avg %.5f Rm %2d N %3d-> %6.2f dsx %6.2f min %6.2f\n",t1.getElapsedTime(),t1.getElapsedTime()/numThisLig,preSH_data[iterMol->pos_molecule-1].rho_max, preSH_data[iterMol->pos_molecule-1].num_atoms,soutputP[0], soutputP[8], dsx_min);
		t1.stopTimer();
		if (id==0) fprintf(stdout," %.2f Avg %.5f Rm %2d N %3d-> %6.2f dsx %6.2f min %6.2f\n",t1.getElapsedTime(),t1.getElapsedTime()/numThisLig,preSH_data->rho_max, preSH_data->num_atoms,soutputP[0], soutputP[8], dsx_min);
		int solh, solk;
		float soltemp;
		// ** sort by dsx
		for (int h=0; h<explored_peaks; h++){
			for (int k=h+1; k<explored_peaks; k++) {
				solh=h*9;
				solk=k*9;
				if (soutputP[solk+8]<soutputP[solh+8]) {
					for (int i=0; i<9; i++) {
						soltemp=soutputP[solh+i];
						soutputP[solh+i]=soutputP[solk+i];
						soutputP[solk+i]=soltemp;
					}

				}
			}
		}

		for (int h=0; h<savedPeaks; h++) {
			solh=h*9;
			for (int i=0; i<9; i++) {
				soutput[solh+i]=soutputP[h*9+i];
			}
		}
		
		//fprintf(stdout," %.2f Avg %.5f Rm %2d N %3d-> %6.2f dsx %6.2f\n",t1.getElapsedTime(),t1.getElapsedTime()/numThisLig,preSH_data->rho_max, preSH_data->num_atoms,soutputP[0], soutputP[8]);

		//cErr = cudaDeviceSynchronize();
		//if(cErr != cudaSuccess){
		//	cout << "CUDA Error : " << cudaGetErrorString(cErr) << endl;
		//	exit(-1);
		//}
		tTotal.stopTimer();
		//if (id==0) printf("Total time: %.18f\n",tTotal.getElapsedTime());
		return soutput;
}

bool checkCUDA(int bw, int points, int numLayers){
	// Enables or disables CUDA capabilities depending on current hardware
	bool CUDAFlag = false;
	cudaDeviceProp deviceProp;
	int sizeCoeff = ((((bw-1)*(4*(bw-1)*(bw-1)-1)/3+(bw-1)*(bw-1))/2)+(bw-1)*(2*(bw-1)+1))+(bw-1)+(bw-1)+1;
	int correlation_buffer_size = 2*bw * 2*bw * 2*(bw+1);
	int correlation_target_buffer_size = 2*bw * 2*bw * 2*bw;
	int sizeLayer = (bw*bw+bw)/2;
	int memPerPoint = sizeof(float) * (correlation_buffer_size + correlation_target_buffer_size + sizeCoeff*2 + numLayers*sizeLayer*2 + 4);
	int totalMemNeeded = memPerPoint * points;
	totalMemNeeded += 1024 * 1024 * 200; // For cuFFT 200 MB of margin
	int win=0;


#ifdef _WIN32
	win=1; // (MPI + CUDA + Windows) is not supported
#endif

#ifdef MPI_RELEASE
	char name[MPI_MAX_PROCESSOR_NAME];
	int nameLength;
	MPI_Get_processor_name(name,&nameLength);
	if(!win){
		if(id==0){
			int size;
			MPI_Comm_size(MPI_COMM_WORLD, &size);
			size--;
			char** nodes = new char* [size];
			int* totalDevices = new int[size];
			int* usedDevices = new int[size];
			for(int i=0;i<size;i++){
				nodes[i] = 0;
				totalDevices[i] = 0;
				usedDevices[i] = 0;
			}
			for(int i=0;i<size;i++){
				int tmpNumDevs;
				char tmpName[MPI_MAX_PROCESSOR_NAME];
				MPI_Status status;
				// Tag 3 for hardware negotiation
				MPI_Recv(tmpName, MPI_MAX_PROCESSOR_NAME, MPI_CHAR, MPI_ANY_SOURCE, 3, MPI_COMM_WORLD,&status);
				int source = status.MPI_SOURCE;
				MPI_Recv(&tmpNumDevs, 1, MPI_INT, source, 3, MPI_COMM_WORLD,&status);
				int n;
				for(n=0;n<size;n++){
					if(nodes[n]!=0){
						if(strcmp(nodes[n],tmpName)==0){
							// The node already exists
							break;
						}
					}else{
						// Creates new node information
						nodes[n] = new char[MPI_MAX_PROCESSOR_NAME];
						strcpy(nodes[n],tmpName);
						totalDevices[n] = tmpNumDevs;
						usedDevices[n] = 0;
						break;
					}
				}
				int devToUse = -1;
				if(usedDevices[n]<totalDevices[n]){
					devToUse = usedDevices[n];
					usedDevices[n]++;
				}
				MPI_Send(&devToUse, 1, MPI_INT, source, 3, MPI_COMM_WORLD);
			}
			delete [] totalDevices;
			delete [] usedDevices;
			for(int i=0;i<size;i++){
					if(nodes[i]!=0){
						delete [] nodes[i];
					}
			}
			delete [] nodes;
		}else{
			int deviceCount;
			cudaGetDeviceCount(&deviceCount);
			int devToUse;
			MPI_Status status;
			MPI_Send(name,MPI_MAX_PROCESSOR_NAME,MPI_CHAR,0,3,MPI_COMM_WORLD);
			MPI_Send(&deviceCount,1,MPI_INT,0,3,MPI_COMM_WORLD);
			MPI_Recv(&devToUse, 1, MPI_INT, 0, 3, MPI_COMM_WORLD,&status);
			if(devToUse>=0){
				cudaSetDevice(devToUse);
				cudaGetDeviceProperties(&deviceProp, devToUse);
				size_t free,total;
				cudaMemGetInfo(&free,&total);
				if(free >= totalMemNeeded && deviceProp.major >= 2){
					CUDAFlag = true;
				}
			}
		}
	}
	if(id!=0){
		if(CUDAFlag){
			cout << "Node " << id << " on " << name << " is using " << deviceProp.name << endl << flush;
		}else{
			cout << "Node " << id << " on " << name << " is using CPU\n" << flush;
		}
	}
#else
	int deviceCount;
	cudaGetDeviceCount(&deviceCount);
	if(deviceCount>0){
		size_t free,total;
		cudaMemGetInfo(&free,&total);
		cudaGetDeviceProperties(&deviceProp, 0);
		if(free >= totalMemNeeded && deviceProp.major >= 2){
			CUDAFlag = true;
			cout << "frodrug CUDA> Using " << deviceProp.name << endl << flush;
		}else{
			cout << "frodrug CUDA> GPU device doesn't have enough resources -> Using CPU" << endl << flush;
		}
	}
#endif

	return CUDAFlag;
}

int main( int argc, char * argv[] ){
	parseOptions(argc,argv);
	const int N_SOLUTIONS = 3;
#ifdef MPI_RELEASE
	// Initialize MPI
	MPI_Init(&argc, &argv);
	MPI_Comm_rank(MPI_COMM_WORLD, &id);
	if(id==0) printf("frodrug> MPI release\n");
#endif
	//PDBs
	Macromolecule *ligand, *ligands,  *ligand_ref, *recept;
	float ligand_max_length,radius_max_length;
	int radius_max_layers;

	//vdw volume
	vlVolume * map[MAX_NUM_MAPS];
	float *eval;  // potential weights
	eval = new float[MAX_NUM_MAPS];
	memset(map,0,sizeof(vlVolume*)*MAX_NUM_MAPS);
	memset(eval,0,sizeof(float)*MAX_NUM_MAPS);

	//Spherical vdw reprepsentation
	vlSpherical *vlsph;

	//Correlation
	int sizeIntegral ;
	float *integralr,*integrali;
	float ****rcoeffsV,****icoeffsV;
	//float *associatedC;
	vlDCoef *vld;
	int correlation_buffer_size;
	float *coef_corr;
	fftwf_plan plan;
	SCollection *solutions=NULL;
	int *ind_coef=NULL,*ind_i_p=NULL,*ind_i_n=NULL;
	int cont_ind=0;

	//Raytracing search
	vlPoint3f subcube_origin,subcube_origin2;
	vlDim subcube_dim,subcube_dim2;
	float subcube_radius,subcube_radius2;
	vlVolume *subcube,*subcube2,*subcube_filled_close,*subcube_filled_far,*aux,*aux2,*aux3;

	//Auxiliar variables
	Tcoor original_center, inverse_original_center;
	vlPoint3f position_map,position_aux;
	int limit_max_layer;
	int in_size_spherical[2];
	int bw2=in_bw*in_bw;
	int size=in_bw*2;
	int size_layer=( bw2 + in_bw ) / 2;
	int h,i,j,k;
	float value_far=0,value_close=0;
	Htimer time,time2,time3;
	double time_ac[5];
	Convention convention=Sybil;
	//    Convention convention=Rosseta;
	ConventionNames convention_name=pdb;
	//	Convention convention_map=ICM;
	//	ConventionNames convention_name_map=pdb;
	float point_distance,min_distance=100000000.0;
	PreSH preSH_data;
	float tback;

	if(id==0) fprintf(stdout,"frodrug>\n");
	switch(in_conv)
	{
	case 0:
		// fprintf(stdout,"Name H convention: iupac\n");
		convention_name=iupac;
		break;
	case 1:
		// fprintf(stdout,"Name H convention: pdb\n");
		convention_name=pdb;
		break;
	case 2:
		// fprintf(stdout,"Name H convention: sybil\n");
		convention_name=sybil;
		break;
	default:
		// fprintf(stdout,"Invalid H name convention set to PDB 3.0\n");
		convention_name=pdb;
		break;
	}
	//
	//
	init_aminoacids(convention,convention_name);
	//
	//Read receptor pdb file
	//
	if(id==0) fprintf(stdout,"frodrug> Reading receptor %s \n", in_rec_pdb);
	recept = new Macromolecule( "Receptor" );
	recept->readPDB( in_rec_pdb );
	//recept->writePDB( "test.pdb" );
	//
	// Reading receptor maps
	//
	// 1) vdW
	if(strcmp(in_maps[0],"")==0)
	{   if(id==0) fprintf(stdout,"frodrug> Building vdw map %s \n", in_maps[0]);
	// map[0]=recept->createVDW(1.0, 0,convention_name_map,convention_map,2.0,1.0,1);

	}
	else
	{
		if(id==0) fprintf(stdout,"frodrug> Reading vdw map %s \n", in_maps[0]);
		map[0]=FOPS::readFile(in_maps[0]);
	}
	map[0]->getPosition(&position_map);
	eval[0]=in_vw;
	//
	// 2) Elec
	//
	if(in_ew>0)
	{
		if(strcmp(in_maps[3],"")==0)
		{
			if(id==0) fprintf(stdout,"frodrug> Building Ele map %s \n", in_maps[0]);
			aux=recept->createELE(1.0,convention_name,convention,-1,0,0);
		}
		else
		{
			if(id==0) fprintf(stdout,"frodrug> Reading vdw map %s \n", in_maps[0]);
			aux=FOPS::readFile(in_maps[1]);
		}
		map[3]=new vlVolume(map[0]);
		FOPS::projectVolume(aux,map[3]);
		delete aux;
		if(in_th> 0)
		{
			FOPS::thresholdUp(map[3],in_th);
			FOPS::thresholdDown(map[3],in_th*(-1.0));
			if(id==0) fprintf(stdout,"\t* Map modification. Threshold applied: %f\n",in_th);
		}
	}
	else
	{
		map[3]=NULL;
	}
	eval[3]=in_ew;
	//
	// 3) Desol
	//
	if(in_sw>0 && strcmp(in_maps[2],"")!=0 )
	{
		aux=FOPS::readFile(in_maps[2]);
		map[2]=new vlVolume(map[0]);
		FOPS::projectVolume(aux,map[2]);
		delete aux;
		if(id==0) fprintf(stdout,"frodrug> Desolvation map read\n");
	}
	else
	{
		map[2]=NULL;
	}
	eval[2]=in_sw;


	//
	// Hydropho
	//
	if(in_hw!=0 && strcmp(in_maps[1],"")!=0 )
	{
		if(id==0) fprintf(stdout,"frodrug> Hydro reading %s\n",in_maps[1]);
		aux=FOPS::readFile(in_maps[1]);
		map[1]=new vlVolume(map[0]);
		FOPS::projectVolume(aux,map[1]);
		// FOPS::writeFile(map[1],"prueba.ccp4"); //
		delete aux;
		if(id==0) fprintf(stdout,"frodrug> Hydrophobic map read\n");
	}
	else
	{
		map[1]=NULL;
	}
	eval[1]=in_hw;
	//
	//  pairwise  Potentials
	//
	for(i=0;i<in_max_pot;i++)
	{
		aux=FOPS::readFile(in_maps[i+4]);
		map[i+4]=new vlVolume(map[0]);
		FOPS::projectVolume(aux,map[i+4]);

		delete aux;
		if(id==0) fprintf(stdout,"frodrug> Hot Spot map read for type %d (weight: %f)\n",pot_type[i],in_eaux[i]);
		eval[i+4]=in_eaux[i];
		//char kk_name[100];
		//sprintf(kk_name,"kk_%d.sit",i);
		//FOPS::writeFile(map[i+4],kk_name);
	}
	num_maps=0;
	for(i=0;i<MAX_NUM_MAPS;i++){
		if(map[i]!=NULL) {
			num_maps++;
		}
	}
	if(id==0) fprintf(stdout,"frodrug> Number of maps %d\n",num_maps);
	if (num_maps>1) {
		if(id==0) fprintf(stdout,"frodrug>  with weights ");
		for(i=0;i<num_maps;i++){
			if(id==0) fprintf(stdout," %2.2f ",eval[i]);
		}
		if(id==0) fprintf(stdout,"\n");
	}


	//DATA PREALLOCATION
	//Function to create integral
	sizeIntegral = in_bw * ( 4 * in_bw * in_bw - 1 ) / 3;
	integralr = ( float * ) malloc( sizeof( float ) * sizeIntegral );
	integrali = ( float * ) malloc( sizeof( float ) * sizeIntegral );

	correlation_buffer_size = 2 * size * size * size;
	coef_corr = ( float * ) malloc( sizeof( float ) * correlation_buffer_size );
	plan = fftwf_plan_dft_c2r_3d( size, size, size, ( fftwf_complex * ) coef_corr, ( float * ) coef_corr, FFTW_ESTIMATE );
	//AssociatedCoef( in_bw, & associatedC );
	vld = new vlDCoef( in_bw, 0.5 * M_PI );
	/* Constructor
	*@param in_point: Number of solutions in temporal buffer
	*@param in_total: Number of solutions in solution buffer
	*@param in_rcut: rotational cutoff
	*@param in_rcut: translational cutoff
	*@param in_bw: Grade of the spherical harmonic base
	*/
	solutions= new SCollection(N_SOLUTIONS, 50,11.0, 0.5, in_bw, map[0]->units().x(),position_map);

	memset( coef_corr, 0, sizeof( float ) * correlation_buffer_size );
	pre_Integral(in_bw, &cont_ind,&ind_coef,&ind_i_p ,&ind_i_n);

	SHC1=(float*)malloc(sizeof(float)*in_bw);
	tback=1.0;
	SHC1[0]=sqrt(tback/2);
	for(i=1;i<in_bw;i++)
	{
		tback*=1.0 + 0.5/i;
		SHC1[i]=sqrt(tback/2);
	}
	SHC2=(float**)malloc(sizeof(float*)*in_bw);
	SHC3=(float**)malloc(sizeof(float*)*in_bw);
	for(i=0;i<in_bw;i++)
	{
		SHC2[i]=(float*)malloc(sizeof(float)*(in_bw-i));
		SHC3[i]=(float*)malloc(sizeof(float)*(in_bw-i));
		for(j=0;j<in_bw-i;j++)
		{
			SHC2[i][j]=2*sqrt((1.0+(i-0.5)/j)*(1.0-(i-0.5)/(2.0*i+j)));
			SHC3[i][j]=-sqrt((1.0-1.0/j)*(1-0-1.0/(2*i+j)) * (1.0+4.0/(2*j+2*i-3)));
		}
	}

	TCOS=(float*)malloc(sizeof(float)*in_bw);
	TSIN=(float*)malloc(sizeof(float)*in_bw);

	//LIGAND GENERAL DATA
	//	if (in_lig_pdb_ref==NULL)
	strcpy(in_lig_pdb_ref, in_lig_pdb);


	if(id==0) fprintf(stdout,"frodrug> Reading ref ligand %s \n", in_lig_pdb);
	ligands = new Macromolecule( "Ligands" );
	ligand_ref = new Macromolecule( "Ligand" );
	ligands->readPDB( in_lig_pdb_ref );
	// ligand->geoCenter(original_center);
	// fprintf(stdout,"Ligand center0: %f %f %f\n",original_center[0],original_center[1],original_center[2]);

	SMol *drug;
	pdbIter *iterMol;
	int num_molecs;
	iterMol = (pdbIter *) new pdbIter(ligands);

	num_molecs = iterMol->num_molecule();
	if(id==0) printf("frodrug> Reading %d ligand molecules\n",num_molecs);


	if(num_molecs== 1) {
		iterMol->pos_molecule=0;
		drug = (SMol *) iterMol->get_molecule();
		ligand_ref->add(drug);
		//ligand_ref->writeMol2("fail.mol2");

		ligand_ref->deleteHYDS();
		//fprintf(stdout,"frodrug> Search center: %f %f %f\n",original_center[0],original_center[1],original_center[2]);
		ligand_ref->geoCenter(original_center);
		if(id==0) fprintf(stdout,"frodrug> Search center: %f %f %f\n",original_center[0],original_center[1],original_center[2]);

		inverse_original_center[0]=original_center[0]*-1.0;
		inverse_original_center[1]=original_center[1]*-1.0;
		inverse_original_center[2]=original_center[2]*-1.0;
		ligand_ref->moveAll( inverse_original_center );
		ligand_max_length=ligand_ref->maxLength();
		radius_max_length=ligand_max_length/2.0;
		radius_max_layers=(int)ceil(radius_max_length/in_width);
		limit_max_layer=radius_max_layers+2;

		//in_ligand_max_length=ligand_max_length;
		in_ligand_max_length=22;
		in_radius_max_length=in_ligand_max_length/2.0;
		in_limit_max_layer=(int)ceil(in_radius_max_length/in_width)+2;
	}else {
		iterMol->pos_molecule=0;
		drug = (SMol *) iterMol->get_molecule();
		ligand_ref->add(drug);
		ligand_ref->deleteHYDS();
		ligand_ref->geoCenter(original_center);
		if(id==0) fprintf(stdout,"frodrug> Search center: %f %f %f\n",original_center[0],original_center[1],original_center[2]);
		inverse_original_center[0]=original_center[0]*-1.0;
		inverse_original_center[1]=original_center[1]*-1.0;
		inverse_original_center[2]=original_center[2]*-1.0;
		ligand_ref->moveAll( inverse_original_center );
		ligand_max_length=ligand_ref->maxLength();
		radius_max_length=ligand_max_length/2.0;
		radius_max_layers=(int)ceil(radius_max_length/in_width);
		limit_max_layer=radius_max_layers+2;

		in_ligand_max_length=24;
		in_radius_max_length=in_ligand_max_length/2.0;
		in_limit_max_layer=(int)ceil(in_radius_max_length/in_width)+2;

		// Read all ligands to find the biggest one and configure max layer
		Macromolecule* l_todos = new Macromolecule( "Ligands" );
		l_todos->readPDB(in_lig_pdb_ref);
		pdbIter* iterActual = (pdbIter *) new pdbIter(l_todos);
		//if(id==0) printf("frodrug> Reading %d ligand molecules, again\n",iterActual->num_molecule());
		iterActual->pos_molecule=0;
		SMol* l_actual = (SMol *) iterActual->get_molecule();
		while(l_actual!=NULL){
			Tcoor original_center, inverse_original_center;
			Macromolecule* l = new Macromolecule("Ligand");
			l->add(l_actual);
			l->deleteHYDS();
			l->geoCenter(original_center);
			inverse_original_center[0]=original_center[0]*-1.0;
			inverse_original_center[1]=original_center[1]*-1.0;
			inverse_original_center[2]=original_center[2]*-1.0;
			l->moveAll(inverse_original_center);
			float l_length=l->maxLength();
			//if(id==0) fprintf(stdout,"frodrug> Ligand %d length: %f\n",iterActual->pos_molecule,l_length);
			if(l_length>in_ligand_max_length){
				in_ligand_max_length=l_length;
			}
			delete l;
			iterActual->next_molecule();
			l_actual = (SMol *) iterActual->get_molecule();
		}

		in_radius_max_length=in_ligand_max_length/2.0;
		in_limit_max_layer=(int)ceil(in_radius_max_length/in_width)+2;

		ligand_max_length=in_ligand_max_length;
		radius_max_length=ligand_max_length/2.0;
		radius_max_layers=(int)ceil(radius_max_length/in_width);
		limit_max_layer=radius_max_layers+2;
	}

	if(id==0) fprintf(stdout,"frodrug> Maximum ligand radius: %f Layer %d\n",in_radius_max_length, in_limit_max_layer);
	//
	//  TRANSLATIONAL POINTS SEARCH
	//
	if(id==0) fprintf(stdout,"frodrug> Generating translational search %f\n", in_er);
	time2.restart();
	Tcoor point,point_real;
	int npoint=0;
	PCollection *points=new PCollection(in_box_s);
	//Raytracing search
	subcube_radius=in_box_l;//10.0;
	subcube_origin.x(original_center[0]-subcube_radius);
	subcube_origin.y(original_center[1]-subcube_radius);
	subcube_origin.z(original_center[2]-subcube_radius);

	//Position of subcube correction
	// project VDW atoms into a grid
	aux=recept->project_radiusVDW(in_box_s,1,false,in_er);
	
	//char *input_map="aux.sit";
	//aux=FOPS::readFile(input_map);
	//FOPS::write(aux,"vdwr.sit");
	aux->getPosition(&position_aux);

	subcube_origin.x( floor((subcube_origin.x()-position_aux.x())/in_box_s) );
	subcube_origin.x( (subcube_origin.x()*in_box_s)+position_aux.x());
	subcube_origin.y( floor((subcube_origin.y()-position_aux.y())/in_box_s) );
	subcube_origin.y( (subcube_origin.y()*in_box_s)+position_aux.y());
	subcube_origin.z( floor((subcube_origin.z()-position_aux.z())/in_box_s) );
	subcube_origin.z( (subcube_origin.z()*in_box_s)+position_aux.z());

	// Dimensions of the docking box
	subcube_radius2=in_box_l+ in_radius_max_length +2;//10.0;
	subcube_origin2.x(original_center[0]-subcube_radius2);
	subcube_origin2.y(original_center[1]-subcube_radius2);
	subcube_origin2.z(original_center[2]-subcube_radius2);

	//Position of subcube correction
	subcube_origin2.x( floor((subcube_origin2.x()-position_aux.x())/in_box_s) );
	subcube_origin2.x( (subcube_origin2.x()*in_box_s)+position_aux.x());
	subcube_origin2.y( floor((subcube_origin2.y()-position_aux.y())/in_box_s) );
	subcube_origin2.y( (subcube_origin2.y()*in_box_s)+position_aux.y());
	subcube_origin2.z( floor((subcube_origin2.z()-position_aux.z())/in_box_s) );
	subcube_origin2.z( (subcube_origin2.z()*in_box_s)+position_aux.z());

	subcube_dim.x((subcube_radius*2.0)/in_box_s);
	subcube_dim.y((subcube_radius*2.0)/in_box_s);
	subcube_dim.z((subcube_radius*2.0)/in_box_s);
	subcube=new vlVolume(subcube_dim,Float,vlUnit(in_box_s,in_box_s,in_box_s));
	subcube->setPosition(subcube_origin);
	if(id==0) printf("frodrug> Box size: %6.3f %6.3f %6.3f\n",subcube->dim().x()*in_box_s,subcube->dim().y()*in_box_s,subcube->dim().z()*in_box_s);
	
	/*printf("ATOM%7d  N   GLY A 735    %8.2f%8.2f%8.2f  1.00 1.00           N\n", 1, subcube_origin.x(),subcube_origin.y(),subcube_origin.z());
	printf("ATOM%7d  N   GLY A 735    %8.2f%8.2f%8.2f  1.00 1.00           N\n", 2, subcube_origin.x()+subcube_dim.x(),subcube_origin.y(),subcube_origin.z());
	printf("ATOM%7d  N   GLY A 735    %8.2f%8.2f%8.2f  1.00 1.00           N\n", 3, subcube_origin.x(),subcube_origin.y()+subcube_dim.y(),subcube_origin.z());
	printf("ATOM%7d  N   GLY A 735    %8.2f%8.2f%8.2f  1.00 1.00           N\n", 4, subcube_origin.x(),subcube_origin.y(),subcube_origin.z()+subcube_dim.z());
	printf("ATOM%7d  N   GLY A 735    %8.2f%8.2f%8.2f  1.00 1.00           N\n", 5, subcube_origin.x()+subcube_dim.x(),subcube_origin.y()+subcube_dim.y(),subcube_origin.z());
	printf("ATOM%7d  N   GLY A 735    %8.2f%8.2f%8.2f  1.00 1.00           N\n", 6, subcube_origin.x(),subcube_origin.y()+subcube_dim.y(),subcube_origin.z()+subcube_dim.z());
	printf("ATOM%7d  N   GLY A 735    %8.2f%8.2f%8.2f  1.00 1.00           N\n", 7, subcube_origin.x()+subcube_dim.x(),subcube_origin.y(),subcube_origin.z()+subcube_dim.z());
	printf("ATOM%7d  N   GLY A 735    %8.2f%8.2f%8.2f  1.00 1.00           N\n", 8, subcube_origin.x()+subcube_dim.x(),subcube_origin.y()+subcube_dim.y(),subcube_origin.z()+subcube_dim.z());
	printf("ATOM%7d  N   GLY A 735    %8.2f%8.2f%8.2f  1.00 1.00           N\n", 9, subcube_origin.x()+(subcube_dim.x()/2),subcube_origin.y()+(subcube_dim.y()/2),subcube_origin.z()+(subcube_dim.z()/2));*/

	subcube_dim2.x((subcube_radius2*2.0)/in_box_s);
	subcube_dim2.y((subcube_radius2*2.0)/in_box_s);
	subcube_dim2.z((subcube_radius2*2.0)/in_box_s);
	// crop of VDW atoms into docking box
	subcube2=new vlVolume(subcube_dim2,Float,vlUnit(in_box_s,in_box_s,in_box_s));
	subcube2->setPosition(subcube_origin2);

	//FILE* dockingBox=fopen("dockingBox.pdb","wt");
	//fprintf(dockingBox,"ATOM%7d  N   GLY A 735    %8.2f%8.2f%8.2f  1.00 1.00           N\n", 1, subcube_origin.x(),subcube_origin.y(),subcube_origin.z());
	//fprintf(dockingBox,"ATOM%7d  N   GLY A 735    %8.2f%8.2f%8.2f  1.00 1.00           N\n", 2, subcube_origin.x()+subcube_dim.x(),subcube_origin.y(),subcube_origin.z());
	//fprintf(dockingBox,"ATOM%7d  N   GLY A 735    %8.2f%8.2f%8.2f  1.00 1.00           N\n", 3, subcube_origin.x(),subcube_origin.y()+subcube_dim.y(),subcube_origin.z());
	//fprintf(dockingBox,"ATOM%7d  N   GLY A 735    %8.2f%8.2f%8.2f  1.00 1.00           N\n", 4, subcube_origin.x(),subcube_origin.y(),subcube_origin.z()+subcube_dim.z());
	//fprintf(dockingBox,"ATOM%7d  N   GLY A 735    %8.2f%8.2f%8.2f  1.00 1.00           N\n", 5, subcube_origin.x()+subcube_dim.x(),subcube_origin.y()+subcube_dim.y(),subcube_origin.z());
	//fprintf(dockingBox,"ATOM%7d  N   GLY A 735    %8.2f%8.2f%8.2f  1.00 1.00           N\n", 6, subcube_origin.x(),subcube_origin.y()+subcube_dim.y(),subcube_origin.z()+subcube_dim.z());
	//fprintf(dockingBox,"ATOM%7d  N   GLY A 735    %8.2f%8.2f%8.2f  1.00 1.00           N\n", 7, subcube_origin.x()+subcube_dim.x(),subcube_origin.y(),subcube_origin.z()+subcube_dim.z());
	//fprintf(dockingBox,"ATOM%7d  N   GLY A 735    %8.2f%8.2f%8.2f  1.00 1.00           N\n", 8, subcube_origin.x()+subcube_dim.x(),subcube_origin.y()+subcube_dim.y(),subcube_origin.z()+subcube_dim.z());
	////fprintf(f,"ATOM%7d  N   GLY A 735    %8.2f%8.2f%8.2f\n",cont_kk++,point_real[0],point_real[1],point_real[2]);
	//fclose(dockingBox);
	//FILE* bigBox=fopen("bigBox.pdb","wt");
	//fprintf(bigBox,"ATOM%7d  N   GLY A 735    %8.2f%8.2f%8.2f  1.00 1.00           N\n", 1, subcube_origin2.x(),subcube_origin2.y(),subcube_origin2.z());
	//fprintf(bigBox,"ATOM%7d  N   GLY A 735    %8.2f%8.2f%8.2f  1.00 1.00           N\n", 2, subcube_origin2.x()+subcube_dim2.x(),subcube_origin2.y(),subcube_origin2.z());
	//fprintf(bigBox,"ATOM%7d  N   GLY A 735    %8.2f%8.2f%8.2f  1.00 1.00           N\n", 3, subcube_origin2.x(),subcube_origin2.y()+subcube_dim2.y(),subcube_origin2.z());
	//fprintf(bigBox,"ATOM%7d  N   GLY A 735    %8.2f%8.2f%8.2f  1.00 1.00           N\n", 4, subcube_origin2.x(),subcube_origin2.y(),subcube_origin2.z()+subcube_dim2.z());
	//fprintf(bigBox,"ATOM%7d  N   GLY A 735    %8.2f%8.2f%8.2f  1.00 1.00           N\n", 5, subcube_origin2.x()+subcube_dim2.x(),subcube_origin2.y()+subcube_dim2.y(),subcube_origin2.z());
	//fprintf(bigBox,"ATOM%7d  N   GLY A 735    %8.2f%8.2f%8.2f  1.00 1.00           N\n", 6, subcube_origin2.x(),subcube_origin2.y()+subcube_dim2.y(),subcube_origin2.z()+subcube_dim2.z());
	//fprintf(bigBox,"ATOM%7d  N   GLY A 735    %8.2f%8.2f%8.2f  1.00 1.00           N\n", 7, subcube_origin2.x()+subcube_dim2.x(),subcube_origin2.y(),subcube_origin2.z()+subcube_dim2.z());
	//fprintf(bigBox,"ATOM%7d  N   GLY A 735    %8.2f%8.2f%8.2f  1.00 1.00           N\n", 8, subcube_origin2.x()+subcube_dim2.x(),subcube_origin2.y()+subcube_dim2.y(),subcube_origin2.z()+subcube_dim2.z());
	////fprintf(f,"ATOM%7d  N   GLY A 735    %8.2f%8.2f%8.2f\n",cont_kk++,point_real[0],point_real[1],point_real[2]);
	//fclose(bigBox);

	//FOPS::projectVolume(aux,subcube);
	//FOPS::write(aux,"aux.sit");
	FOPS::projectVolume(aux,subcube2);
	
	//FOPS::write(subcube2,"subcube2.sit");
	
	aux2=ray_tracer(subcube2,true);
	//FOPS::write(aux2,"RTClosest.sit");
	subcube_filled_close=new vlVolume(subcube);
	subcube_filled_close->clear(0.0);
	FOPS::projectVolume(aux2,subcube_filled_close);
	//FOPS::write(subcube_filled_close,"subcube_filled_close.sit");
	aux3=ray_tracer_inner(subcube2,aux2);
	subcube_filled_far=new vlVolume(subcube_filled_close);
	subcube_filled_far->setPosition(subcube_origin);
	subcube_filled_far->clear(0.0);
	FOPS::projectVolume(aux3,subcube_filled_far);
	//FOPS::writeFile(subcube_filled_close,"close.ccp4");
	//FOPS::writeFile(subcube_filled_far,"far.ccp4");
	//FOPS::writeFile(subcube,"subcube.ccp4");
	//FOPS::writeFile(subcube2,"subcube2.ccp4");
	//FOPS::writeFile(aux,"aux.ccp4");
	delete aux2;
	delete aux3;
	delete subcube2;
	delete subcube;
	delete aux;

	//ONE POSITION
	//point[0]=(original_center[0]-position_map.x()-map[0]->units().x()/2.0)/map[0]->units().x();
	//point[1]=(original_center[1]-position_map.y()-map[0]->units().y()/2.0)/map[0]->units().y();
	//point[2]=(original_center[2]-position_map.z()-map[0]->units().z()/2.0)/map[0]->units().z();
	//fprintf(stderr,"%f %f %f\n",point[0],point[1],point[2]);
	//points->Insert_point(point);

	int cont_kk=0, neig;
	float value_neig_far=0, value_neig_close=0, min_distancex=0,min_distancey=0, min_distancez=0 ;
	float far_length, close_length;

	if(num_molecs==1) {
		close_length=radius_max_length*0.5;
		if (close_length<3.5){
			close_length=3.5;
		}
	}else{
		close_length=radius_max_length;
		/*if (close_length<3.5){
			close_length=3.5;
		}*/
	}

	if(num_molecs==1) {
		far_length=radius_max_length*0.5;
	} else {
		far_length=in_radius_max_length*0.5;
		if (far_length>7.0){
			far_length=7.0;
		}
	}

	aux2=new vlVolume(subcube_filled_close);
	aux2->setPosition(subcube_origin);
	aux2->clear(0.0);
	for(i=0;i<subcube_filled_close->dim().x();i++)
	{
		for(j=0;j<subcube_filled_close->dim().y();j++)
		{
			for(k=0;k<subcube_filled_close->dim().z();k++)
			{
				subcube_filled_far->getVoxel(vlPoint3ui(i,j,k),value_far);
				subcube_filled_close->getVoxel(vlPoint3ui(i,j,k),value_close);
				if(value_close<close_length && value_close > 0 && (value_far>far_length || value_close<1))
				{

					int is, js, ks;
					int is2, js2, ks2;
					if (i==0) is=0; else is=1;
					if (j==0) js=0; else js=1;
					if (k==0) ks=0; else ks=1;
					if (i==subcube_filled_close->dim().x()-1)  is2=1; else is2=2;
					if (j==subcube_filled_close->dim().y()-1)  js2=1; else js2=2;
					if (k==subcube_filled_close->dim().z()-1)  ks2=1; else ks2=2;

					neig=0;
					for(int ii=i-is;ii<i+is2;ii++){
						for(int jj=j-js;jj<j+js2;jj++){
							for(int kk=k-ks;kk<k+ks2;kk++) {
								subcube_filled_far->getVoxel(vlPoint3ui(ii,jj,kk),value_neig_far);
								subcube_filled_close->getVoxel(vlPoint3ui(ii,jj,kk),value_neig_close);

								if(value_neig_close<close_length && value_neig_close > 0 && (value_neig_far>far_length || value_neig_close<1)){
									neig++;
								}
								// check empties 
								if (neig >6) {
									ii=i+2; jj=j+2; kk=k+2;
								} // salgo bucle
								//			fprintf(stdout,"%d %d %d %f %f %f %d\n",ii, jj, kk, value_close,value_far,value_neig, neig);
								//		    getchar();
							}
						}
					}

					if (neig >6) {
						point[0]=((float)i*subcube_filled_close->units().x())+subcube_origin.x();
						point_real[0]=point[0];
						point[0]=(point[0]-position_map.x()-map[0]->units().x()/2.0)/map[0]->units().x();
						point[1]=((float)j*subcube_filled_close->units().y())+subcube_origin.y();
						point_real[1]=point[1];
						point[1]=(point[1]-position_map.y()-map[0]->units().y()/2.0)/map[0]->units().y();
						point[2]=((float)k*subcube_filled_close->units().z())+subcube_origin.z();
						point_real[2]=point[2];
						point[2]=(point[2]-position_map.z()-map[0]->units().z()/2.0)/map[0]->units().z();

						point_distance=( (point_real[0]-original_center[0])*(point_real[0]-original_center[0]) +
							(point_real[1]-original_center[1])*(point_real[1]-original_center[1]) +
							(point_real[2]-original_center[2])*(point_real[2]-original_center[2]) );

						if(point_distance<min_distance) {
							min_distance=point_distance;
							min_distancex=(point_real[0]-original_center[0]);
							min_distancey=(point_real[1]-original_center[1]);
							min_distancez=(point_real[2]-original_center[2]);
						}

						//							fprintf(f,"ATOM%7d  N   GLY A 735    %8.2f%8.2f%8.2f  1.00 %6.3f           N\n",
						//									cont_kk++,point_real[0],point_real[1],point_real[2],value_far);

						aux2->setVoxel(vlPoint3ui(i,j,k),value_neig_close);

					}
					else{
						//	if(value_close<radius_max_length && value_close > 0)
						//		fprintf(stdout,"Space too narrow %f %f %f\n",value_close,value_far,radius_max_length);
					}
				}
			}
		}
	}

	// fclose(f);
	//FOPS::writeFile(aux2,"pointsBefore.sit");
	// fprintf(stdout,"Number of points: %d\n",points->num);
	//min_distance=sqrt(min_distance);
	// fprintf(stdout,"%s minimum distance to central point: %f\n",in_lig_pdb,min_distance);

	vlVolume *mas;
	int *listMask;
	int max, limit_mask=-1;
	FILE *f;
	mas=new vlVolume(aux2);
	mas->setPosition(subcube_origin);
	mas->clear(0.0);
	mas=FOPS::regions(aux2,0.01,&listMask,&max,10,true,0);
	//FOPS::writeFile(mas,"pointsAfter.sit");
	//vlVolume *dts=new vlVolume(aux2); // Distance to surface
	//dts->setPosition(subcube_origin);
	//dts->clear(0.0);
	in_saveT=false;
	if (in_saveT){
		f=fopen("points.pdb","wt");
	}

	for (int k=0; k<max; k++){
		if(listMask[k] > 100){
			limit_mask=k;
			break;
		}
	}

	list<PointVoxel> listOfPoints;

	cont_kk=1;
	for(i=0;i<mas->dim().x();i++){
		for(j=0;j<mas->dim().y();j++){
			for(k=0;k<mas->dim().z();k++){
				mas->getVoxel(vlPoint3ui(i,j,k),value_close);
				if (value_close>limit_mask) {
					float distClose,distFar;
					subcube_filled_close->getVoxel(vlPoint3ui(i,j,k),distClose);
					subcube_filled_far->getVoxel(vlPoint3ui(i,j,k),distFar);
					//dts->setVoxel(vlPoint3ui(i,j,k),distClose);
					point[0]=((float)i*mas->units().x())+subcube_origin.x();
					point_real[0]=point[0];
					point[0]=(point[0]-position_map.x()-map[0]->units().x()/2.0)/map[0]->units().x();

					point[1]=((float)j*mas->units().y())+subcube_origin.y();
					point_real[1]=point[1];
					point[1]=(point[1]-position_map.y()-map[0]->units().y()/2.0)/map[0]->units().y();

					point[2]=((float)k*mas->units().z())+subcube_origin.z();
					point_real[2]=point[2];
					point[2]=(point[2]-position_map.z()-map[0]->units().z()/2.0)/map[0]->units().z();

					points->Insert_point(point);
					listOfPoints.push_back(PointVoxel(point,distClose,distFar));
					if (in_saveT){
						if(id==0) fprintf(f,"ATOM%7d  N   GLY A 735    %8.2f%8.2f%8.2f\n",cont_kk++,point_real[0],point_real[1],point_real[2]);
						//if(id==0) fprintf(f,"ATOM%7d  N   GLY A 735    %8.2f%8.2f%8.2f   %6.3f %6.3f           N\n",cont_kk++,point_real[0],point_real[1],point_real[2],value_close, distClose);
					}
				}
			}
		}
	}
	if (in_saveT){
		fclose(f);
	}

	if(id==0) fprintf(stdout,"frodrug> Number of points: %d  %s\n",points->num, time2.print_time());
	if (in_saveT){
		fprintf(stdout,"frodrug> Saved at points.pdb\n");
	}

	// Set Distance to Surface array
	float *dts = new float[points->num];
	int p=0;
	for(list<PointVoxel>::iterator it = listOfPoints.begin(); it!=listOfPoints.end(); it++){
		float distanceToSurface = it->getValueClose();
		dts[p] = distanceToSurface;
		p++;
	}

	min_distance=sqrt(min_distance);
	if(id==0) fprintf(stdout,"frodrug> Minimum distance to central point: %6.3f    x:%6.3f y:%6.3f z:%6.3f\n",min_distance,min_distancex,min_distancey,min_distancez);

	//FOPS::writeFile(mas,"m2.ccp4");
	//f=fopen("point.pdb","wt");
	//fprintf(f,"ATOM%7d  N   GLY A 735    %8.2f%8.2f%8.2f  1.00 0.00           N\n",
	//	          cont_kk,original_center[0],original_center[1],original_center[2]);
	//fclose(f);

	//
	// MEMORY PRECOMPUTATIONS
	//
	rcoeffsV = ( float ****) malloc( sizeof( float *** ) * num_maps );
	icoeffsV = ( float ****) malloc( sizeof( float *** ) * num_maps );
	for(k=0;k<num_maps;k++)
	{
		rcoeffsV[k] = ( float ***) malloc( sizeof( float ** ) * points->num );
		icoeffsV[k] = ( float ***) malloc( sizeof( float ** ) * points->num );

		for(j=0;j<points->num;j++)
		{
			rcoeffsV[k][j] = ( float * *) malloc( sizeof( float * ) * in_limit_max_layer );
			icoeffsV[k][j] = ( float * *) malloc( sizeof( float * ) * in_limit_max_layer );

			if(rcoeffsV[k][j]==NULL || icoeffsV[k][j]==NULL)
			{
				if(id==0) fprintf(stdout,"frodrug> Memory allocation not possible\n");

			}
			for ( i = 0; i < in_limit_max_layer; i++ )
			{
				rcoeffsV[k][j][i] = ( float * ) malloc( sizeof( float ) * size_layer );
				icoeffsV[k][j][i] = ( float * ) malloc( sizeof( float ) * size_layer );
				if(rcoeffsV[k][j][i]==NULL || icoeffsV[k][j][i]==NULL)
				{
					if(id==0) fprintf(stdout,"frodrug> Memory allocation not possible\n");

				}

				memset(rcoeffsV[k][j][i],0, sizeof( float ) * size_layer);
				memset(icoeffsV[k][j][i],0, sizeof( float ) * size_layer );

			}
		}
	}

	// Set SH representations for each point of the dinamyc list
	int index=0;
	for(list<PointVoxel>::iterator it = listOfPoints.begin(); it != listOfPoints.end(); it++){
		it->setSH(rcoeffsV[0][index],icoeffsV[0][index]);
		index++;
	}
	listOfPoints.sort(); // The points are sorted by distance to surface
	
	preSH_data.sol_r=(float***)malloc(sizeof(float**)*MAX_LIGAND_ATOMS);
	preSH_data.sol_i=(float***)malloc(sizeof(float**)*MAX_LIGAND_ATOMS);
	//	preSH_data.radius=(float*)malloc(sizeof(float)*MAX_LIGAND_ATOMS);
	preSH_data.fup=(float*)malloc(sizeof(float)*MAX_LIGAND_ATOMS);
	preSH_data.fdown=(float*)malloc(sizeof(float)*MAX_LIGAND_ATOMS);
	preSH_data.rho_up_index=(int*)malloc(sizeof(int)*MAX_LIGAND_ATOMS);
	preSH_data.rho_down_index=(int*)malloc(sizeof(int)*MAX_LIGAND_ATOMS);
	preSH_data.type=(int*)malloc(sizeof(int)*MAX_LIGAND_ATOMS);
	preSH_data.li=(float*)malloc(sizeof(float)*MAX_LIGAND_ATOMS);
	preSH_data.li2=(float*)malloc(sizeof(float)*MAX_LIGAND_ATOMS);
	preSH_data.dsx=(int*)malloc(sizeof(int)*MAX_LIGAND_ATOMS);
	preSH_data.posx=(float*)malloc(sizeof(float)*MAX_LIGAND_ATOMS);
	preSH_data.posy=(float*)malloc(sizeof(float)*MAX_LIGAND_ATOMS);
	preSH_data.posz=(float*)malloc(sizeof(float)*MAX_LIGAND_ATOMS);

	for(h=0;h<MAX_LIGAND_ATOMS;h++)
	{
		preSH_data.sol_r[h]=(float**)malloc(sizeof(float*)*in_bw);
		preSH_data.sol_i[h]=(float**)malloc(sizeof(float*)*in_bw);
		for(i=0;i<in_bw;i++)
		{
			preSH_data.sol_r[h][i]=(float*)malloc(sizeof(float)*(in_bw-i));
			preSH_data.sol_i[h][i]=(float*)malloc(sizeof(float)*(in_bw-i));
			memset(preSH_data.sol_r[h][i],0,sizeof(float)*(in_bw-i));
			memset(preSH_data.sol_i[h][i],0,sizeof(float)*(in_bw-i));
		}
	}
	//
	//
	// TRANSLATIONAL SEARCH PRECOMPUTATIONS
	//
	if(id==0) fprintf(stdout,"frodrug> Precomputations protein grids");
	time2.restart();
	vlsph= new vlSpherical( in_bw, in_limit_max_layer );
	vlsph->preComputation();

	for(i=0;i<num_maps;i++)
	{
		//FILE *file_r_layers=fopen("receptorR.dat","rb");
		//fprintf(stdout,"mapa=%d\n",i);
		npoint=0;
		while(points->return_point(npoint,point)==1)
		{
			vlsph->clear();
			vlsph=volumetric_sampling_slow_drug(map[i], in_size_spherical, in_bw, in_limit_max_layer,point[0],point[1],point[2],in_width/map[0]->units().x(),vlsph);
			sph_to_sh(vlsph, rcoeffsV[i][npoint], icoeffsV[i][npoint], in_size_spherical);
			//write_receptor_layers(file_r_layers, in_size_spherical, rcoeffsV,icoeffsV, size_layer);
			//read_receptor_layers(file_r_layers, in_size_spherical, rcoeffsV,icoeffsV, size_layer);
			//writeSphVol("kakita.pdb", vlsph, in_bw,limit_max_layer,in_width, (point[0]*map[0]->units().x())+position_map.x()+map[0]->units().x()/2.0,(point[1]*map[0]->units().y())+position_map.y()+map[0]->units().y()/2.0,(point[2]*map[0]->units().z())+position_map.z()+map[0]->units().z()/2.0);
			//exit(1);
			npoint++;
		}
	}
	if(id==0) fprintf(stdout,"->%s\n",time2.print_time());

	//
	// DSX potentials files
	//
	float dato;
	//float score[300][601];
	float** score;
	score = new float*[300];
	for(int x=0;x<300;x++){
		score[x] = new float[601];
	}
	int hindex, datoi;
	//int tipo[66][66];
	int **tipo;
	tipo = new int*[66];
	for (int x = 0;x<66;x++){
		tipo[x] = new int[66];
	}
	if(id==0) fprintf(stdout,"frodrug> Reading pairwise potentials\n");
	FILE *pwdata;

	pwdata=fopen("pwpot.dat","rb");
	if (pwdata==NULL) {
		if(id==0) fprintf(stdout," error reading pwpot.dat\n");
	}
	for (int j=0; j<66; j++){
		for (int k=0; k<66;  k++) {
			fread(&datoi,  sizeof(int),  1, pwdata);
			tipo[j][k]=datoi;
		}
	}
	hindex = -1;
	for (int i = 0; i < 180300; i++) {
		fread(&dato, sizeof(float), 1, pwdata);
		if (fmod(i, 300.0) == 0) 	hindex++;
		score[i - (300 * hindex)][hindex] = dato;
	}
	fclose(pwdata);


	//
	//
	// Receptor DSX potentials
	//
	//

	pdbIter *iter_prot,  *iterA;
	Fragment *res;
	Atom *atomP;
	float posP[3], *coor_atomP;
	int *tipo_atomP;
	int cont=0, N_coor_atomP=0;


	iter_prot= new pdbIter(recept);

	N_coor_atomP=recept->get_num_atoms();

	// fprintf(stdout, " cont=%d  N=%d\n", cont, N_coor_atomP);

	coor_atomP=(float*)malloc(sizeof(float)*N_coor_atomP*3);
	if (coor_atomP == NULL) {
		fputs("not enought memory for coor_atomP ", stderr);
		exit(1);
	}
	tipo_atomP=(int*)malloc(sizeof(int)*N_coor_atomP);
	if (tipo_atomP == NULL) {
		fputs("not enought memory for tipo_atomP ", stderr);
		exit(1);
	}
	int resn;


	//HASTA AQUI LEO BIEN LOS ÁTOMOS DE LA PROTEÍNA
	cont=0;
	for(iter_prot->pos_fragment=0; !iter_prot->gend_fragment(); iter_prot->next_fragment() )
	{
		res = iter_prot->get_fragment();
		iterA = new pdbIter(res); // iterate "A" fragment atoms

		// fprintf( stdout, "Processing aa %s\n", res->getName());

		// check AA
		for ( resn = 0; resn < N_AMINO; resn++ )
		{
			if ( strcmp( res->getName(), AA[resn].aa_name3 ) == 0 )
				break;
		}
		//fprintf( stdout, "Processing %d\n", resn);

		if ( resn > N_AMINO -1 )
		{
			if(id==0) fprintf( stdout, "Warning %s residue is not an aa\n", res->getName());
			//getchar();
		} else
		{
			for(iterA->pos_atom=0; !iterA->gend_atom(); iterA->next_atom() )
			{
				atomP = iterA->get_atom();
				atomP->getPosition(posP);
				// atomP->getPdbName();

				coor_atomP[cont*3+0]=posP[0];
				coor_atomP[cont*3+1]=posP[1];
				coor_atomP[cont*3+2]=posP[2];
				// fprintf( stdout, "Processing %s %f %d %d\n", atomP->getPdbName(), posP[0], cont, AA[resn].natoms+3 );
				// check atom ....
				for(int k=0;k<AA[resn].natoms+3;k++)
				{
					// fprintf( stdout, "comparing %s %s %d\n", atomP->getPdbName(), AA[resn].atom[k].atom_name, k);

					if(strcmp(atomP->getPdbName(),AA[resn].atom[k].atom_name)==0)
					{
						tipo_atomP[cont]=AA[resn].atom[k].fullatom_type;
						k=AA[resn].natoms+4;
					}
					else {
						tipo_atomP[cont]=66;
					}

				}
				//	if ((cont>10520)&&(cont<10530)) fprintf(stdout, " cont=%d  AA_atomo=%d AA=%s %s\n", cont, tipo_atomP[cont],
				//			AA[resn].aa_name3, atomP->getPdbName());
				if (tipo_atomP[cont]!=66) cont++;
			}

		}
		//fprintf( stdout, "End aa\n");
	}


	//  fprintf(stdout, " cont=%d  N=%d\n", cont, N_coor_atomP);
	N_coor_atomP=cont;
	// getchar();

	//
	// LIGAND INPUT
	//




	// fprintf(stdout,"frodrug> Reading ligand %s \n", in_lig_pdb);

	ligand = new Macromolecule( "Ligand" );

	if(id==0) fprintf(stdout,"frodrug> VS\n");
	int start_lig;
	if(num_molecs== 1) start_lig=0;
	else start_lig=1;

	int totalPeaks;
	int saved_peaks=15;
	int explored_peaks=50;

	int startmol=1;
	if(num_molecs== 1) {
		startmol=0;
	}
	totalPeaks=saved_peaks*(num_molecs-startmol);

	float  *soutput;
	soutput=(float*)malloc(sizeof(float)*totalPeaks*9);
	if (soutput==NULL) {fprintf(stderr,"error output ");}

	float  *soutputP;
	soutputP=(float*)malloc(sizeof(float)*explored_peaks*9);
	if (soutputP==NULL) {fprintf(stderr,"error output ");}

	if(CUDAFlag){
		CUDAFlag = checkCUDA(in_bw,listOfPoints.size(),in_limit_max_layer);
	}

	time_ac[1]=0;

#ifdef MPI_RELEASE
	MPIManager mman;
	if(id==0){
		// MPI Server
		time_ac[1] = mman.startServer(startmol, iterMol->num_molecule(),soutput, saved_peaks);
	}else{
		// MPI Client
		int mol = mman.getMol();
		while(mol>=0){
			iterMol->pos_molecule=mol;
			drug = (SMol *) iterMol->get_molecule();
			//cout << "frodrug " << id << "> Lig " << iterMol->pos_molecule << endl << flush;
			//CUDAFlag = false;
			if(CUDAFlag){
				float* tempOutput;
				tempOutput = dockingCUDA_SingleLigand(in_bw,vld->ddd,listOfPoints,eval,in_limit_max_layer, drug,map[0]->units().x(),position_map,score,tipo_atomP,coor_atomP,N_coor_atomP,tipo, mol);
				memcpy(soutput+(mol-1)*saved_peaks*9,tempOutput,saved_peaks*9*sizeof(float));
				mman.sendData(iterMol->pos_molecule-startmol,saved_peaks,&soutput[(iterMol->pos_molecule-startmol)*saved_peaks*9],CUDAComputeTimer.getTotalTime());
				CUDAComputeTimer.resetTotalTime();
			}else{
				ligand->eraseAll();
				ligand->add(drug);

				// time2.restart();

				if (ligand->num_atoms()>MAX_LIGAND_ATOMS) {
					fprintf(stdout,"Warning %d\n", ligand->num_atoms());
					//      PENDING a realloc if bigger
				}

				//PRECALCULATION OF SPHERICAL REPRESENTATION OF THE LIGAND
				createSH(ligand, in_bw, in_width,&preSH_data );

				if (preSH_data.rho_max>in_limit_max_layer) {
					fprintf(stdout,"\nfrodrug> Warning layer %d %d\n", preSH_data.rho_max, in_limit_max_layer);
					preSH_data.rho_max=in_limit_max_layer;
				}
				time3.restart();
				time_ac[0]=0;
				for(int i=0;i<points->num;i++){
					// Find max radii for the ligand
					float center[3];
					ligand->deleteHYDS();
					ligand->geoCenter(center);
					center[0]*= -1.0;
					center[1]*= -1.0;
					center[2]*= -1.0;
					ligand->moveAll(center);
					float ligMaxR = ligand->maxLength()/2.0f;
					if(dts[i] <= ligMaxR){
						time2.restart();
						points->return_point(i,point);
						memset( integrali, 0, sizeof( float ) * sizeIntegral );
						memset( integralr, 0, sizeof( float ) * sizeIntegral );
						//fprintf(stdout,"Correlation\n");
						for(j=0;j<num_maps;j++){
							createIntegral_drug(integrali, integralr,rcoeffsV[j][i],icoeffsV[j][i],	in_bw,ind_coef,ind_i_p, ind_i_n,&preSH_data,eval[j],j);
						}
						//strcpy(t1,time2.print_time());
						//fprintf(stdout,"Correlation\n");
						//time2.restart();
						fourier_corr( in_bw, integralr, integrali, vld, coef_corr );
						//strcpy(t2,time2.print_time());
						//time2.restart();
						fftwf_execute( plan );
						//strcpy(t3,time2.print_time());
						//fprintf(stdout,"Introduction of solutions\n");
						//time2.restart();
						solutions->insert(coef_corr,point);
						//sprintf(stdout,"Solution %f \n",solutions.best_solutions_found[0]);
						//strcpy(t4,time2.print_time());
						time_ac[0]+=time2.elapsed();
						//fprintf(stdout,"Tiempo por punto: %s\n",time2.print_time());
					}
				}

				solutions->write_solutions_frodrug((iterMol->pos_molecule-startmol), soutputP);


				//
				// Dsx
				//
				float sin_psi;
				float cos_psi;
				float sin_theta;
				float cos_theta;
				float sin_phi;
				float cos_phi;
				float matrix[3][3],dist,buffer[3];;
				float coor_atomL_origen[3];

				int solm;
				float dist_score;
				int int_dist_score, par_lig, par_prot, tipo_final ;
				float dsx_score=0,  dsx_min=9999, Lx, Ly, Lz;
				dsx_score=0;
				for (int h=0; h<explored_peaks; h++){
					dsx_score=0;
					//solm=((iterMol->pos_molecule-startmol)*50+h)*9;
					solm=h*9;
					buffer[0]=soutputP[solm+1]*3.1415297/180.0;
					buffer[1]=soutputP[solm+2]*3.1415297/180.0;
					buffer[2]=soutputP[solm+3]*3.1415297/180.0;

					sin_psi = sin(buffer[0]);
					cos_psi = cos(buffer[0]);
					sin_theta= sin(buffer[1]);
					cos_theta= cos(buffer[1]);
					sin_phi=sin(buffer[2]);
					cos_phi=cos(buffer[2]);

					matrix[0][0]= cos_psi*cos_phi - cos_theta*sin_phi*sin_psi;
					matrix[0][1]= cos_psi*sin_phi + cos_theta*cos_phi*sin_psi;
					matrix[0][2]= sin_psi*sin_theta;
					matrix[1][0]= -sin_psi*cos_phi - cos_theta*sin_phi*cos_psi;
					matrix[1][1]= -sin_psi*sin_phi + cos_theta*cos_phi*cos_psi;
					matrix[1][2]= cos_psi*sin_theta;
					matrix[2][0]= sin_theta*sin_phi;
					matrix[2][1]= -sin_theta*cos_phi;
					matrix[2][2]= cos_theta;

					float testCount = 0.0f;
					for (int i=0; i<preSH_data.num_atoms; i++) { // ligando

						coor_atomL_origen[0]=preSH_data.posx[i];
						coor_atomL_origen[1]=preSH_data.posy[i];
						coor_atomL_origen[2]=preSH_data.posz[i];

						// rotation
						Lx= coor_atomL_origen[0]*matrix[0][0] + coor_atomL_origen[1]*matrix[0][1] + coor_atomL_origen[2]*matrix[0][2];
						Ly= coor_atomL_origen[0]*matrix[1][0] + coor_atomL_origen[1]*matrix[1][1] + coor_atomL_origen[2]*matrix[1][2];
						Lz= coor_atomL_origen[0]*matrix[2][0] + coor_atomL_origen[1]*matrix[2][1] + coor_atomL_origen[2]*matrix[2][2];

						// translation
						Lx+=soutputP[solm+4];
						Ly+=soutputP[solm+5];
						Lz+=soutputP[solm+6];

						par_lig=preSH_data.dsx[i];

						if ( par_lig!=66 ){
							for (int j=0; j<N_coor_atomP; j++){
								dist= (((Lx-coor_atomP[3*j+0])*(Lx-coor_atomP[3*j+0]))
									+((Ly-coor_atomP[3*j+1])*(Ly-coor_atomP[3*j+1]))
									+((Lz-coor_atomP[3*j+2])*(Lz-coor_atomP[3*j+2])) );

								if (dist<=36){
									dist_score=sqrt(dist)*100;
									int_dist_score=(int)dist_score;
									par_prot=tipo_atomP[j];
									//        				fprintf(stderr, "%d(%d,%d)[%d]-t=%d",i,j, par_prot,int_dist_score,tipo[par_lig][par_prot]);
									tipo_final=tipo[par_lig][par_prot];

									if ( tipo_final!=66 ){
										testCount++;
										dsx_score+=	score[tipo_final][(int_dist_score+1)]+(dist_score-(int_dist_score+1))*( (score[tipo_final][(int_dist_score+1)]-score[tipo_final][int_dist_score]));
									}

								}
							}
						}
					}
					dsx_score /= testCount;
					soutputP[solm+8]=dsx_score;
					if (dsx_score<dsx_min) dsx_min=dsx_score;
					// fprintf(stdout," sol %d FRM-> %f  dsx %f\n",h, soutputP[solm], soutputP[solm+8]);
					// getchar();

				}

				time_ac[1]+=time_ac[0];
				if(num_molecs== 1) {

					//fprintf(stdout," %.2f Avg %.5f Rm %2d N %3d-> %6.2f dsx %6.2f min %6.2f\n",time_ac[0],time_ac[0]/points->num,preSH_data.rho_max, preSH_data.num_atoms, soutputP[0], soutputP[8], dsx_min);


					// solutions->write_solutions(in_output);
				} else {
					// solutions->write_solutions_frodrug(iterMol->pos_molecule, output);
					//fprintf(stdout," %.2f Avg %.5f Rm %2d N %3d-> %6.2f dsx %6.2f min %6.2f\n",time_ac[0],time_ac[0]/points->num,	preSH_data.rho_max, preSH_data.num_atoms,soutputP[0], soutputP[8], dsx_min);

				}
				int solh, solk;
				float soltemp;
				// ** sort by dsx
				for (int h=0; h<explored_peaks; h++){
					for (int k=h+1; k<explored_peaks; k++){
						solh=h*9;
						solk=k*9;
						if (soutputP[solk+8]<soutputP[solh+8]) {
							for (int i=0; i<9; i++) {
								soltemp=soutputP[solh+i];
								soutputP[solh+i]=soutputP[solk+i];
								soutputP[solk+i]=soltemp;
							}

						}
					}
				}

				for (int h=0; h<saved_peaks; h++) {
					solh=((iterMol->pos_molecule-startmol)*saved_peaks+h)*9;
					// fprintf(stderr, "%3d ", solh);
					for (int i=0; i<9; i++) {
						soutput[solh+i]=soutputP[h*9+i];
						//fprintf(stderr, " %6.2f ",soutput[solh+i]);
					}
					//fprintf(stderr,"\n");

				}

				solutions->clear_solutions();
				mman.sendData(iterMol->pos_molecule-startmol,saved_peaks,&soutput[(iterMol->pos_molecule-startmol)*saved_peaks*9], time_ac[0]);
			}
			mol = mman.getMol();
		}
		MPI_Finalize();
		exit(0);
	}
#else
//CUDAFlag = false;
	if(CUDAFlag){
		//cudaSetDevice(1);
		ATimer t1;
		t1.startTimer();
		float* tempOutput;
		for(iterMol->pos_molecule=startmol; !iterMol->gend_molecule(); iterMol->next_molecule()){
			//iterMol->pos_molecule = 5;
			//if (iterMol->pos_molecule == 11){exit(0);}
			drug = (SMol *) iterMol->get_molecule();
			tempOutput = dockingCUDA_SingleLigand(in_bw,vld->ddd,listOfPoints,eval,in_limit_max_layer, drug, map[0]->units().x(),position_map,score,tipo_atomP,coor_atomP,N_coor_atomP,tipo, iterMol->pos_molecule);
			memcpy(soutput+(iterMol->pos_molecule-1)*saved_peaks*9,tempOutput,saved_peaks*9*sizeof(float));
			//exit(0);
		}
		/*}else{
			soutput = dockingCUDA(in_bw,vld->ddd,points,rcoeffsV,icoeffsV,eval,in_limit_max_layer, iterMol, startmol,map[0]->units().x(),position_map,score,tipo_atomP,coor_atomP,N_coor_atomP,tipo);
		}*/
		//cudaProfilerStop();
		t1.stopTimer();
		time_ac[1]=CUDAComputeTimer.getTotalTime();
		//printf("GPU Docking time: %.20f\n",t1.getElapsedTime());
		//printf("|- CUDA Compute time: %.20f\n",CUDATime);
		//printf("|- CPU Compute time: %.20f\n",t1.getElapsedTime() - CUDATime);
	}else{
		ATimer t1;
		t1.startTimer();
		for(iterMol->pos_molecule=startmol; !iterMol->gend_molecule(); iterMol->next_molecule()) {
			//iterMol->pos_molecule=5;
			fprintf(stdout,"frodrug> Lig %5d ", iterMol->pos_molecule);

			drug = (SMol *) iterMol->get_molecule();
			ligand->eraseAll();
			ligand->add(drug);

			// time2.restart();

			if (ligand->num_atoms()>MAX_LIGAND_ATOMS) {
				fprintf(stdout,"Warning %d\n", ligand->num_atoms());
				//      PENDING a realloc if bigger
			}

			//PRECALCULATION OF SPHERICAL REPRESENTATION OF THE LIGAND
			createSH(ligand, in_bw, in_width,&preSH_data );

			if (preSH_data.rho_max>in_limit_max_layer) {
				fprintf(stdout,"\nfrodrug> Warning layer %d %d\n", preSH_data.rho_max, in_limit_max_layer);
				preSH_data.rho_max=in_limit_max_layer;
			}

			time3.restart();
			time_ac[0]=0;
			for(int i=0;i<points->num;i++){
				// Find max radii for the ligand
				float center[3];
				ligand->deleteHYDS();
				ligand->geoCenter(center);
				center[0]*= -1.0;
				center[1]*= -1.0;
				center[2]*= -1.0;
				ligand->moveAll(center);
				float ligMaxR = ligand->maxLength()/2.0f;
				if(dts[i] <= ligMaxR){
					time2.restart();
					points->return_point(i,point);
					memset( integrali, 0, sizeof( float ) * sizeIntegral );
					memset( integralr, 0, sizeof( float ) * sizeIntegral );
					//fprintf(stdout,"Correlation\n");
					for(int j=0;j<num_maps;j++){
						createIntegral_drug(integrali, integralr,rcoeffsV[j][i],icoeffsV[j][i],	in_bw,ind_coef,ind_i_p, ind_i_n,&preSH_data,eval[j],j);
					}
					//strcpy(t1,time2.print_time());
					//fprintf(stdout,"Correlation\n");
					//time2.restart();
					//int sizeCoeff = ((((in_bw-1)*(4*(in_bw-1)*(in_bw-1)-1)/3+(in_bw-1)*(in_bw-1))/2)+(in_bw-1)*(2*(in_bw-1)+1))+(in_bw-1)+(in_bw-1)+1;
					//float* data = dockingCUDA(in_bw,vld->ddd,points->num,rcoeffsV,icoeffsV,eval,in_limit_max_layer, iterMol, startmol);
					//compareFloatData(integralr,data,sizeCoeff,0.1f)==0? cout<< "OK\n":cout << "ERROR\n";

					fourier_corr( in_bw, integralr, integrali, vld, coef_corr );
					//strcpy(t2,time2.print_time());
					//time2.restart();
					fftwf_execute( plan );
					//strcpy(t3,time2.print_time());
					//fprintf(stdout,"Introduction of solutions\n");
					//time2.restart();
					solutions->insert(coef_corr,point);
					//dockingCUDA(in_bw,vld->ddd,points->num,rcoeffsV,icoeffsV,eval,in_limit_max_layer, iterMol, startmol);
					//sprintf(stdout,"Solution %f \n",solutions.best_solutions_found[0]);
					//strcpy(t4,time2.print_time());
					time_ac[0]+=time2.elapsed();
					//fprintf(stdout,"Tiempo por punto: %s\n",time2.print_time());
				}
			}

			solutions->write_solutions_frodrug((iterMol->pos_molecule-startmol), soutputP);
			//cout << "Best corr: " << soutputP[0] << " psi: " << soutputP[1]*M_PI/180 << " th: " << soutputP[2]*M_PI/180 << " phi: " << soutputP[3]*M_PI/180 << endl << flush;
			//
			// Dsx
			//
			float sin_psi;
			float cos_psi;
			float sin_theta;
			float cos_theta;
			float sin_phi;
			float cos_phi;
			float matrix[3][3],dist,buffer[3];;
			float coor_atomL_origen[3];

			int solm;
			float dist_score;
			int int_dist_score, par_lig, par_prot, tipo_final ;
			float dsx_score=0,  dsx_min=9999, Lx, Ly, Lz;
			dsx_score=0;
			for (int h=0; h<explored_peaks; h++){
				dsx_score=0;
				solm=h*9;
				buffer[0]=soutputP[solm+1]*3.1415297/180.0;
				buffer[1]=soutputP[solm+2]*3.1415297/180.0;
				buffer[2]=soutputP[solm+3]*3.1415297/180.0;

				sin_psi = sin(buffer[0]);
				cos_psi = cos(buffer[0]);
				sin_theta= sin(buffer[1]);
				cos_theta= cos(buffer[1]);
				sin_phi=sin(buffer[2]);
				cos_phi=cos(buffer[2]);

				matrix[0][0]= cos_psi*cos_phi - cos_theta*sin_phi*sin_psi;
				matrix[0][1]= cos_psi*sin_phi + cos_theta*cos_phi*sin_psi;
				matrix[0][2]= sin_psi*sin_theta;
				matrix[1][0]= -sin_psi*cos_phi - cos_theta*sin_phi*cos_psi;
				matrix[1][1]= -sin_psi*sin_phi + cos_theta*cos_phi*cos_psi;
				matrix[1][2]= cos_psi*sin_theta;
				matrix[2][0]= sin_theta*sin_phi;
				matrix[2][1]= -sin_theta*cos_phi;
				matrix[2][2]= cos_theta;

				float testCount=0.0f;
				for (int i=0; i<preSH_data.num_atoms; i++) { // ligando

					coor_atomL_origen[0]=preSH_data.posx[i];
					coor_atomL_origen[1]=preSH_data.posy[i];
					coor_atomL_origen[2]=preSH_data.posz[i];

					// rotation
					Lx= coor_atomL_origen[0]*matrix[0][0] + coor_atomL_origen[1]*matrix[0][1] + coor_atomL_origen[2]*matrix[0][2];
					Ly= coor_atomL_origen[0]*matrix[1][0] + coor_atomL_origen[1]*matrix[1][1] + coor_atomL_origen[2]*matrix[1][2];
					Lz= coor_atomL_origen[0]*matrix[2][0] + coor_atomL_origen[1]*matrix[2][1] + coor_atomL_origen[2]*matrix[2][2];

					// translation
					Lx+=soutputP[solm+4];
					Ly+=soutputP[solm+5];
					Lz+=soutputP[solm+6];

					par_lig=preSH_data.dsx[i];
					//			    fprintf(stderr, "%d o %f %f %f L %f %f %f  T %d\n",  i, 	Lx, Ly, Lz,
					//			                                                        coor_atomP[3*j+0], 	coor_atomP[3*j+1], coor_atomP[3*j+2],
					//			                                                        par_lig
					//			                                                        );
					////			    getchar();
					if ( par_lig!=66 )
						for (int j=0; j<N_coor_atomP; j++){
							dist=    ( ((Lx-coor_atomP[3*j+0])*(Lx-coor_atomP[3*j+0]))
								+((Ly-coor_atomP[3*j+1])*(Ly-coor_atomP[3*j+1]))
								+((Lz-coor_atomP[3*j+2])*(Lz-coor_atomP[3*j+2])) );

							if (dist<=36){
								dist_score=sqrt(dist)*100;
								int_dist_score=(int)dist_score;
								par_prot=tipo_atomP[j];
								//        				fprintf(stderr, "%d(%d,%d)[%d]-t=%d",i,j, par_prot,int_dist_score,tipo[par_lig][par_prot]);
								tipo_final=tipo[par_lig][par_prot];

								if ( tipo_final!=66 ){

									//        				 fprintf(stderr, "%d P %d L %d  o %f %f %f L %f %f %f P %f %f %f   D -> dist %f - %d %d--> %f\n", h, j, i, original_center[0], original_center[1], original_center[2],
									//        					    					        				                                       		Lx, Ly, Lz,
									//        					     					        				                                       		coor_atomP[3*j+0], 	coor_atomP[3*j+1], coor_atomP[3*j+2], dist_score
									//        					      					        				                                       		, preSH_data.dsx[i], tipo_atomP[j], dsx_score
									//        					      					        				                                       );
									//
									//
									//
									//
									testCount++;
									float thisAtom = score[tipo_final][(int_dist_score+1)]+(dist_score-(int_dist_score+1))*( (score[tipo_final][(int_dist_score+1)]-score[tipo_final][int_dist_score]));
									//float minPair = score[tipo_final][0];
									//float maxPair = score[tipo_final][0];
									//for(int i=1;i<601;i++){
									//	if(score[tipo_final][i]<minPair){
									//		minPair = score[tipo_final][i];
									//	}
									//	if(score[tipo_final][i]>maxPair){
									//		maxPair = score[tipo_final][i];
									//	}
									//}
									//maxPair += abs(minPair);
									//minPair += abs(minPair);
									/*thisAtom += abs(minPair);
									thisAtom /= maxPair;*/
									/*if(thisAtom<0.0f){
										thisAtom/=abs(minPair);
									}else{
										thisAtom/=maxPair;
									}*/
									dsx_score+= thisAtom;

								}

							}
						}
						// fprintf(stderr, " lig_num  %d score %f %f\n", h+1, dsx_score, soutput[(iterMol->pos_molecule-1)*8+7]); getchar();
				}
				dsx_score /= testCount;
				soutputP[solm+8]=dsx_score;

				if(dsx_score<dsx_min){
					dsx_min=dsx_score;
				}
				// fprintf(stdout," sol %d FRM-> %f  dsx %f\n",h, soutputP[solm], soutputP[solm+8]);
				// getchar();

			}

			time_ac[1]+=time_ac[0];

			if(num_molecs== 1) {
				fprintf(stdout," %.2f Avg %.5f Rm %2d N %3d-> %6.2f dsx %6.2f min %6.2f\n",time_ac[0],time_ac[0]/points->num,preSH_data.rho_max, preSH_data.num_atoms, soutputP[0], soutputP[8], dsx_min);
				// solutions->write_solutions(in_output);
			} else {
				// solutions->write_solutions_frodrug(iterMol->pos_molecule, output);
				fprintf(stdout," %.2f Avg %.5f Rm %2d N %3d-> %6.2f dsx %6.2f min %6.6f\n",time_ac[0],time_ac[0]/points->num,preSH_data.rho_max, preSH_data.num_atoms,soutputP[0], soutputP[8], dsx_min);
			}
			int solh, solk;
			float soltemp;
			// ** sort by dsx
			for (int h=0; h<explored_peaks; h++){
				for (int k=h+1; k<explored_peaks; k++) {
					solh=h*9;  solk=k*9;
					if (soutputP[solk+8]<soutputP[solh+8]) {
						for (int i=0; i<9; i++) {
							soltemp=soutputP[solh+i];
							soutputP[solh+i]=soutputP[solk+i];
							soutputP[solk+i]=soltemp;
						}

					}
				}
			}

			for (int h=0; h<saved_peaks; h++) {
				solh=((iterMol->pos_molecule-startmol)*saved_peaks+h)*9;
				// fprintf(stderr, "%3d ", solh);
				for (int i=0; i<9; i++) {
					soutput[solh+i]=soutputP[h*9+i];
					//fprintf(stderr, " %6.2f ",soutput[solh+i]);
				}
				//fprintf(stderr,"\n");

			}
			//fprintf(stdout," %.2f Avg %.5f Rm %2d N %3d-> %6.2f dsx %6.2f\n",time_ac[0],time_ac[0]/points->num,preSH_data.rho_max, preSH_data.num_atoms,soutputP[0], soutputP[8]);
			//fprintf(stdout," %.2f Avg %.5f Rm %2d N %3d-> %6.2f dsx %6.2f min %6.2f\n",time_ac[0],time_ac[0]/points->num,preSH_data.rho_max, preSH_data.num_atoms,soutputP[0], soutputP[8], dsx_min);
			solutions->clear_solutions();

		} // end ligands
		t1.stopTimer();
		//printf("CPU Docking time: %.20f\n",t1.getElapsedTime());
	}
#endif
	fprintf(stdout,"frodrug>\nfrodrug> Docking %5d %.2f Avg %.2f pp %.5f\n",num_molecs-startmol, time_ac[1], time_ac[1]/(num_molecs-startmol),  time_ac[1]/((num_molecs-startmol)*points->num));

	fprintf(stdout,"frodrug> Saving solutions %s \nfrodrug> Completed in %s\nfrodrug>\n",in_output, time.print_time_sec());

	// saving solutions
	FILE *fsolu;
	fsolu=fopen(in_output,"wb");
	if (fsolu==NULL) {
		fprintf(stdout," error saving %s\n", in_output);
	}
	fwrite(&totalPeaks,  sizeof(int),  1, fsolu);
	fwrite(soutput,sizeof(float),totalPeaks*9,fsolu);
	fclose(fsolu);

	//free (soutput);
	free(TCOS);
	free(TSIN);
#ifdef MPI_RELEASE
	MPI_Finalize();
#endif
	cudaDeviceSynchronize();
	cudaDeviceReset();
	return 0;
}
