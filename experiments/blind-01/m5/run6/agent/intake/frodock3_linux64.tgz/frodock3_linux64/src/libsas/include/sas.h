#ifndef SAS_H
#define SAS_H

///Number of spheres. Global for being used by all functions
static int ns;

/// ASA space
namespace ASA
{

/**
 *  Water radius type. Useless.
 *  It is used always VOLD (The same water radius for all the atoms)
 */
enum VP_type {VP1,VP2,VP3,VOLD};

/**
 * SAS structure. Represents a Macromolecular system to compute atom SAS
 */
typedef struct{
		double **spheres;
    int *index_start;
    int *neighbors_number;
    int *neighbors_indices;
    double **sphere_local;
    int *ind;
    double **arcs;
    double **circles;
    double **arcsnew;
    double *angles;
    int narcs;
}SAS_t;

/**
 * Water radius convention structure for polar, apolar and carboxyl. Useless, all atoms have the same radius
 */
typedef  struct  {
	float rpolar;
	float rapolar;
	float rcarboxyl;
	float rdefault;
}  Atom_vp;


/**
 * Colecction of water radius conventions. Useless, always used type 0 (radius read by argument)
 */
extern Atom_vp atom_vpn[4];


/**
 * Frees a SAS structure
 *
 * @param sas: SAS structure to free
 */
void eraseSAS(SAS_t *sas);

/**
 * Allocates and initializes a SAS structure for a Macromolecular structure
 * It must be called before localSAS
 *
 *@param iter: Macromolecular iterator. Provides access to the Macromolecular structure to model
 *@param sas: pointer to SAS structure to alloc
 *@param in_wradprobe: Water radius to use (This radius will use for all the atoms)
 *@param option_VP: Fixes the water radius convention employed. ATENTION: It is always used convention VOLD (0).
 */
void preSAS(pdbIter *iter ,SAS_t *sas,float in_wradprobe, VP_type option_VP=VP1);
/**
 * Computes the ASA of a system modeled in a ASA structured
 * The occupancy columns of each atom in the Macromolecular system are modified to store its ASA
 * It must be called after preSAS
 *
 *@param Macromolecular iterator. Provides access to the Macromolecular structure modeled
 *@param num: Number of atoms in Macromolecular structure
 *@param sas: SAS structure
 *@param prove: Checks if last atom (prove) is too close to another atom. NEVER USED
 *@return The complete ASA of all the system
 */
float localSAS(pdbIter *iter,int num,SAS_t sas, bool prove=false);

/*  nuevo Pablo calculo 2017
 *
 */
float calcSAS(int num, SAS_t sas, float *sasa);


float localSAS(int start, int end, SAS_t sas, float *sasa, bool prove=false);

/**
 * Computes variance in ASA (SAS) produced in an atom for a probe set in different regions around the atom
 *
 *@param atom_pos: atom position in the SAS structure
 *@param num: Number of valid positions for the probe around the atom (should be precomputed)
 *@param sas: SAS structure
 *@param validpos: List of valid  positions of the probe around the atom (should be precomputed. It is a colletion of triplets. The positions are computed in a volume coordinates)
 *@param values: List of SAS values for each poosition of the probe around the atom (It is computed in the function)
 *@param ox,oy,oz: Origin of the volume employed to compute valid positions
 *@param gridsize: size (in amstrongs) of the voxels of the volume employed to compute valid positions
 */
float localSAS_3(int atom_pos,int num,SAS_t sas, int *validpos, float *values, float ox,float oy, float oz, float gridsize);

}
#endif
