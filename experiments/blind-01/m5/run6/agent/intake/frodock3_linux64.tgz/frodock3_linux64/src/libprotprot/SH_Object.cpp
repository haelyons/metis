#include "SH_Object.h"

#include <libbessel/include/bessels.h>
#include <libpdb/include/pdbIter.h>

extern void cart2sph(float *rad,float *theta,float *lambda,float posx,float posy,float posz,
              float cx,float cy,float cz);

void precomputation(Macromolecule *mol,float **SH_layerr,float **SH_layeri,float *radius,float steprho,int rmax,int bw,int opt,float *associatedC);


/**
 * ELECTRONIC WEIGHT
 * Computation of the spherical harmonics coefficients from the electronic weight of a pdb.
 * The coefficients are computed by layers, grouping atoms in the layers.
 *
 *@param mol: Macromolecule that is represented
 *@param SH_layerr: Output. Real part of the spherical harmonic coefficients computed
 *@param SH_layeri: Output. imaginary part of the spherical harmonic coefficients computed
 *@param radius: Output. Average distance of all the layers (computed from all the atoms that are in the layer)
 *@param steprho: Distance between layers
 *@param rmax: Maximum nuimber of layers
 *@param bw: Grade of the spherical harmonic base
 *@param opt: option (0: all atoms but hydrogens, 1: Hydrogens, 2: heavy atoms)
 *@param associatedC: Precomputed d coefficients
 *
 */
void precomputation(Macromolecule *mol,float **SH_layerr,float **SH_layeri,float *radius,float steprho,int rmax,int bw,int opt,float *associatedC)
{
  int l,n,init,layer,cont_iter;
  float sol[2];
  Tcoor pos;
  Atom*at;
  Element *e;

  float rho,theta,lambda;
  int *num_atoms;
  bool cond=false;
  pdbIter *iter[2];
  float mul[2];

  num_atoms=(int*)malloc(sizeof(int)*rmax);
  memset(num_atoms,0,sizeof(int)*rmax);
  memset(radius,0,sizeof(float)*rmax);

  for(l=0;l<rmax;l++)
  {
    memset(SH_layerr[l],0,sizeof(float)*(bw*bw+bw)/2);
    memset(SH_layeri[l],0,sizeof(float)*(bw*bw+bw)/2);
  }

	//Separation of backbone and lateral chains
	Macromolecule *mol1,*mol2;

	Conditions *conds= new Conditions();
	  Condition *condition= new Condition(-1,-1,-1,-1,-1,-1,-1,-1,-1,-1);
  	condition->add(" C  ");
  	condition->add(" CA ");
  	condition->add(" N  ");
  	condition->add(" O  ");
  	condition->add(" CB ");
  	condition->add(" HA ");
  	condition->add(" H  ");
  	conds->add(condition);

  mol1=mol->select_cpy(conds);
	mol2=mol->select_cpy(conds, false);

  iter[0]=new pdbIter(mol1);
  mul[0]=1;
  iter[1]=new pdbIter(mol2);
	mul[1]=1.0;

  //Checking Atoms
  for(cont_iter=0;cont_iter<2;cont_iter++)
  {
   for(iter[cont_iter]->pos_atom=0;!iter[cont_iter]->gend_atom();iter[cont_iter]->next_atom())
   {
    at=iter[cont_iter]->get_atom();
    e=at->getElement();
    switch(opt)
    {
      case 0:
        //if(e->symbol==C || e->symbol==N || e->symbol==O)
        //if(e->symbol==C)
        if(e->symbol!=H )
          cond=true;
        else
          cond=false;
        break;

      case 1:
        if(e->symbol==H)
          cond=true;
        else
          cond=false;
        break;

      case 2:
        if(e->symbol!=C && e->symbol!=N && e->symbol!=O && e->symbol!=H)
          cond=true;
        else
          cond=false;
        break;
      default:
    	 break;
    }


    if(cond)
    {
      at->getPosition(pos);
      cart2sph(&rho,&theta,&lambda,pos[0],pos[1],pos[2],0,0,0);

      layer=(int)floor(rho/steprho);
			if(layer>=rmax)
      {
		//none
      }
      else
      {
		radius[layer]+=rho;
       	num_atoms[layer]++;
		init=0;

      	for(l=0;l<bw;l++){
        	init+=l;
        	for(n=0;n<=l;n++){
         		computeSH(l,n, theta, lambda, sol,associatedC);
 	         	SH_layerr[layer][init+n]+= sol[0]*e->weight*mul[cont_iter];
 	         	SH_layeri[layer][init+n]+= sol[1]*e->weight*mul[cont_iter];
        	}
       	}
      }

    }
   }
  }



  for(l=0;l<rmax;l++)
    if(num_atoms[l]!=0)
    {
      radius[l]=(radius[l]/(float)num_atoms[l]);
    }
  free(num_atoms);
  delete iter[0];
  delete iter[1];
  delete mol1;
  delete mol2;
  delete conds;
}

/**
 * ACCESIBILITY
 * Computation of the spherical harmonics coefficients from the accessibility of a pdb.
 * The coefficients are computed by layers, grouping atoms in the layers.
 *
 *@param mol: Macromolecule that is represented
 *@param SH_layerr: Output. Real part of the spherical harmonic coefficients computed
 *@param SH_layeri: Output. imaginary part of the spherical harmonic coefficients computed
 *@param radius: Output. Average distance of all the layers (computed from all the atoms that are in the layer)
 *@param steprho: Distance between layers
 *@param rmax: Maximum number of layers
 *@param bw: Grade of the spherical harmonic base
 *@param associatedC: Precomputed d coefficients
 *
 */
void precomputationS(Macromolecule *mol,float **SH_layerr,float **SH_layeri,float *radius,float steprho,int rmax,int bw,float *associatedC)
{
  int l,n,init,layer,cont_iter;
  float sol[2];
  Tcoor pos;
  Atom*at;
  Element *e;
  float rho,theta,lambda;
  int *num_atoms;

  pdbIter *iter[2];

  num_atoms=(int*)malloc(sizeof(int)*rmax);
  memset(num_atoms,0,sizeof(int)*rmax);
  memset(radius,0,sizeof(float)*rmax);

  for(l=0;l<rmax;l++)
  {
    memset(SH_layerr[l],0,sizeof(float)*(bw*bw+bw)/2);
    memset(SH_layeri[l],0,sizeof(float)*(bw*bw+bw)/2);
  }

	//Separacion back de cadenas laterales
	Macromolecule *mol1,*mol2;

	Conditions *conds= new Conditions();
	Condition *condition= new Condition(-1,-1,-1,-1,-1,-1,-1,-1,-1,-1);
  	condition->add(" C  ");
  	condition->add(" CA ");
  	condition->add(" N  ");
  	condition->add(" O  ");
  	condition->add(" CB ");
  	condition->add(" HA ");
  	condition->add(" H  ");
  	conds->add(condition);

  	mol1=mol->select_cpy(conds);
	mol2=mol->select_cpy(conds, false);

	iter[0]=new pdbIter(mol1);
	iter[1]=new pdbIter(mol2);
  //Atoms
  for(cont_iter=0;cont_iter<2;cont_iter++)
  {
   for(iter[cont_iter]->pos_atom=0;!iter[cont_iter]->gend_atom();iter[cont_iter]->next_atom())
   {
    at=iter[cont_iter]->get_atom();
    e=at->getElement();
    //fprintf(stderr,"%s %f\n",at->getName(),at->getPdbocc());
    if(e->symbol!=H )
    {
      at->getPosition(pos);
      cart2sph(&rho,&theta,&lambda,pos[0],pos[1],pos[2],0,0,0);
      layer=(int)floor(rho/steprho);
      if(layer>=rmax)
      {
    	  //none
      }
       else
       {
       	radius[layer]+=rho;
        num_atoms[layer]++;
		init=0;

	      for(l=0;l<bw;l++){
  	      init+=l;
    	  for(n=0;n<=l;n++){
      	   computeSH(l,n, theta, lambda, sol,associatedC);
      	   SH_layerr[layer][init+n]+= sol[0]*at->getPdbocc()/100.0;
           SH_layeri[layer][init+n]+= sol[1]*at->getPdbocc()/100.0;
          }
        }
       }

    }
   }
  }




  for(l=0;l<rmax;l++)
    if(num_atoms[l]!=0)
    {
      radius[l]=(radius[l]/(float)num_atoms[l]);
    }
  free(num_atoms);
  delete iter[0];
  delete iter[1];
  delete mol1;
  delete mol2;
  delete conds;
}

/**
 * MAP PROPERTY (charge, solvatation potential)
 * Computation of the spherical harmonics coefficients from a map which a projection of a property (charge, solvatation potential).
 * The coefficients are computed by layers, grouping atoms in the layers.
 *
 *@param mol: Macromolecule that is represented
 *@param SH_layerr: Output. Real part of the spherical harmonic coefficients computed
 *@param SH_layeri: Output. imaginary part of the spherical harmonic coefficients computed
 *@param radius: Output. Average distance of all the layers (computed from all the atoms that are in the layer)
 *@param steprho: Distance between layers
 *@param rmax: Maximum nuimber of layers
 *@param bw: Grade of the spherical harmonic base
 *@param associatedC: Precomputed d coefficients
 *
 */
void precomputationS_2(vlVolume *vol,float **SH_layerr,float **SH_layeri,float *radius,float steprho,int rmax,int bw,float *associatedC)
{
  int x,y,z,l,n,init,layer;
  float sol[2];
  vlPoint3ui pos;
  float center[3];
  float rho,theta,lambda;
  float value;
  int *num_voxels;

	float *mass=(float*)malloc(sizeof(float)*rmax);
  memset(mass,0,sizeof(float)*rmax);

  num_voxels=(int*)malloc(sizeof(int)*rmax);
  memset(num_voxels,0,sizeof(int)*rmax);
  memset(radius,0,sizeof(float)*rmax);

  for(l=0;l<rmax;l++)
  {
    memset(SH_layerr[l],0,sizeof(float)*(bw*bw+bw)/2);
    memset(SH_layeri[l],0,sizeof(float)*(bw*bw+bw)/2);
  }


	//Estos es igual que llamar a FOPS::center_vol
	center[0]=vol->dim().x()/2.0-0.5;
	center[1]=vol->dim().y()/2.0-0.5;
	center[2]=vol->dim().z()/2.0-0.5;

	vlPoint3f origin_receptor;
	vol->getPosition(& origin_receptor);

	for(x=0;x<vol->dim().x();x++)
	{
		pos.x(x);
		for(y=0;y<vol->dim().y();y++)
		{
			pos.y(y);
			for(z=0;z<vol->dim().z();z++)
			{
				pos.z(z);

				vol->getVoxel(pos,value);

				if(value!=0.0)
				{
					cart2sph(&rho,&theta,&lambda,pos.x(),pos.y(),pos.z(),center[0],center[1],center[2]);

					layer=(int)floor(rho/steprho);
					if(layer>=rmax)
					{
						//none
					}
					else
					{
						radius[layer]+=rho;
						num_voxels[layer]++;
						mass[layer]+=value;

						init=0;
						for(l=0;l<bw;l++){
							init+=l;
							for(n=0;n<=l;n++){
								computeSH(l,n, theta, lambda, sol,associatedC);
								SH_layerr[layer][init+n]+= sol[0]* value * -1.0;
								SH_layeri[layer][init+n]+= sol[1]* value * -1.0;
							}
						}
					}
				}
			}
		}
	}

int contkk=0;
float contkk2=0;
  for(l=0;l<rmax;l++)
    if(num_voxels[l]!=0)
    {
      radius[l]=(radius[l]/(float)num_voxels[l]);

      //printf("radius[%d]=%f num_vox=%d mass=%f\n",l,radius[l],num_voxels[l],mass[l]);
    	contkk+=num_voxels[l];
    	contkk2+=mass[l];
    }
    //printf("Num_vox_total=%d masa_total=%f\n",contkk,contkk2);
  free(num_voxels);


}


/**
 * CHARGE
 * Computation of the spherical harmonics coefficients from the charge of a pdb.
 * The coefficients are computed by layers, grouping atoms in the layers.
 *
 *@param mol: Macromolecule that is represented
 *@param SH_layerr: Output. Real part of the spherical harmonic coefficients computed
 *@param SH_layeri: Output. imaginary part of the spherical harmonic coefficients computed
 *@param radius: Output. Average distance of all the layers (computed from all the atoms that are in the layer)
 *@param steprho: Distance between layers
 *@param rmax: Maximum nuimber of layers
 *@param bw: Grade of the spherical harmonic base
 *@param opt: option (0: all atoms but hydrogens, 1: Hydrogens, 2: heavy atoms)
 *@param associatedC: Precomputed d coefficients
 *
 */
void precomputationE(Macromolecule *mol,float **SH_layerr,float **SH_layeri,float *radius,float steprho,int rmax,int bw,float *associatedC)
{
  int l,n,i,init,layer;
  float sol[2];
  Tcoor pos;
  Atom*at;
  Element *e;
  PDB_Container *fath;
  float rho,theta,lambda;
  int *num_atoms;
  int aminoacid,atom;
  char name[5];
  float charge;
  bool error=false;
  //float total_charge;
  //int cont=0;

  num_atoms=(int*)malloc(sizeof(int)*rmax);
  memset(num_atoms,0,sizeof(int)*rmax);
  memset(radius,0,sizeof(float)*rmax);

  for(l=0;l<rmax;l++)
  {
    memset(SH_layerr[l],0,sizeof(float)*(bw*bw+bw)/2);
    memset(SH_layeri[l],0,sizeof(float)*(bw*bw+bw)/2);
  }

  //fprintf(stderr,"Nº de atomos:%d\n",mol->get_num_atoms());
  mol->initAll();
  if(mol->get_num_atoms()>0)
  do
  {
	  error=false;
	  at = (Atom*) mol->getCurrentAtom();
	  e=at->getElement();
	  fath=(PDB_Container*)at->getFather();

	  if( (e->symbol!=H) && fath->getClass()!= pdb_smol)
	  {
		  if(fath->getClass()==pdb_residue || fath->getClass()==pdb_nucleotide)
		  {
			  for(i=0;i<N_AMINO;i++)
			  {
				  if(strcmp(fath->getName(),AA[i].aa_name3)==0)
				  {
					  aminoacid=i;
					  //printf("%s en %s\n",res->getName(),AA[i].aa_name3);
					  i=N_AMINO+10;
				  }
			  }
			  if(i==N_AMINO+1)
			  {
				  error=true;
				  printf("Error: Fragment not identified: %s\n",fath->getName());
			  }
			  else
			  {
				  strcpy(name,at->getName());
				  name[4]='\0';

				  for(i=0;i<AA[aminoacid].natoms;i++)
				  {
					  if(strcmp(name,AA[aminoacid].atom[i].atom_name)==0)
					  {
						  atom=i;
						  charge=AA[aminoacid].atom[atom].charge;
						  //printf("%s en %s Numero=%d\n",name,AA[aminoacid].atom[i].atom_name,i);
						  i=1000;
					  }
				  }
				  if(i!=1001)
				  {
					  //printf("Error: Atom not identified: %s\n",at->getName());
					  error=true;
					  charge=0;
				  }
			  }
		  }
		  else
		  {
			  error=true;
			  charge=0;
		  }


		  if(!error && charge!=0)
		  {
			  //total_charge+=charge;
			  //fprintf(stderr,"RES=%s Atom=%s charge=%f %f  %d\n",AA[aminoacid].aa_name3,AA[aminoacid].atom[atom].atom_name,charge,total_charge,cont);
			  //cont++;

			  at->getPosition(pos);
			  cart2sph(&rho,&theta,&lambda,pos[0],pos[1],pos[2],0,0,0);
			  layer=(int)floor(rho/steprho);
			  if(layer>=rmax)
			  {
				  //none
			  }
			  else
			  {
				  radius[layer]+=rho;
				  num_atoms[layer]++;
				  init=0;
				  for(l=0;l<bw;l++)
				  {
					  init+=l;
					  for(n=0;n<=l;n++)
					  {
						  computeSH(l,n, theta, lambda, sol,associatedC);
						  SH_layerr[layer][init+n]+= sol[0]*charge;
						  SH_layeri[layer][init+n]+= sol[1]*charge;
	                  		//printf("%d %d %f %f\n",layer,init+n,SH_layerr[layer][init+n],SH_layeri[layer][init+n]);

					  }
				  }
			  }
		  }
	  }
  }
  while(mol->nextAtom());



  for(l=0;l<rmax;l++)
  if(num_atoms[l]!=0)
  {
      radius[l]=(radius[l]/(float)num_atoms[l]);
  }
  free(num_atoms);
}

void precomputationP(Macromolecule *mol,float **SH_layerr,float **SH_layeri,float *radius,float steprho,int rmax,int bw,float *associatedC, int type)
{
  int l,n,i,init,layer;
  float sol[2];
  Tcoor pos;
  Atom*at;
  Element *e;
  PDB_Container *fath;
  float rho,theta,lambda;
  int *num_atoms;
  int aminoacid;
  char name[5];
  bool type_found,atom_found;
  int atom_type;

  //float total_charge;
  //int cont=0;

  num_atoms=(int*)malloc(sizeof(int)*rmax);
  memset(num_atoms,0,sizeof(int)*rmax);
  memset(radius,0,sizeof(float)*rmax);




  for(l=0;l<rmax;l++)
  {
    memset(SH_layerr[l],0,sizeof(float)*(bw*bw+bw)/2);
    memset(SH_layeri[l],0,sizeof(float)*(bw*bw+bw)/2);
  }

  //fprintf(stderr,"Nº de atomos:%d\n",mol->get_num_atoms());
  mol->initAll();
  if(mol->get_num_atoms()>0)
  do
  {
	  at = (Atom*) mol->getCurrentAtom();
	  e=at->getElement();
	  fath=(PDB_Container*)at->getFather();

	  if( (e->symbol!=H) )
	  {

		  if(fath->getClass()==pdb_nucleotide || fath->getClass()==pdb_residue)
		  {

			for(i=0;i<N_AMINO;i++)
			{
				if(strcmp(fath->getName(),AA[i].aa_name3)==0)
				{
					aminoacid=i;
					//printf("%s en %s\n",res->getName(),AA[i].aa_name3);
					i=N_AMINO+10;
				}
			}
			if(i==N_AMINO+1)
			{
				aminoacid=-1;
				printf("Alert: Aminoacid not found %s. The atoms will be evaluated by its element.\n",fath->getName());
			}
		  }
		  else
		  {
				aminoacid=-1;
		  }


		  strcpy(name,at->getName());
		  name[4]='\0';
		  atom_found=false;
		  if(aminoacid>=0)
		  {

		   	  for(i=0;i<AA[aminoacid].natoms+3;i++)
		   	  {
		   	  	if(strcmp(name,AA[aminoacid].atom[i].atom_name)==0)
		   	  	{
		   	  		atom_type= AA[aminoacid].atom[i].fullatom_type-1;
		   	  		//fprintf(stderr,"RES=%s Atom=%s charge=%f\n",AA[aminoacid].aa_name3,AA[aminoacid].atom[i].atom_name,charge);
		   	  		atom_found=true;
		   	  		i=1000;
		   	  	}
		   	  }
		   }
		   else
		   {
		   	  atom_found=false;
		   }

		  atom_type+=1;
		  type_found=false;
		  if(atom_found)
		  {
			 if(atom_type==type)
				 type_found=true;
		  }

		  /*if(type_found)
			  value=1.0;
		  else
			  value=0.0;*/
		  //fprintf(stderr,"Residuo: %s Atomo:%s tipo: %d\n", fath->getName(),at->getName(),atom_type);

		  if(type_found)
		  {
			  //fprintf(stderr,"Atomo empleado con potencial, %s %s tipo: %d\n", at->getName(),fath->getName(),type);
			  at->getPosition(pos);
			  cart2sph(&rho,&theta,&lambda,pos[0],pos[1],pos[2],0,0,0);
			  layer=(int)floor(rho/steprho);
			  if(layer>=rmax)
			  {
				  //none
			  }
			  else
			  {
				  radius[layer]+=rho;
				  num_atoms[layer]++;
				  init=0;
				  for(l=0;l<bw;l++)
				  {
					  init+=l;
					  for(n=0;n<=l;n++)
					  {
						  computeSH(l,n, theta, lambda, sol,associatedC);
						  SH_layerr[layer][init+n]+= sol[0];
						  SH_layeri[layer][init+n]+= sol[1];
	                  		//printf("%d %d %f %f\n",layer,init+n,SH_layerr[layer][init+n],SH_layeri[layer][init+n]);

					  }
				  }
			  }
		  }
	  }
  }
  while(mol->nextAtom());



  for(l=0;l<rmax;l++)
  if(num_atoms[l]!=0)
  {
      radius[l]=(radius[l]/(float)num_atoms[l]);
  }
  free(num_atoms);
}


void writeSH(vlVolume *vol,float **SH_layerr,float **SH_layeri,float *radius,float steprho,int rmax,int bw,float *associatedC)
{
  int l,n,init,layer;
  float sol[2];
  Tcoor pos;
  Tcoor pos_orig;
  float rho,theta,lambda;
	float value;
	int x,y,z;



	pos_orig[0]=floor(vol->dim().x()/2.0);
	pos_orig[1]=floor(vol->dim().y()/2.0);
	pos_orig[2]=floor(vol->dim().z()/2.0);



	for(x=0;x<vol->dim().x();x++)
		for(y=0;y<vol->dim().y();y++)
			for(z=0;z<vol->dim().z();z++)
	{
		pos[0]=(x-pos_orig[0])*vol->units().x();
		pos[1]=(y-pos_orig[1])*vol->units().y();
		pos[2]=(z-pos_orig[2])*vol->units().z();

		cart2sph(&rho,&theta,&lambda,pos[0],pos[1],pos[2],0,0,0);
		layer=(int)floor(rho/steprho);

    init=0;
		value=0;

		for(l=0;l<bw;l++){
    	init+=l;
      for(n=0;n<=l;n++){
      	computeSH(l,n, theta, lambda, sol,associatedC);

      if(layer<rmax)
      {
      		value+=((SH_layerr[layer][init+n]*sol[0])+(SH_layeri[layer][init+n]*sol[1]));
      		//value+=(SH_layerr[layer][init+n]*sol[1])+(SH_layeri[layer][init+n]*sol[0]);
      }

			//printf("sol[0]=%f sol[1]=%f value=%f\n",sol[0],sol[1],value);
      }
		}

			vol->setVoxel( vlPoint3ui(x,y,z) ,value);

  }



}





SH_Object::SH_Object(Macromolecule *ligand, int in_bw, int in_radius_max, float in_rho_amstrongs, bool *in_eval,vlVolume *vol_sol,vlVolume *vol_acc,vlVolume *vol_ele,int *extra_type)
{
	int j,i;

	bw=in_bw;
	radius_max=in_radius_max;
	rho_amstrongs=in_rho_amstrongs;
	//Reservas para coeficientes harmonicos
  SH_layerr = ( float * * * ) malloc( NUM_POT * sizeof( float * * ) );
  SH_layeri = ( float * * * ) malloc( NUM_POT * sizeof( float * * ) );
  radius_layer = ( float * * ) malloc( NUM_POT * sizeof( float * ) );

  AssociatedCoef( bw, & associatedC );

	// aa_pdb2pqr();
	//ligand->rename_residues();

  //Calculo de los esfericos harmonicos para cada tipo de energia
  for ( j = 0; j < NUM_POT; j++ )
  {
     eval[j]=false;
     if(in_eval[j])
     {
     	eval[j]=true;
      //Reservas de memoria
      SH_layerr[j] = ( float * * ) malloc( ( int )radius_max * sizeof( float * ) );
      SH_layeri[j] = ( float * * ) malloc( ( int )radius_max * sizeof( float * ) );
      radius_layer[j] = ( float * ) malloc( ( int )radius_max * sizeof( float ) );
      for ( i = 0; i < ( int )radius_max; i++ )
      {
        SH_layerr[j] [i] = ( float * ) malloc( sizeof( float ) * ( bw * bw + bw ) / 2 );
        SH_layeri[j] [i] = ( float * ) malloc( sizeof( float ) * ( bw * bw + bw ) / 2 );
      }
      //Calculo de esfericos harmonicos para las capas que cubren el pdb
      if ( j < 3 )
      {
        precomputation( ligand, SH_layerr[j], SH_layeri[j], radius_layer[j], rho_amstrongs, radius_max,
             bw, j, associatedC );


      }
      else
      if(j==3)
      {
				if(vol_ele==NULL)
        {
        	precomputationE( ligand, SH_layerr[j], SH_layeri[j], radius_layer[j], rho_amstrongs,
             radius_max, in_bw, associatedC );
        }
        else
        {
        	 	precomputationS_2(vol_ele, SH_layerr[j], SH_layeri[j], radius_layer[j], rho_amstrongs,
      								radius_max, in_bw, associatedC);
        }
      }
      if(j==4)
      {
      	if(vol_acc==NULL)
      	{
      		precomputationS( ligand, SH_layerr[j], SH_layeri[j], radius_layer[j], rho_amstrongs,
      								radius_max, in_bw, associatedC );
      	}
      	else
      	{
      		//cambio para doble
      		precomputationS_2(vol_acc, SH_layerr[j], SH_layeri[j], radius_layer[j], rho_amstrongs,
      								radius_max, in_bw, associatedC);
      	}
				//precomputationS_double(vol_acc,vol_sol,SH_layerr[j], SH_layeri[j], radius_layer[j], rho_amstrongs,
      	//							radius_max, in_bw, associatedC);
      }

//cambio para doble
      if(j==5)
      {
      	precomputationS_2(vol_sol, SH_layerr[j], SH_layeri[j], radius_layer[j], rho_amstrongs,
      								radius_max, in_bw, associatedC);
      }

     if(j>5)
     {
    	 //precomputationP( ligand, SH_layerr[j], SH_layeri[j], radius_layer[j], rho_amstrongs, radius_max,
         //      bw, associatedC );
    	 precomputationP( ligand, SH_layerr[j], SH_layeri[j], radius_layer[j], rho_amstrongs, radius_max,
    	              bw, associatedC,extra_type[j-6] );
     }
    }

  }
}

SH_Object::SH_Object()
{
	//Reservas para coeficientes harmonicos
  SH_layerr = NULL;
  SH_layeri = NULL;
  radius_layer = NULL;

}


SH_Object::~SH_Object()
{
	int j,i;

		for(j=0;j<NUM_POT;j++)
		{
		 if(eval[j])
		 {	for ( i = 0; i < radius_max; i++ )
			{
				free(SH_layerr[j] [i]);
				free(SH_layeri[j] [i]);
			}
			free(SH_layerr[j]);
			free(SH_layeri[j]);
			free(radius_layer[j]);
		 }
		}
		free(SH_layerr);
		free(SH_layeri);
		free(radius_layer);
		free(associatedC);
}

float ** SH_Object::return_shr(int i)
{
	return SH_layerr[i];
}
float ** SH_Object::return_shi(int i)
{
	return SH_layeri[i];
}
float * SH_Object::return_sh_Radius(int i)
{
	return radius_layer[i];
}




void SH_Object::write(char *name)
{
	FILE *f;
	int i,j;
	f=fopen(name,"wb");

	fwrite(&bw, sizeof(int),  1, f);
	fwrite(&radius_max, sizeof(int),  1, f);
	fwrite(&rho_amstrongs, sizeof(float),  1, f);
	fwrite(eval,sizeof(bool),NUM_POT,f);
//fprintf(stderr,"WRITE: bw=%d radius_max=%d rho_amstrongs=%f\n",bw, radius_max,rho_amstrongs);
	float aux=( bw * bw + bw ) / 2;

  for(j=0;j<NUM_POT;j++)
  {

  	if (eval[j])
  	{
  	 for(i=0;i<radius_max;i++)
  	 {

  		 fwrite(SH_layerr[j][i], sizeof(float),  aux, f);
  		 fwrite(SH_layeri[j][i], sizeof(float),  aux, f);
  	 }

		 fwrite(radius_layer[j], sizeof(float),  radius_max, f);
  	}
  }

  fwrite(associatedC,sizeof(float),aux,f);
	fclose(f);

}

void SH_Object::read(char *name)
{
	FILE *f;
	int i,j;
	f=fopen(name,"rb");

	fread(&bw, sizeof(int),  1, f);
	fread(&radius_max, sizeof(int),  1, f);
	fread(&rho_amstrongs, sizeof(float),  1, f);
	fread(eval,sizeof(bool),NUM_POT,f);
	float aux=( bw * bw + bw ) / 2;
	SH_layerr = ( float * * * ) malloc( NUM_POT * sizeof( float * * ) );
  SH_layeri = ( float * * * ) malloc( NUM_POT * sizeof( float * * ) );
  radius_layer = ( float * * ) malloc( NUM_POT * sizeof( float * ) );

  for(j=0;j<NUM_POT;j++)
  {
		if(eval[j])
		{
			SH_layerr[j]=( float * * ) malloc( ( int )radius_max * sizeof( float * ) );
			SH_layeri[j]=( float * * ) malloc( ( int )radius_max * sizeof( float * ) );
  		for(i=0;i<radius_max;i++)
  		{
  			SH_layerr[j][i]= (float*)malloc(sizeof(float)*aux);
  			SH_layeri[j][i]= (float*)malloc(sizeof(float)*aux);

  			fread(SH_layerr[j][i], sizeof(float),  aux, f);
  			fread(SH_layeri[j][i], sizeof(float),  aux, f);
  		}

			radius_layer[j]=( float *  ) malloc( ( int )radius_max * sizeof( float ) );
  		fread(radius_layer[j], sizeof(float),  radius_max, f);
		}
  }
  associatedC=(float*)malloc(sizeof(float)*((bw*bw)+bw)/2);
  fread(associatedC,sizeof(float),aux,f);
	fclose(f);


}
