#ifndef _FRODOCKCLUSTER_hpp
#define _FRODOCKCLIUSTER_hpp

#include <libpdb/include/Macromolecule.h>


int calcule_cluster(float *buffer, int npeaksTotal, char *in_pdb,
		  	  	float **output_buffer, float **output_buffer2, int rampi, float rampd,
		  	  	int in_num=-1, int in_numc=-1, float in_limit=5.0, float in_limit2=1.0,bool output2=false,
		  	  	int num_elem=7,bool is_sort=false, bool in_eval=false);



#endif
