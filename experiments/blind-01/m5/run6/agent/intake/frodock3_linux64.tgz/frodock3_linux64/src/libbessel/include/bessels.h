#ifndef BESSEL_H
#define BESSEL_H
//void ShCoeff(Macromolecule *pdb,float r,float *coefr,float *coefi,int bw);
//void ShCoeff(Macromolecule *pdb,float sigma,float r,float *coefr,float *coefi,int bw);
//void ShCoeff(Macromolecule *pdb,float r,float *coefr,float *coefi,int bw,float *charges);
void ShCoeff(Macromolecule *pdb,float sigma,float r,float *coefr,float *coefi,int bw,float *preC);
void ShCoeff(Macromolecule *pdb,float r,float *coefr,float *coefi,int bw,float *preC);
void ShCoeff_gauss(Macromolecule *pdb,float r,float *coefr,float *coefi,int bw,float *preC);

void computeSH(int l, int m,float theta, float lambda, float sol[2],float *coef);
void AssociatedCoef(int bw,float **coef);
float plgndr(int l, int m,float x,float *coef);

void writeSphVol(Macromolecule *pdb,char* name, int bw,int rmax,float width, int cx,int cy,int cz);
float Pmncos(int order,int index,float phi);
float plgndr(int l, int m,float x);
float aLegendre(int l, int m,float x);
double bessel(int l, float x);
#endif
