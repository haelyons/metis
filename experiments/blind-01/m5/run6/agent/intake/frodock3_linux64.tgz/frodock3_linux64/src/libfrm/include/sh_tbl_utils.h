/***************************************************************************
  **************************************************************************

                           S2kit 1.0

          A lite version of Spherical Harmonic Transform Kit

   Peter Kostelec, Dan Rockmore
   {geelong,rockmore}@cs.dartmouth.edu

   Contact: Peter Kostelec
            geelong@cs.dartmouth.edu

   Copyright 2004 Peter Kostelec, Dan Rockmore

   This file is part of S2kit.

   S2kit is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   S2kit is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with S2kit; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

   See the accompanying LICENSE file for details.

  ************************************************************************
  ************************************************************************/



#ifndef _PRIMITIVE_H
#define _PRIMITIVE_H
#define Sphfloat float

extern Sphfloat L2_an( int ,
		     int ) ;

extern Sphfloat L2_cn( int ,
		     int ) ;

extern Sphfloat L2_cn_inv( int ,
			 int ) ;

extern Sphfloat L2_ancn( int ,
		       int ) ;

extern void vec_add( Sphfloat * ,
		     Sphfloat * ,
		     Sphfloat * ,
		     int ) ;

extern void vec_mul( Sphfloat ,
		     Sphfloat * ,
		     Sphfloat * ,
		     int ) ;

extern void vec_pt_mul( Sphfloat * ,
			Sphfloat * ,
			Sphfloat * ,
			int ) ;

extern void ArcCosEvalPts( int ,
			   Sphfloat * ) ;

extern void EvalPts( int ,
		     Sphfloat * ) ;

extern void Pmm_L2( int ,
		    Sphfloat * ,
		    int ,
		    Sphfloat * ) ;

extern void P_eval( int ,
		    Sphfloat * ,
		    Sphfloat * ,
		    Sphfloat * ,
		    Sphfloat * ,
		    int ) ;
#endif /* _PRIMITIVE_H */
