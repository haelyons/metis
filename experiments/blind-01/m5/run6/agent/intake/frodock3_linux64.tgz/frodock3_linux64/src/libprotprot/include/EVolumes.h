#ifndef EVOLUMES_H_
#define EVOLUMES_H_

#ifndef NUM_POT
#define NUM_POT 50
#endif

#include "libvolume/include/floatops.h"
/**
 * Class to store different volume projection of a macromolecule
 */
class EVolumes {
public:
	/// Collection of volumes
	vlVolume * vol_lo[NUM_POT];
	/// Indicates each volume existence
	bool init[NUM_POT];
	// Center of the volumes
	float c_lo_voxel[3];

	/// Constructor
	EVolumes();
	/// Destructor
	~EVolumes();
	/**
	 *  Fills a volume from a file
	 *@param filename: name file
	 *@param vol_id: id of the volume to fill
	 */
	void read_volume(char *filename,int vol_id);
	/**
	 *  Sets a volumr
	 *@param v: input volume
	 *@param vol_id: id of the volume to fill
	 */
	void get_volume(vlVolume *v,int vol_id);

	///computes the center of masses of the volumes
	void compute_center_masses();
	/**
	 * returns the position value in first volume
	 */
	void get_position(vlPoint3f &origin_receptor);
	/// Returns voxel size
	float get_voxSize();
	///Returns maximum radius from first map
	float getMaxRadius();
};

#endif /*EVOLUMES_H_*/
