################################################################################
# Automatically-generated file. Do not edit!
################################################################################

USER_OBJS :=

LIBS := -lvolume -lprotprot -lbessel -lfrm -lpdb -ltools

