#include "Correlation.h"


//Variables globales para el calculo de correlaciones
float * rcoeffs, * icoeffs, * rcoeffs2, * icoeffs2; //Buffers donde se almacenan los coeficientes asociados a los harmonicos
// esfericos para representar los volumenes
float * integralr, * integrali; //buffers donde se almacena la integral del producto entre ambos volumenes
int sizeIntegral;
float * coef_corr; //buffer donde se almacena la correlacion entre dos volumenes
fftwf_plan plan; //plan para realizar la transformada inversa de la matriz de correlaciones
//Precalculacion de correlacion
twoFloat * integralAux1;
int * t_ind2, * t_index;
//Normalizacion de correlaciones
float norm_hi;
vlDCoef * vld;



/* ==================================================================== */

// Mon: This seems unused... remove...
//static int prime( int n, int s )
//{
//    // returns n if it is >=0, or n+s otherwise
//
//    if ( n >= 0 ) return n;
//    return n + s;
//}


/* ==================================================================== */
int compute_corr( int bw,

		//ENTRADAS PARA EL CALCULO DE INTEGRAL
		twoFloat * integralAux1, //Buffer con la aportacion de la integral
		//del volumen en baja resolucion

		vlSpherical * sph_hi, //volumen en alta en coord esfericas

		Sphfloat * rcoeffs, Sphfloat * icoeffs, //buffers donde se alamacenan los coeficientes
		//harmonicos para una determinada capa
		int rmax, //Nº de capas esfericas a tratar de los volumenes
		int * t_ind2, //buffer que indica posiciones a leer de
		//los coeficientes harmonicos
		float norm_lo, //Factor de normalizacion para el volumen en baja
		//resolucion

		//SALIDAS DEL CALCULO DE LA INTEGRAL
		float * integralr, float * integrali, //Buffers donde se calcula la integral
		int sizeIntegral, //tamaño de los buffers de la integral
		int * t_index, //buffer que indica posiciones a escribir en la integral

		//ENTRADAS DEL CALCULO DE CORRELACIONES EN FOURIER
		vlDCoef * vld, //almacen de coeficientes ddd necesarios para
		//el calculo de las correlaciones en Fourier

		//SALIDAS DEL CALCULO DE CORRELACIONES EN FOURIER
		float * coef_corr, //Buffer donde se calculan las correlaciones

		//ENTRADAS PARA EL CALCULO DE LA INVERSA
		fftwf_plan plan, //Plan para calcular la transformada inversa

		//SALIDAS DEL CALCULO DE MEJORES SOLUCIONES
		float * * corr, //Buffer donde se almacenan las mejores soluciones.
		//Actua como salida de la funcion

		float dist_cut, int TotalPeaks, int ii, int jj, int kk, bool sinInterp )
{
	float norm_hi, tempr, tempj, norm_fact, integralAux2[2];
	int num_iAux1, num_ind2, num_index, sig;
	int l, i, j, tl;
	int index, ind2, r2, npeaks=0;

	memset( integralr, 0, sizeof( float ) * sizeIntegral );
	memset( integrali, 0, sizeof( float ) * sizeIntegral );

	//Para cada capa calculo de la aportacion de los coeficientes harmonicos a
	//la integral
	//CREACION DE LA INTEGRAL IMMP
	num_iAux1 = 0, num_ind2 = 0, num_index = 0;
	tempr = 0;
	for ( int contr = 1; contr < rmax; contr++ )
	{
		sph_hi->sphCoef( contr, rcoeffs, icoeffs );
		r2 = contr * contr;
		tempj = 0;
		for ( l = 0, tl = 0; l < bw; l++, tl += 2 )
		{
			// Para i=l
					i=l;
			index = t_index[num_index++];
			ind2 = t_ind2[num_ind2++]; // i-l=m
			tempj += (( rcoeffs[ind2]*rcoeffs[ind2] ) + ( icoeffs[ind2]*icoeffs[ind2] ) );
			sig = -1;
			// para j=l
			ind2 = t_ind2[num_ind2++]; // j-l=m'
			integralAux2[0] = rcoeffs[ind2];
			integralAux2[1] = icoeffs[ind2];
			* ( integralr + index) +=
					( float )( integralAux1[num_iAux1] [0] * integralAux2[0] + integralAux1[num_iAux1] [1] * integralAux2[1] );
			* ( integrali + index) +=
					( float )( integralAux2[0] * integralAux1[num_iAux1] [1] - integralAux2[1] * integralAux1[num_iAux1] [0] );
			// Para j!=l
					for ( j = 1; j <= l; j++ )
					{
						ind2 = t_ind2[num_ind2++]; // j-l=m'
						integralAux2[0] = rcoeffs[ind2];
						integralAux2[1] = icoeffs[ind2];
						* ( integralr + index + j ) +=
								( float )( integralAux1[num_iAux1] [0] * integralAux2[0] + integralAux1[num_iAux1] [1] * integralAux2[1] );
						* ( integrali + index + j ) +=
								( float )( integralAux2[0] * integralAux1[num_iAux1] [1] - integralAux2[1] * integralAux1[num_iAux1] [0] );

						integralAux2[0] *= sig;
						integralAux2[1] *= -sig;
						sig *= -1;
						* ( integralr + index -  j  ) +=
								( float )( integralAux1[num_iAux1] [0] * integralAux2[0]
																					  + integralAux1[num_iAux1] [1] * integralAux2[1] );
						* ( integrali + index -  j  ) +=
								( float )( integralAux2[0] * integralAux1[num_iAux1] [1] - integralAux2[1]
																										* integralAux1[num_iAux1] [0] );
					} //for
					num_iAux1++;
					// para i!=l
					for ( i = l+1; i <= tl; i++ )
					{
						index = t_index[num_index++];
						ind2 = t_ind2[num_ind2++]; // i-l=m
						tempj += 2.0 * (( rcoeffs[ind2]*rcoeffs[ind2] ) + ( icoeffs[ind2]*icoeffs[ind2] ) );
						sig = -1;
						//para j=l
						ind2 = t_ind2[num_ind2++]; // j-l=m'
						integralAux2[0] = rcoeffs[ind2];
						integralAux2[1] = icoeffs[ind2];
						* ( integralr + index ) +=
								( float )( integralAux1[num_iAux1] [0] * integralAux2[0] + integralAux1[num_iAux1] [1] * integralAux2[1] );
						* ( integrali + index ) +=
								( float )( integralAux2[0] * integralAux1[num_iAux1] [1] - integralAux2[1] * integralAux1[num_iAux1] [0] );
						// para j!=l
								for ( j = 1; j <= l; j++ )
								{
									ind2 = t_ind2[num_ind2++]; // j-l=m'
									integralAux2[0] = rcoeffs[ind2];
									integralAux2[1] = icoeffs[ind2];
									* ( integralr + index +  j   ) +=
											( float )( integralAux1[num_iAux1] [0] * integralAux2[0] + integralAux1[num_iAux1] [1] * integralAux2[1] );
									* ( integrali + index +  j   ) +=
											( float )( integralAux2[0] * integralAux1[num_iAux1] [1] - integralAux2[1] * integralAux1[num_iAux1] [0] );

									integralAux2[0] *= sig;
									integralAux2[1] *= -sig;
									sig *= -1;
									* ( integralr + index - ( j ) ) +=
											( float )( integralAux1[num_iAux1] [0] * integralAux2[0]
																								  + integralAux1[num_iAux1] [1] * integralAux2[1] );
									* ( integrali + index - ( j  ) ) +=
											( float )( integralAux2[0] * integralAux1[num_iAux1] [1] - integralAux2[1]
																													* integralAux1[num_iAux1] [0] );

								} //for
								num_iAux1++;
					} //for i
		} //for l
		tempr += tempj * r2;
	} //for contr

	norm_hi = sqrt( tempr );
	norm_fact = norm_hi * norm_lo;
	if ( norm_fact == 0 )
		return 0;

	//FIN DE CREACION DE INTEGRAL
	//Calculo de la matriz de correlaciones entre los dos objetos volumetricos en
	//el espacio de Fourier

	//for ( j = 1; j <= 100000; j++ )
	fourier_corr( bw, integralr, integrali, vld, coef_corr );

	//Transformacion inversa de la matriz de correlaciones en Fourier, obteniendo la
	//matriz de correlaciones en funcion de angulos
	fftwf_execute( plan );

	//Conversion de angulos y obtencion de los picos con mayor correlacion de
	//la matriz
	if ( ii == -1 && jj == -1 && kk == -1 )
	{
		npeaks = best_angles( coef_corr, bw, 2 * bw, dist_cut, corr, norm_fact, TotalPeaks );
	}
	else
	{
		best_angle( ii, jj, kk, coef_corr, bw, 2 * bw, corr, norm_fact, sinInterp );
	}

	return npeaks;
}


/* ==================================================================== */
void fourier_corr( int bw, float * coeffr, float * coeffi, vlDCoef * ddd, float * coef_corr )
{
	// computes the Fourier coefficients of the correlation function
	int size = bw << 1, tsize = size << 1;
	float tempd, dddumpi,dddumpr,dddumpil,dddumprl;
	unsigned long size2,  tsize2 ;

	//Indices auxiliares
	unsigned long aux_d_hmp1, aux_d_mh1, aux_har1, aux_obj1, aux_obj2, aux_obj3, aux_obj4, aux_obj5, aux_obj6;

	int tl = 0, tl1, l, m, h, mp, init, init_mmp;
	int isig_m, isig_mp, isig_mp2;
	unsigned long index_d_mh, index_d_hmp, index_mmp, index_mhmp, index_m_hmp, indexm_hmp, indexmhmp, sizesub1_tsize,
	sizesub1_tsize2, size_tsize;




	tsize = ( tsize / 2 ) + 2;
	size2 = size * ( size / 2 + 1 );
	tsize2 = 2 * size2;
	sizesub1_tsize = ( size - 1 ) * tsize;
	sizesub1_tsize2 = ( size - 1 ) * tsize2;
	size_tsize = size * tsize;

	memset( coef_corr, 0, sizeof( float ) * size * size * (size +2) );

	/* PASO 1. Para l de 0 a bw2 se incrementa el valor de correlacion en los cuadrantes

    --+ (Este se calcula a partir de lo que seria el cuadrante ++-) +++

    Para cada "capa" l se realiza el incremento en funcion de los coeficientes de los
    harmonicos esfericos de dicha capa y loos coeficientes d asociados.

    Tambien se calcula el caso especial para el cuadrante -++ en el que h=0

    Se producen casos especiales para m=0 y h=0 debido a que estos valores solo se calculan
    para la parte positiva pero no para la negativa

    Al final de la Parte 1 no se tienen calculados los dos cuadrantes completamente ya que el incremento de
    la ultima capa de l se introduce en la parte 2 */


	for ( l = 0, tl = 0, tl1 = 1; l < bw - 1; l++, tl += 2, tl1 += 2 )
	{
		//Posicion inicial los coeficientes d asociados a la capa l
		init = l * ( tl * tl - 1 ) / 3 + l * ( tl1 );
		//Posicion inicial de los coeficientes de los esfericos harmonicos de la capa l
		init_mmp = ( l * ( tl * tl - 1 ) / 3 + ( l * l ) ) / 2;
		//
		//  Caso especial para cuadrante +++
		//              m=0
		//
		for ( mp = -l, aux_d_hmp1 = init + l, index_mmp = init_mmp + l, aux_obj1 = 0; mp <= 0;
				mp++, aux_d_hmp1++, index_mmp++, aux_obj1 += 2 )
		{
			dddumpr=* ( coeffr + index_mmp );
			dddumpi=* ( coeffi + index_mmp );
			for ( h = 0, index_d_hmp = aux_d_hmp1, index_d_mh = init + l, indexmhmp = aux_obj1; h <= l;
					h++, index_d_hmp += ( tl1 ), index_d_mh++, indexmhmp += tsize )
			{
				tempd = ddd->get( index_d_mh ) * ddd->get( index_d_hmp );
				//fprintf(stderr,"\n\n************\n");
				//fprintf(stderr,"l=%d m=%d h=%d mp=%d\n",l,m,h,mp);
				//fprintf(stderr,"coef_corr=%f %f\n",* ( coef_corr + indexmhmp ),* ( coef_corr + indexmhmp +1 ));
				//fprintf(stderr,"intgralr=%f integrali=%f ddd1=%f ddd2=%f\n",dddumpr,dddumpi,ddd->get( index_d_mh ),ddd->get( index_d_mh ));

				* ( coef_corr + indexmhmp ) += dddumpr * tempd;
				* ( coef_corr + indexmhmp + 1 ) += dddumpi * tempd;
				//fprintf(stderr,"coef_corr=%f\n",* ( coef_corr + indexmhmp ));

			}
		}
		//
		//     cuadrante +++ y --+ m>0
		//
		for ( m = 1, aux_d_mh1 = init + ( tl1 ) + l, aux_har1 = init_mmp + tl1, aux_obj1 = sizesub1_tsize2 + 2 * l, aux_obj3 = tsize2; m <= l;
				m++, aux_d_mh1 += ( tl1 ), aux_har1 += ( tl1 ), aux_obj1 -= tsize2, aux_obj3 += tsize2 )
		{
			for ( mp = -l, aux_d_hmp1 = init, index_mmp = aux_har1, aux_obj2 = aux_obj1, aux_obj4 = aux_obj3; mp <= 0;
					mp++, aux_d_hmp1++, index_mmp++, aux_obj2 -= 2, aux_obj4 += 2 )
			{

				//
				//  Caso especial con h=0 para el cuadrante -++
				//
				tempd = ddd->get( aux_d_mh1 ) * ddd->get( aux_d_hmp1 );
				//fprintf(stderr,"\n\n************\n");
				//fprintf(stderr,"l=%d m=%d h=0 mp=%d\n",l,m,h,mp);
				//fprintf(stderr,"coef_corr=%f %f\n",* ( coef_corr + aux_obj2 ),* ( coef_corr + aux_obj2 +1 ));
				//fprintf(stderr,"intgralr=%f integrali=%f ddd1=%f ddd2=%f\n",* ( coeffr + index_mmp ),* ( coeffi + index_mmp ),ddd->get( aux_d_mh1 ),ddd->get( aux_d_hmp1 ));

				* ( coef_corr + aux_obj2 ) += * ( coeffr + index_mmp ) * tempd;
				* ( coef_corr + aux_obj2 + 1 ) -=  * ( coeffi + index_mmp ) * tempd;
				//fprintf(stderr,"coef_corr=%f %f\n",* ( coef_corr + aux_obj2 ),* ( coef_corr + aux_obj2 +1 ));

				//
				// Caso especial con h=0 para el cuadrante +++
				//
				tempd = ddd->get( aux_d_mh1 ) * ddd->get( aux_d_hmp1 + l );
				//fprintf(stderr,"\n\n************\n");
				//fprintf(stderr,"l=%d m=%d h=0 mp=%d\n",l,m,h,mp);
				//fprintf(stderr,"coef_corr=%f %f\n",* ( coef_corr + aux_obj4 ),* ( coef_corr + aux_obj4 +1 ));
				//fprintf(stderr,"intgralr=%f integrali=%f ddd1=%f ddd2=%f\n",* ( coeffr + index_mmp + l  ),* ( coeffi + index_mmp + l ),ddd->get( aux_d_mh1 ),ddd->get( aux_d_hmp1 + l ));

				* ( coef_corr + aux_obj4 ) += * ( coeffr + index_mmp + l ) * tempd;
				* ( coef_corr + aux_obj4 + 1 ) += * ( coeffi + index_mmp + l ) * tempd;
				//fprintf(stderr,"coef_corr=%f %f\n",* ( coef_corr + aux_obj4 ),* ( coef_corr + aux_obj4 +1 ));

				//
				//  Cuadrantes +++ y --+ para h>0 y m>0
				//
				dddumpr=* ( coeffr + index_mmp );
				dddumpi=* ( coeffi + index_mmp );
				dddumprl=* ( coeffr + index_mmp +l);
				dddumpil=* ( coeffi + index_mmp +l);
				for ( h = 1, index_d_hmp = aux_d_hmp1 + ( tl1 ),
						index_d_mh = aux_d_mh1 + 1, index_m_hmp = aux_obj2 + sizesub1_tsize, indexmhmp = aux_obj4 + tsize; h <= l;
						h++, index_d_hmp += tl1, index_d_mh++, index_m_hmp -= tsize, indexmhmp += tsize )
				{
					//     PARA --+
					tempd = ddd->get(index_d_mh ) * ddd->get(index_d_hmp);
					//fprintf(stderr,"\n\n************\n");
					//fprintf(stderr,"l=%d m=%d h=%d mp=%d\n",l,m,h,mp);
					//fprintf(stderr,"coef_corr=%f %f\n",* ( coef_corr + index_m_hmp ),* ( coef_corr +index_m_hmp + 1 ));
					//fprintf(stderr,"intgralr=%f integrali=%f ddd1=%f ddd2=%f\n",dddumpr,dddumpi,ddd->get( index_d_mh ),ddd->get( index_d_hmp ));

					* ( coef_corr + index_m_hmp ) += dddumpr * tempd;
					* ( coef_corr + index_m_hmp + 1 ) -= dddumpi* tempd;
					//fprintf(stderr,"coef_corr=%f %f\n",* ( coef_corr + index_m_hmp ),* ( coef_corr +index_m_hmp + 1 ));

					//     PARA +++
					tempd = ddd->get( index_d_mh ) * ddd->get( index_d_hmp + l );
					//fprintf(stderr,"\n\n************\n");
					//fprintf(stderr,"l=%d m=%d h=%d mp=%d\n",l,m,h,mp);
					//fprintf(stderr,"coef_corr=%f %f\n",* ( coef_corr + indexmhmp ),* ( coef_corr +indexmhmp + 1 ));
					//fprintf(stderr,"intgralr=%f integrali=%f ddd1=%f ddd2=%f\n",dddumprl,dddumpil,ddd->get( index_d_mh ),ddd->get( index_d_hmp + l ));
					* ( coef_corr + indexmhmp ) += dddumprl * tempd;
					* ( coef_corr + indexmhmp + 1 ) += dddumpil  * tempd;
					//fprintf(stderr,"coef_corr=%f %f\n",* ( coef_corr + indexmhmp ),* ( coef_corr +indexmhmp + 1 ));

				}
			}
		}
	}

	/* PASO 2. Se realizan dos cosas: Primero: se termina de calcular los valores para los cuadrantes +++ y --+
       incrementandolos en funcion de la ultima capa.

       Segundo: se calculan los valores de los cuadrantes -++ y +-+ a partir de los
       valores de los cuadrantes --+ y +-+ respectivamente

	 */

	//
	// PARA l=bw-1
	//
	//Valores de l para la ultima capa
	l = bw - 1; tl = 2 * ( bw - 1 ); tl1 = tl + 1;
	//Posicion inicial los coeficientes d asociados a la ultima capa l
	init = l * ( tl * tl - 1 ) / 3 + l * ( tl1 );
	//Posicion inicial de los coeficientes de los esfericos harmonicos de la capa l
	init_mmp = ( l * ( tl * tl - 1 ) / 3 + ( l * l ) ) / 2;


	//
	//  Caso especial para m=0
	//  para terminar de calcular +++ y ,
	//  en funcion de lo anterior calcular +-+
	//
	//Paridad de m
	isig_m = 1;
	//Paridad de mp
	isig_mp = -1;
	for ( mp = 0, aux_d_hmp1 = init + l, aux_d_mh1 = init + l, index_mmp = init_mmp + l, aux_obj1 = 0, aux_obj3 = size_tsize; mp <= l;
			mp++, aux_d_hmp1++, index_mmp++, aux_obj1 += 2, aux_obj3 += 2 )
	{
		//Cambio de paridad de mp
		isig_mp = -isig_mp;
		//
		// Caso especial para h=0
		//
		// para terminar de calcular valores en +++ (Para +-+ no hace falta ese valor)
		//
		tempd = ddd->get( aux_d_mh1 ) * ddd->get( aux_d_hmp1 );
		//fprintf(stderr,"\n\n************\n");
		//fprintf(stderr,"l=%d m=%d h=%d mp=%d\n",l,m,h,mp);
		//fprintf(stderr,"coef_corr=%f %f\n",* ( coef_corr + aux_obj1 ),* ( coef_corr +aux_obj1 + 1 ));
		//fprintf(stderr,"intgralr=%f integrali=%f ddd1=%f ddd2=%f\n",* ( coeffr + index_mmp  ),* ( coeffi + index_mmp ),ddd->get( aux_d_mh1 ),ddd->get( aux_d_hmp1 ));

		* ( coef_corr + aux_obj1 ) += * ( coeffr + index_mmp ) * tempd;
		* ( coef_corr + aux_obj1 + 1 ) += * ( coeffi + index_mmp ) * tempd;
		//fprintf(stderr,"coef_corr=%f %f\n",* ( coef_corr + aux_obj1 ),* ( coef_corr +aux_obj1 + 1 ));

		//
		// Cuadrantes +++ y +-+ para h>0
		//
		dddumpr=* ( coeffr + index_mmp);
		dddumpi=* ( coeffi + index_mmp);
		if ( isig_m == isig_mp )
			for ( h = 1, index_d_hmp = aux_d_hmp1 + tl1, index_d_mh = aux_d_mh1 + 1, indexm_hmp = aux_obj3 - tsize, indexmhmp = aux_obj1 + tsize;
					h <= l; h++, index_d_hmp += tl1, index_d_mh++, indexm_hmp -= tsize, indexmhmp += tsize )
			{
				// cuadrante +++
				tempd = ddd->get( index_d_mh ) * ddd->get( index_d_hmp );
				//fprintf(stderr,"\n\n************\n");
				//fprintf(stderr,"l=%d m=%d h=%d mp=%d\n",l,m,h,mp);
				//fprintf(stderr,"coef_corr=%f %f\n",* ( coef_corr + indexmhmp ),* ( coef_corr +indexmhmp + 1 ));
				//fprintf(stderr,"intgralr=%f integrali=%f ddd1=%f ddd2=%f\n",* ( coeffr + index_mmp  ),* ( coeffi + index_mmp ),ddd->get( index_d_mh ),ddd->get( index_d_hmp ));

				* ( coef_corr + indexmhmp ) += dddumpr * tempd;
				* ( coef_corr + indexmhmp + 1 ) += dddumpi * tempd;
				//fprintf(stderr,"coef_corr=%f %f\n",* ( coef_corr + indexmhmp ),* ( coef_corr +indexmhmp + 1 ));
				//  cuadrante +-+ en funcion de las paridades
				//fprintf(stderr,"\n\n************\n");
				//fprintf(stderr,"l=%d m=%d h=%d mp=%d\n",l,m,h,mp);
				//fprintf(stderr,"coef_corr=%f %f\n",* ( coef_corr + indexm_hmp ),* ( coef_corr +indexm_hmp + 1 ));

				* ( coef_corr + indexm_hmp ) = * ( coef_corr + indexmhmp );
				* ( coef_corr + indexm_hmp + 1 ) = * ( coef_corr + indexmhmp + 1 );
				//fprintf(stderr,"new coef_corr=%f %f\n",* ( coef_corr + indexm_hmp ),* ( coef_corr +indexm_hmp + 1 ));

			}
		else
			for ( h = 1, index_d_hmp = aux_d_hmp1 + tl1, index_d_mh = aux_d_mh1 + 1, indexm_hmp = aux_obj3 - tsize, indexmhmp = aux_obj1 + tsize;
					h <= l; h++, index_d_hmp += tl1, index_d_mh++, indexm_hmp -= tsize, indexmhmp += tsize )
			{
				// cuadrante +++
				tempd = ddd->get( index_d_mh ) * ddd->get( index_d_hmp );
				//fprintf(stderr,"\n\n************\n");
				//fprintf(stderr,"l=%d m=%d h=%d mp=%d\n",l,m,h,mp);
				//fprintf(stderr,"coef_corr=%f %f\n",* ( coef_corr + indexmhmp ),* ( coef_corr +indexmhmp + 1 ));
				//fprintf(stderr,"intgralr=%f integrali=%f ddd1=%f ddd2=%f\n",dddumpr,dddumpi,ddd->get( index_d_mh ),ddd->get( index_d_hmp ));

				* ( coef_corr + indexmhmp ) += dddumpr * tempd;
				* ( coef_corr + indexmhmp + 1 ) += dddumpi * tempd;
				//fprintf(stderr,"coef_corr=%f %f\n",* ( coef_corr + indexmhmp ),* ( coef_corr +indexmhmp + 1 ));
				//  cuadrante +-+ en funcion de las paridades
				//fprintf(stderr,"\n\n************\n");
				//fprintf(stderr,"l=%d m=%d h=%d mp=%d\n",l,m,h,mp);
				//fprintf(stderr,"coef_corr=%f %f\n",* ( coef_corr + indexm_hmp ),* ( coef_corr +indexm_hmp + 1 ));
				* ( coef_corr + indexm_hmp ) -= * ( coef_corr + indexmhmp );
				* ( coef_corr + indexm_hmp + 1 ) -= * ( coef_corr + indexmhmp + 1 );
				//fprintf(stderr,"new coef_corr=%f %f\n",* ( coef_corr + indexm_hmp ),* ( coef_corr +indexm_hmp + 1 ));

			}
	}

	//
	//  Cuadrantes +++ y --+ & calcular +-+  y -++
	//
	//
	//Paridad de m
	isig_m = 1;
	for ( m = 1, aux_d_mh1 = init + tl1 + l, aux_har1 = init_mmp + tl1, aux_obj1 = sizesub1_tsize2 + 2 * l, aux_obj3 =
			sizesub1_tsize2 + tsize + 2 * l, aux_obj5 = tsize2; m <= l;
			m++, aux_d_mh1 += tl1, aux_har1 += tl1, aux_obj1 -= tsize2, aux_obj3 -= tsize2, aux_obj5 += tsize2 )
	{
		//Cambio de paridad de m
		isig_m = -isig_m;
		//Paridad de mp
		isig_mp = 1;
		for ( mp = -l, aux_d_hmp1 = init, index_mmp = aux_har1, aux_obj2 = aux_obj1, aux_obj4 = aux_obj3, aux_obj6 = aux_obj5; mp <= 0;
				mp++, aux_d_hmp1++, index_mmp++, aux_obj2 -= 2, aux_obj4 -= 2, aux_obj6 += 2 )
		{
			//Cambio de paridad de mp
			isig_mp = -isig_mp;
			//
			// Caso especial cuadrante +-+ con h=0
			//
			tempd = ddd->get( aux_d_mh1 ) * ddd->get( aux_d_hmp1 );
			//fprintf(stderr,"\n\n************\n");
			//fprintf(stderr,"l=%d m=%d h=%d mp=%d\n",l,m,h,mp);
			//fprintf(stderr,"coef_corr=%f %f\n",* ( coef_corr + aux_obj1 ),* ( coef_corr +aux_obj1 + 1 ));
			//fprintf(stderr,"intgralr=%f integrali=%f ddd1=%f ddd2=%f\n",* ( coeffr + index_mmp ),* ( coeffi + index_mmp ),ddd->get( aux_d_mh1 ),ddd->get( aux_d_hmp1 ));
			// a bug was found here
			* ( coef_corr + aux_obj2 ) += * ( coeffr + index_mmp ) * tempd;
			* ( coef_corr + aux_obj2 + 1 ) -= * ( coeffi + index_mmp ) * tempd;
			//fprintf(stderr,"coef_corr=%f %f\n",* ( coef_corr + aux_obj1 ),* ( coef_corr +aux_obj1 + 1 ));

			//
			// Cuadrantes --+ (finalizar) y -++ para h>0
			//
			dddumpr=* ( coeffr + index_mmp );
			dddumpi=* ( coeffi + index_mmp );
			if ( isig_m == isig_mp )
				for ( h = 1, index_d_hmp = aux_d_hmp1 + tl1, index_d_mh = aux_d_mh1 + 1, index_m_hmp =
						aux_obj2 + sizesub1_tsize, index_mhmp = aux_obj4; h <= l;
						h++, index_d_hmp += tl1, index_d_mh++, index_m_hmp -= tsize, index_mhmp += tsize )
				{
					// PARA --+
					tempd = ddd->get( index_d_mh ) * ddd->get( index_d_hmp );
					//fprintf(stderr,"\n\n************\n");
					//fprintf(stderr,"l=%d m=%d h=%d mp=%d\n",l,m,h,mp);
					//fprintf(stderr,"coef_corr=%f %f\n",* ( coef_corr + index_m_hmp ),* ( coef_corr +index_m_hmp + 1 ));
					//fprintf(stderr,"intgralr=%f integrali=%f ddd1=%f ddd2=%f\n",dddumpr,dddumpi,ddd->get( index_d_mh ),ddd->get( index_d_hmp ));
					* ( coef_corr + index_m_hmp ) += dddumpr * tempd;
					* ( coef_corr + index_m_hmp + 1 ) -= dddumpi * tempd;
					//fprintf(stderr,"coef_corr=%f %f\n",* ( coef_corr + index_m_hmp ),* ( coef_corr +index_m_hmp + 1 ));
					// PARA -++ en funcion --+ segun paridad
					//fprintf(stderr,"\n\n************\n");
					//fprintf(stderr,"l=%d m=%d h=%d mp=%d\n",l,m,h,mp);
					//fprintf(stderr,"coef_corr=%f %f\n",* ( coef_corr + index_mhmp ),* ( coef_corr +index_mhmp + 1 ));
					* ( coef_corr + index_mhmp ) =  * ( coef_corr + index_m_hmp );
					* ( coef_corr + index_mhmp + 1 ) = * ( coef_corr + index_m_hmp + 1 );
					//fprintf(stderr,"coef_corr=%f %f\n",* ( coef_corr + index_mhmp ),* ( coef_corr +index_mhmp + 1 ));

				}
			else for ( h = 1, index_d_hmp = aux_d_hmp1 + tl1, index_d_mh = aux_d_mh1 + 1, index_m_hmp =
					aux_obj2 + sizesub1_tsize, index_mhmp = aux_obj4; h <= l;
					h++, index_d_hmp += tl1, index_d_mh++, index_m_hmp -= tsize, index_mhmp += tsize )
			{
				// PARA  --+
				tempd = ddd->get( index_d_mh ) * ddd->get( index_d_hmp );
				//fprintf(stderr,"\n\n************\n");
				//fprintf(stderr,"l=%d m=%d h=%d mp=%d\n",l,m,h,mp);
				//fprintf(stderr,"coef_corr=%f %f\n",* ( coef_corr + index_m_hmp ),* ( coef_corr +index_m_hmp + 1 ));
				//fprintf(stderr,"intgralr=%f integrali=%f ddd1=%f ddd2=%f\n",dddumpr,dddumpi,ddd->get( index_d_mh ),ddd->get( index_d_hmp ));
				* ( coef_corr + index_m_hmp ) += dddumpr * tempd;
				* ( coef_corr + index_m_hmp + 1 ) -= dddumpi * tempd;
				//fprintf(stderr,"coef_corr=%f %f\n",* ( coef_corr + index_m_hmp ),* ( coef_corr +index_m_hmp + 1 ));
				// PARA -++ en funcion --+ segun paridad
				//fprintf(stderr,"\n\n************\n");
				//fprintf(stderr,"l=%d m=%d h=%d mp=%d\n",l,m,h,mp);
				//fprintf(stderr,"coef_corr=%f %f\n",* ( coef_corr + index_mhmp ),* ( coef_corr +index_mhmp + 1 ));
				* ( coef_corr + index_mhmp ) -= * ( coef_corr + index_m_hmp );
				* ( coef_corr + index_mhmp + 1 ) -=  * ( coef_corr + index_m_hmp + 1 );
				//fprintf(stderr,"coef_corr=%f %f\n",* ( coef_corr + index_mhmp ),* ( coef_corr +index_mhmp + 1 ));

			}

			//
			// Finalización cuadrante +++ y en funcion del calcular +-+
			//
			//
			//  Caso especial para h=0 (para +-+ estos valores no son necesarios)
			//
			//  como mp es negativo y se necesita para estos cuadrantes que sea positivo
			//  se realiza una transformacion
			h = 0;
			isig_mp2 = -isig_mp;
			tempd = ddd->get( aux_d_mh1 ) * ddd->get( aux_d_hmp1 + l );
			//fprintf(stderr,"\n\n************\n");
			//fprintf(stderr,"l=%d m=%d h=%d mp=%d\n",l,m,h,mp);
			//fprintf(stderr,"coef_corr=%f %f\n",* ( coef_corr + aux_obj6 ),* ( coef_corr +aux_obj6 + 1 ));
			//fprintf(stderr,"intgralr=%f integrali=%f ddd1=%f ddd2=%f\n",* ( coeffr + index_mmp + l ),* ( coeffi + index_mmp + l ),ddd->get( aux_d_mh1 ),ddd->get( aux_d_hmp1 + l ));
			* ( coef_corr + aux_obj6 ) += * ( coeffr + index_mmp + l ) * tempd;
			* ( coef_corr + aux_obj6 + 1 ) += * ( coeffi + index_mmp + l ) * tempd;
			//fprintf(stderr,"coef_corr=%f %f\n",* ( coef_corr + aux_obj6 ),* ( coef_corr +aux_obj6 + 1 ));

			//
			//  Calculo +++ y +-+ para h>0
			//
			if ( isig_m == isig_mp2 )
				for ( h = 1, indexmhmp = aux_obj6 + tsize, indexm_hmp = aux_obj6 + sizesub1_tsize; h <= l;
						h++, indexmhmp += tsize, indexm_hmp -= tsize )
				{
					//fprintf(stderr,"\n\n************\n");
					//fprintf(stderr,"l=%d m=%d h=%d mp=%d\n",l,m,h,mp);
					//fprintf(stderr,"coef_corr=%f %f\n",* ( coef_corr + indexm_hmp ),* ( coef_corr +indexm_hmp + 1 ));

					* ( coef_corr + indexm_hmp ) =  * ( coef_corr + indexmhmp );
					* ( coef_corr + indexm_hmp + 1 ) =  * ( coef_corr + indexmhmp + 1 );
					//fprintf(stderr,"new coef_corr=%f %f\n",* ( coef_corr + indexm_hmp ),* ( coef_corr +indexm_hmp + 1 ));

				}
			else   for ( h = 1, indexmhmp = aux_obj6 + tsize, indexm_hmp = aux_obj6 + sizesub1_tsize; h <= l;
					h++, indexmhmp += tsize, indexm_hmp -= tsize )
			{
				//fprintf(stderr,"\n\n************\n");
				//fprintf(stderr,"l=%d m=%d h=%d mp=%d\n",l,m,h,mp);
				//fprintf(stderr,"coef_corr=%f %f\n",* ( coef_corr + indexm_hmp ),* ( coef_corr +indexm_hmp + 1 ));

				* ( coef_corr + indexm_hmp ) -= * ( coef_corr + indexmhmp );
				* ( coef_corr + indexm_hmp + 1 ) -= * ( coef_corr + indexmhmp + 1 );
				//fprintf(stderr,"new coef_corr=%f %f\n",* ( coef_corr + indexm_hmp ),* ( coef_corr +indexm_hmp + 1 ));

			}
		}
	}


}
/* ==================================================================== */
void split_corr(float * coef_corr,int size,int bw)
{

	float *coef_corr2;
	int x,y,z;
	int im1,im2,ih1,ih2,imp1,imp2,s;

	ih2=2*bw+2;
	ih1=bw+2;
	im2=2*bw*(2*bw+2);
	im1=2*bw*(bw+2);
	imp1=imp2=2;
	s=2*bw;

	coef_corr2=(float*)malloc(sizeof(float)*size);
	memcpy(coef_corr2, coef_corr, sizeof(float)*size);
	memset( coef_corr, 0, sizeof( float ) * size );

	for(x=0;x<s;x++)
		for(y=0;y<s;y++)
			for(z=0;z<bw/2+1;z++)
			{
				*(coef_corr + (x*im1+y*ih1+z*imp1) )= *(coef_corr2 + (x*im2+y*ih2+z*imp2) + ih2/2  - 1  );
				*(coef_corr + (x*im1+y*ih1+z*imp1) +1 )= *(coef_corr2 + (x*im2+y*ih2+z*imp2)  + ih2/2 -1  + 1);
			}

	free(coef_corr2);
}


/* ==================================================================== */


int best_angles( float * buff, int bw, int size, float dist_cut, float * corr[], float norm, int MaxPeaks )
{

	int i, j, k, l, m, n, p, npeaks;
	int ind1, ind2, ind3;
	// float *corr[4];
	float f000, f100, f200, f010, f020, f001, f002;
	float temp, tempi, tempj, tempk;
	int size2 = size * ( size + 2 );
	float phi, th, psi;
	float phe, phc, ohm;


	float correlation;
	bool repetido;
	timer tim;

	memset( corr[0], 0, sizeof( float ) * MaxPeaks );

	int cont=0;
	//Exploracion de todos los valores del buffer de correlaciones. Cada valor es comparado
	//con sus valores vecinos. Si el valor es el mas alto de sus vecinos=> esa posicion es un pico
	//OJO: al comparar con los vecinos hay que tener en cuenta que existen dos valores expureos en el buffer
	//para cada valor de la ultima dimension (al final de la fila) que no deben de ser tenidos en cuenta

	npeaks = 0;


	for ( i = 0; i < size; i++ )
	{

		ind1 = i * size2;
		for ( j = 0; j <= bw; j++ )
		{
			ind2 = ind1 + j * ( size + 2 );
			for ( k = 0; k < size; k++ )
			{
				ind3 = ind2 + k;

				//OJO esto faltaba
				f000 = buff[ind3];
				if(f000>0.0)
				{

					if ( j == bw ) f020 = f000;
					else
						f020 = buff[( ind3 + size + 2 )];

					if ( f020 <=  f000  )
					{
						if ( i == 0 ) f100 = buff[( ind3 + ( size - 1 ) * size2 )];
						else
							f100 = buff[( ind3 - size2 )];

						if ( f100 <= f000 )
						{
							if ( i == size - 1 ) f200 = buff[( j * ( size + 2 ) + k )];
							else
								f200 = buff[( ind3 + size2 )];

							if ( f200 <= f000 )
							{
								//if ( j == 0 ) f010 = buff[( ind3 + size2 - ( size + 2 ) )];
								if ( j == 0 ) f010 = f000;// j=0 and j=bw no interpolation
								else
									f010 = buff[( ind3 - ( size + 2 ) )];

								if ( f010 <= f000 )
								{
									if ( k == 0 ) f001 = buff[( ind3 + size - 1 )];
									else
										f001 = buff[( ind3 - 1 )];

									if ( f001 <= f000 )
									{
										if ( k == size - 1 ) f002 = buff[ind2];
										else
											f002 = buff[( ind3 + 1 )];

										if ( f002 <= f000 )
										{

											tempi = 0.0; tempj = 0.0; tempk = 0.0;

											if ( ( temp = f100 + f200 - 2 * f000 ) != 0 )
												tempi = ( f100 - f200 ) / ( 2 * temp );
											phe = ( i + tempi ) * M_PI / bw;

											if ( j != 0 )
												if ( ( temp = f010 + f020 - 2 * f000 ) != 0 )
													tempj = ( f010 - f020 ) / ( 2 * temp );
											phc = ( j + tempj ) * M_PI / bw;

											if (phc>M_PI) { phc=M_PI; tempj=0.0; }
											else if (phc<0) { phc=0.00000; tempj=0.0; }

											if ( ( temp = f001 + f002 - 2 * f000 ) != 0 )
												tempk = ( f001 - f002 ) / ( 2 * temp );
											ohm = ( k + tempk ) * M_PI / bw;

											psi = -phe;
											psi = psi - 2.0 * M_PI * floor( psi / 2.0 / M_PI );
											th = M_PI - phc;
											//th = th - 2.0 * M_PI * floor( th / 2.0 / M_PI );
											phi = M_PI - ohm;
											phi = phi - 2.0 * M_PI * floor( phi / 2.0 / M_PI );

											///



											correlation = ( 0.5 * ( f100 + f200 ) - f000 ) * tempi * tempi + ( 0.5 * ( f010 + f020 ) - f000 ) * tempj
													* tempj + ( 0.5 * ( f001 + f002 ) - f000 ) * tempk * tempk + 0.5 * ( f200 - f100 ) * tempi + 0.5
													* ( f020 - f010 ) * tempj + 0.5 * ( f002 - f001 ) * tempk + f000;


											/*if(fabs(correlation-f000)>100&&(correlation>0.0))
									{
										fprintf(stdout,"\n i=%d j=%d k=%d\n",i,j,k);
										fprintf(stdout,"f000=%f f100=%f f200=%f f010=%f f020=%f f001=%f f002=%f\n",f000,f100,f200,f010,f020,f001,f002);
										fprintf(stdout,"correlation=%f\n",correlation);
                                        //colocacion del nuevo pico en la lista ordenada de mayor a menor
									}*/

											correlation /= norm;


											repetido = false;
											cont++;
											if ( npeaks == 0 )
											{
												corr[0] [0] = correlation;
												corr[1] [0] = psi;
												corr[2] [0] = th;
												corr[3] [0] = phi;
												corr[4] [0] = (float) i;
												corr[5] [0] = (float) j;
												corr[6] [0] = (float) k;
												npeaks++;
											}
											else
											{

												if((npeaks == MaxPeaks) && correlation<corr[0] [npeaks-1])
												{

												}
												else
												{
													for(n=0; n < npeaks && !repetido; n++)
													{
														if ( distance_eulers( psi, th, phi, n, corr ) < dist_cut * M_PI / 180.0 )
														{
															if(correlation<=corr[0][n])
																repetido=true;
															else
															{
																//Borrar solucion n
																for(m=n;m<(npeaks-1);m++)
																	for ( l = 0; l < 7; l++ ) corr[l] [m] = corr[l] [m+1];
																npeaks--;
															}
														}
													}


													if(!repetido)
													{
														//meter solucion
														for ( p = 0; p < npeaks; p++ )
															if ( correlation > corr[0] [p] ) break;

														if(npeaks<(MaxPeaks-1))
															npeaks++;

														if(p<npeaks)
														{

															for(m=npeaks-1;m>=p;m--)
																for ( l = 0; l < 7; l++ ) corr[l] [m+1] = corr[l] [m];
														}
														corr[0] [p] = correlation;
														corr[1] [p] = psi;
														corr[2] [p] = th;
														corr[3] [p] = phi;
														corr[4] [p] = (float) i;
														corr[5] [p] = (float) j;
														corr[6] [p] = (float) k;



													}
												}

											}





										} // end peak detection
									}
								}
							}
						}
					}

				}//if(f000>0)

			}//for k
		}//for j
	}//for i
	//free(buff);



	//printf("contador=%d\n",cont);
	return npeaks;
}

int best_angles_wI( float * buff, int bw, int size, float dist_cut, float * corr[], float norm, int MaxPeaks )
{

	int i, j, k, l, m, n, p, npeaks;
	int ind1, ind2, ind3;
	// float *corr[4];
	float f000, f100, f200, f010, f020, f001, f002;
	float temp, tempi, tempj, tempk;
	int size2 = size * ( size + 2 );
	float phi, th, psi;
	float phe, phc, ohm;
	float fact=0.25;

	float correlation;
	bool repetido;
	timer tim;
	float matrix_sol[3][3];
	float distance_rot=dist_cut * M_PI / 180.0;

	memset( corr[0], 0, sizeof( float ) * MaxPeaks );

	int cont=0;
	//Exploracion de todos los valores del buffer de correlaciones. Cada valor es comparado
	//con sus valores vecinos. Si el valor es el mas alto de sus vecinos=> esa posicion es un pico
	//OJO: al comparar con los vecinos hay que tener en cuenta que existen dos valores expureos en el buffer
	//para cada valor de la ultima dimension (al final de la fila) que no deben de ser tenidos en cuenta

	npeaks = 0;


	for ( i = 0; i < size; i++ )
	{

		ind1 = i * size2;
		for ( j = 0; j <= bw; j++ )
		{
			ind2 = ind1 + j * ( size + 2 );
			for ( k = 0; k < size; k++ )
			{
				ind3 = ind2 + k;

				//OJO esto faltaba
				f000 = buff[ind3];
				if(f000>0.0)
				{
					if ( j == bw ) f020 = f000;
					else
						f020 = buff[( ind3 + size + 2 )];

					if ( f020 <= f000 )
					{
						if ( i == 0 ) f100 = buff[( ind3 + ( size - 1 ) * size2 )];
						else
							f100 = buff[( ind3 - size2 )];

						if ( f100 <= f000 )
						{
							if ( i == size - 1 ) f200 = buff[( j * ( size + 2 ) + k )];
							else
								f200 = buff[( ind3 + size2 )];

							if ( f200 <= f000 )
							{
								// if ( j == 0 ) f010 = buff[( ind3 + size2 - ( size + 2 ) )];
								if ( j == 0 ) f010 = f000;// j=0 and j=bw no interpolation
								else
									f010 = buff[( ind3 - ( size + 2 ) )];

								if ( f010 <= f000 )
								{
									if ( k == 0 ) f001 = buff[( ind3 + size - 1 )];
									else
										f001 = buff[( ind3 - 1 )];

									if ( f001 <= f000 )
									{
										if ( k == size - 1 ) f002 = buff[ind2];
										else
											f002 = buff[( ind3 + 1 )];

										if ( f002 <= f000 )
										{

											if(f100>f200)
											{
												if(f200<(f100*fact))
													f200=f100=f000;
											}
											else
											{
												if(f100<(f200*fact))
													f200=f100=f000;
											}

											if(f010>f020)
											{
												if(f020<(f010*fact))
													f020=f010=f000;
											}
											else
											{
												if(f010<(f020*fact))
													f020=f010=f000;
											}

											if(f001>f002)
											{
												if(f002<(f001*fact))
													f002=f001=f000;
											}
											else
											{
												if(f001<(f002*fact))
													f002=f001=f000;
											}


											tempi = 0.0; tempj = 0.0; tempk = 0.0;

											if ( ( temp = f100 + f200 - 2 * f000 ) != 0 )
												tempi = ( f100 - f200 ) / ( 2 * temp );
											phe = ( i + tempi ) * M_PI / bw;

											if ( j != 0 )
												if ( ( temp = f010 + f020 - 2 * f000 ) != 0 )
													tempj = ( f010 - f020 ) / ( 2 * temp );
											phc = ( j + tempj ) * M_PI / bw;

											if (phc>M_PI) { phc=M_PI; tempj=0.0; }
											else if (phc<0) { phc=0.00000; tempj=0.0; }

											if ( ( temp = f001 + f002 - 2 * f000 ) != 0 )
												tempk = ( f001 - f002 ) / ( 2 * temp );
											ohm = ( k + tempk ) * M_PI / bw;

											psi = -phe;
											psi = psi - 2.0 * M_PI * floor( psi / 2.0 / M_PI );
											th = M_PI - phc;
											//th = th - 2.0 * M_PI * floor( th / 2.0 / M_PI );
											phi = M_PI - ohm;
											phi = phi - 2.0 * M_PI * floor( phi / 2.0 / M_PI );

											///



											correlation = ( 0.5 * ( f100 + f200 ) - f000 ) * tempi * tempi + ( 0.5 * ( f010 + f020 ) - f000 ) * tempj
													* tempj + ( 0.5 * ( f001 + f002 ) - f000 ) * tempk * tempk + 0.5 * ( f200 - f100 ) * tempi + 0.5
													* ( f020 - f010 ) * tempj + 0.5 * ( f002 - f001 ) * tempk + f000;


											/*if(fabs(correlation-f000)>100&&(correlation>0.0))
									{
										fprintf(stdout,"\n i=%d j=%d k=%d\n",i,j,k);
										fprintf(stdout,"f000=%f f100=%f f200=%f f010=%f f020=%f f001=%f f002=%f\n",f000,f100,f200,f010,f020,f001,f002);
										fprintf(stdout,"correlation=%f\n",correlation);
                                        //colocacion del nuevo pico en la lista ordenada de mayor a menor
									}*/

											correlation /= norm;
											get_rot_matrix( matrix_sol, psi, th, phi );

											repetido = false;
											cont++;
											if ( npeaks == 0 )
											{
												corr[0] [0] = correlation;
												corr[1] [0] = psi;
												corr[2] [0] = th;
												corr[3] [0] = phi;
												npeaks++;
											}
											else
											{

												if((npeaks == MaxPeaks) && correlation<corr[0] [npeaks-1])
												{

												}
												else
												{
													for(n=0; n < npeaks && !repetido; n++)
													{
														// if ( distance_eulers( matrix_sol, n,  matrix ) < distance_rot )
														if ( distance_eulers( psi,th,phi, n,  corr ) < distance_rot )
														{
															if(correlation<=corr[0][n])
															{
																repetido=true;
															}
															else
															{
																//Borrar solucion n
																for(m=n;m<(npeaks-1);m++)
																{
																	for ( l = 0; l < 4; l++ ) corr[l] [m] = corr[l] [m+1];

																}
																npeaks--;
															}
														}
													}


													if(!repetido)
													{
														//meter solucion
														for ( p = 0; p < npeaks; p++ )
															if ( correlation > corr[0] [p] ) break;
														if(p<MaxPeaks)
														{
															if(npeaks<(MaxPeaks))
																npeaks++;

															if(p<npeaks)
															{

																for(m=npeaks-2;m>=p;m--)
																{
																	for ( l = 0; l < 4; l++ ) corr[l] [m+1] = corr[l] [m];

																}
															}
															corr[0] [p] = correlation;
															corr[1] [p] = psi;
															corr[2] [p] = th;
															corr[3] [p] = phi;

														}


													}
												}

											}





										} // end peak detection
									}
								}
							}
						}
					}

				}//if(f000>0)

			}//for k
		}//for j
	}//for i
	//free(buff);


	//printf("contador=%d\n",cont);

	return npeaks;
}

int best_angles_lI( float * buff, float ***matrix, int bw, int size, float dist_cut, float * corr[], float norm, int MaxPeaks )
{

	int i, j, k, l, m, n, p, npeaks,m1,m2;
	int ind1, ind2, ind3;
	// float *corr[4];
	float f000, f100, f200, f010, f020, f001, f002;
	float temp, tempi, tempj, tempk;
	int size2 = size * ( size + 2 );
	float phi, th, psi;
	float phe, phc, ohm;
	float fact=0.25;

	float correlation;
	bool  repetido;
	timer tim;
	float matrix_sol[3][3];
	float distance_rot=dist_cut * M_PI / 180.0;

	memset( corr[0], 0, sizeof( float ) * MaxPeaks );

	int cont=0;
	//Exploracion de todos los valores del buffer de correlaciones. Cada valor es comparado
	//con sus valores vecinos. Si el valor es el mas alto de sus vecinos=> esa posicion es un pico
	//OJO: al comparar con los vecinos hay que tener en cuenta que existen dos valores expureos en el buffer
	//para cada valor de la ultima dimension (al final de la fila) que no deben de ser tenidos en cuenta

	npeaks = 0;


	for ( i = 0; i < size; i++ )
	{

		ind1 = i * size2;
		for ( j = 0; j <= bw; j++ )
		{
			ind2 = ind1 + j * ( size + 2 );
			for ( k = 0; k < size; k++ )
			{
				ind3 = ind2 + k;

				//OJO esto faltaba
				f000 = buff[ind3];
				if(f000>0.0)
				{
					if ( j == bw ) f020 = f000;
					else
						f020 = buff[( ind3 + size + 2 )];

					if ( f020 <= f000 )
					{
						if ( i == 0 ) f100 = buff[( ind3 + ( size - 1 ) * size2 )];
						else
							f100 = buff[( ind3 - size2 )];

						if ( f100 <= f000 )
						{
							if ( i == size - 1 ) f200 = buff[( j * ( size + 2 ) + k )];
							else
								f200 = buff[( ind3 + size2 )];

							if ( f200 <= f000 )
							{
								// if ( j == 0 ) f010 = buff[( ind3 + size2 - ( size + 2 ) )];
								if ( j == 0 ) f010 = f000;// j=0 and j=bw no interpolation
								else
									f010 = buff[( ind3 - ( size + 2 ) )];

								if ( f010 <= f000 )
								{
									if ( k == 0 ) f001 = buff[( ind3 + size - 1 )];
									else
										f001 = buff[( ind3 - 1 )];

									if ( f001 <= f000 )
									{
										if ( k == size - 1 ) f002 = buff[ind2];
										else
											f002 = buff[( ind3 + 1 )];

										if ( f002 <= f000 )
										{

											if(f100>f200)
											{
												if(f200<(f100*fact))
													f200=f100=f000;
											}
											else
											{
												if(f100<(f200*fact))
													f200=f100=f000;
											}

											if(f010>f020)
											{
												if(f020<(f010*fact))
													f020=f010=f000;
											}
											else
											{
												if(f010<(f020*fact))
													f020=f010=f000;
											}

											if(f001>f002)
											{
												if(f002<(f001*fact))
													f002=f001=f000;
											}
											else
											{
												if(f001<(f002*fact))
													f002=f001=f000;
											}


											tempi = 0.0; tempj = 0.0; tempk = 0.0;

											if ( ( temp = f100 + f200 - 2 * f000 ) != 0 )
												tempi = ( f100 - f200 ) / ( 2 * temp );
											phe = ( i + tempi ) * M_PI / bw;

											if ( j != 0 )
												if ( ( temp = f010 + f020 - 2 * f000 ) != 0 )
													tempj = ( f010 - f020 ) / ( 2 * temp );
											phc = ( j + tempj ) * M_PI / bw;

											if (phc>M_PI) { phc=M_PI; tempj=0.0; }
											else if (phc<0) { phc=0.00000; tempj=0.0; }

											if ( ( temp = f001 + f002 - 2 * f000 ) != 0 )
												tempk = ( f001 - f002 ) / ( 2 * temp );
											ohm = ( k + tempk ) * M_PI / bw;

											psi = -phe;
											psi = psi - 2.0 * M_PI * floor( psi / 2.0 / M_PI );
											th = M_PI - phc;
											//th = th - 2.0 * M_PI * floor( th / 2.0 / M_PI );
											phi = M_PI - ohm;
											phi = phi - 2.0 * M_PI * floor( phi / 2.0 / M_PI );

											///



											correlation = ( 0.5 * ( f100 + f200 ) - f000 ) * tempi * tempi + ( 0.5 * ( f010 + f020 ) - f000 ) * tempj
													* tempj + ( 0.5 * ( f001 + f002 ) - f000 ) * tempk * tempk + 0.5 * ( f200 - f100 ) * tempi + 0.5
													* ( f020 - f010 ) * tempj + 0.5 * ( f002 - f001 ) * tempk + f000;


											correlation /= norm;
											get_rot_matrix( matrix_sol, psi, th, phi );

											repetido = false;
											cont++;
											if ( npeaks == 0 )
											{
												corr[0] [0] = correlation;
												corr[1] [0] = psi;
												corr[2] [0] = th;
												corr[3] [0] = phi;
												for(m1=0;m1<3;m1++)
													for(m2=0;m2<3;m2++)
														matrix[0][m1][m2]=matrix_sol[m1][m2];

												npeaks++;
											}
											else
											{

												if((npeaks == MaxPeaks) && correlation<corr[0] [npeaks-1])
												{

												}
												else
												{
													for(n=0; n < npeaks && !repetido; n++)
													{
														if ( distance_eulers( matrix_sol, n,  matrix ) < distance_rot )
															//if ( distance_eulers( psi,th,phi, n,  corr ) < distance_rot )
														{
															if(correlation<=corr[0][n])
															{
																repetido=true;
															}
															else
															{
																//Borrar solucion n
																for(m=n;m<(npeaks-1);m++)
																{
																	for ( l = 0; l < 4; l++ ) corr[l] [m] = corr[l] [m+1];
																	for(m1=0;m1<3;m1++)
																		for(m2=0;m2<3;m2++)
																			matrix[m][m1][m2]=matrix[m+1][m1][m2];

																}
																npeaks--;
															}
														}
													}


													if(!repetido)
													{
														//meter solucion
														for ( p = 0; p < npeaks; p++ )
															if ( correlation > corr[0] [p] ) break;
														if(p<MaxPeaks)
														{
															if(npeaks<(MaxPeaks))
																npeaks++;

															if(p<npeaks)
															{

																for(m=npeaks-2;m>=p;m--)
																{
																	for ( l = 0; l < 4; l++ ) corr[l] [m+1] = corr[l] [m];
																	for(m1=0;m1<3;m1++)
																		for(m2=0;m2<3;m2++)
																			matrix[m+1][m1][m2]=matrix[m][m1][m2];

																}
															}
															corr[0] [p] = correlation;
															corr[1] [p] = psi;
															corr[2] [p] = th;
															corr[3] [p] = phi;
															for(m1=0;m1<3;m1++)
																for(m2=0;m2<3;m2++)
																	matrix[p][m1][m2]=matrix_sol[m1][m2];
														}


													}
												}

											}





										} // end peak detection
									}
								}
							}
						}
					}

				}//if(f000>0)

			}//for k
		}//for j
	}//for i
	//free(buff);



	//printf("contador=%d\n",cont);

	return npeaks;
}



void best_angle( int ii, int jj, int kk, float * buff, int bw, int size, float * corr[], float norm, bool sinInterp )
{
	int i, j, k;
	int ind1, ind2, ind3;
	float f000, f100, f200, f010, f020, f001, f002;
	float temp, tempi, tempj, tempk, nf000;
	int size2 = size * ( size + 2 );
	float phi, th, psi;
	float phe, phc, ohm;

	float correlation;



	//el valor de la posicion es comparado
	//con sus valores vecinos. Si el valor es el mas alto de sus vecinos=> esa posicion es un pico
	//OJO: al comparar con los vecinos hay que tener en cuenta que existen dos valores expureos en el buffer
	//para cada valor de la ultima dimension (al final de la fila) que no deben de ser tenidos en cuenta

	i = ii;
	j = jj;
	k = kk;

	if ( sinInterp == false )
	{


		ind1 = i * size2;
		ind2 = ind1 + j * ( size + 2 );
		ind3 = ind2 + k;
		f000 = buff[ind3];

		if ( j == bw ) f020 = f000;
		else f020 = buff[( ind3 + size + 2 )]; // j=0 and bw=0 no interpolation

		if ( i == 0 ) f100 = buff[( ind3 + ( size - 1 ) * size2 )];
		else
			f100 = buff[( ind3 - size2 )];
		if ( i == size - 1 ) f200 = buff[( j * ( size + 2 ) + k )];
		else
			f200 = buff[( ind3 + size2 )];
		//if ( j == 0 ) f010 = buff[( ind3 + size2 - ( size + 2 ) )];
		if ( j == 0 ) f010 = f000;
		else
			f010 = buff[( ind3 - ( size + 2 ) )];
		if ( k == 0 ) f001 = buff[( ind3 + size - 1 )];
		else
			f001 = buff[( ind3 - 1 )];
		if ( k == size - 1 ) f002 = buff[ind2];
		else
			f002 = buff[( ind3 + 1 )];

		//printf("matriz rotacion:\n");
		//printf("f000=%f: f100=%f f200=%f f010=%f f020=%f f001=%f f002=%f\n"
		//,f000,f100,f200,f010,f020,f001,f002);

		nf000=f000;
		if ( nf000 < f100)  { nf000 = f100; if (i==0) i=size-1; else i--;}
		if ( nf000 < f200)  { nf000 = f200; if (i==size-1) i=0; else i++;}
		//if ( nf000 < f010)  { nf000 = f010; if (j==0) j=size-1; else j--;}
		//if ( nf000 < f020)  { nf000 = f020; if (j==size-1) j=0; else j++;}
		if ( nf000 < f010)  { nf000 = f010; if (j==0) j=0; else j--;}
		if ( nf000 < f020)  { nf000 = f020; if (j==bw) j=bw; else j++;}
		if ( nf000 < f001)  { nf000 = f001; if (k==0) k=size-1; else k--;}
		if ( nf000 < f002)  { nf000 = f002; if (k==size-1) k=0; else k++;}

		if (nf000!=f000) {

			ind1 = i * size2;
			ind2 = ind1 + j * ( size + 2 );
			ind3 = ind2 + k;
			f000 = buff[ind3];

			if ( j == bw ) f020 = f000;
			else f020 = buff[( ind3 + size + 2 )]; // j=0 and bw=0 no interpolation

			if ( i == 0 ) f100 = buff[( ind3 + ( size - 1 ) * size2 )];
			else
				f100 = buff[( ind3 - size2 )];
			if ( i == size - 1 ) f200 = buff[( j * ( size + 2 ) + k )];
			else
				f200 = buff[( ind3 + size2 )];
			// if ( j == 0 ) f010 = buff[( ind3 + size2 - ( size + 2 ) )];
			if ( j == 0 ) f010 = f000;// j=0 and bw=0 no interpolation
			else
				f010 = buff[( ind3 - ( size + 2 ) )];
			if ( k == 0 ) f001 = buff[( ind3 + size - 1 )];
			else
				f001 = buff[( ind3 - 1 )];
			if ( k == size - 1 ) f002 = buff[ind2];
			else
				f002 = buff[( ind3 + 1 )];


			nf000=f000;
			if ( nf000 < f100)  { nf000 = f100; if (i==0) i=size-1; else i--;}
			if ( nf000 < f200)  { nf000 = f200; if (i==size-1) i=0; else i++;}
			//if ( nf000 < f010)  { nf000 = f010; if (j==0) j=size-1; else j--;}
			//if ( nf000 < f020)  { nf000 = f020; if (j==size-1) j=0; else j++;}
			if ( nf000 < f010)  { nf000 = f010; if (j==0) j=0; else j--;}
			if ( nf000 < f020)  { nf000 = f020; if (j==bw) j=bw; else j++;}
			if ( nf000 < f001)  { nf000 = f001; if (k==0) k=size-1; else k--;}
			if ( nf000 < f002)  { nf000 = f002; if (k==size-1) k=0; else k++;}
		}

		if (nf000!=f000) {
			correlation = nf000/ norm;
			phe = ( i ) * M_PI / bw;
			phc = ( j ) * M_PI / bw;
			ohm = ( k ) * M_PI / bw;

		}

		else {

			tempi = 0.0; tempj = 0.0; tempk = 0.0;

			if ( ( f000 > f100 ) && ( f000 > f200 ) )
				if ( ( temp = f100 + f200 - 2 * f000 ) != 0 )
					tempi = ( f100 - f200 ) / ( 2 * temp );
			phe = ( i + tempi ) * M_PI / bw;


			if (j!=0)
				if ( ( f000 > f010 ) && ( f000 > f020 ) )
					if ( ( temp = f010 + f020 - 2 * f000 ) != 0 )
						tempj = ( f010 - f020 ) / ( 2 * temp );
			phc = ( j + tempj ) * M_PI / bw;

			if (phc>M_PI) { phc=M_PI; tempj=0.0; }
			else if (phc<0.0) { phc=0.000000; tempj=0.0; }

			if ( ( f000 > f001 ) && ( f000 > f002 ) )
				if ( ( temp = f001 + f002 - 2 * f000 ) != 0 )
					tempk = ( f001 - f002 ) / ( 2 * temp );
			ohm = ( k + tempk ) * M_PI / bw;

			//printf("tempi=%f tempj=%f tempk=%f\n", tempi, tempj, tempk);





			correlation = ( 0.5 * ( f100 + f200 ) - f000 ) * tempi * tempi +  0.5 * ( f200 - f100 ) * tempi +
					( 0.5 * ( f010 + f020 ) - f000 ) * tempj * tempj +  0.5 * ( f020 - f010 ) * tempj +
					( 0.5 * ( f001 + f002 ) - f000 ) * tempk * tempk +  0.5 * ( f002 - f001 ) * tempk +
					f000;

			correlation /= norm;

		}




		psi = -phe; psi = psi - 2.0 * M_PI * floor( psi / 2.0 / M_PI );
		th = M_PI - phc; //th=th-2.0*M_PI*floor(th/2.0/M_PI);
		phi = M_PI - ohm; phi = phi - 2.0 * M_PI * floor( phi / 2.0 / M_PI );



		corr[0] [0] = correlation;
		corr[1] [0] = psi;
		corr[2] [0] = th;
		corr[3] [0] = phi;
		corr[4] [0] = i;
		corr[5] [0] = j;
		corr[6] [0] = k;
	}
	else
	{
		ind1 = i * size2;
		ind2 = ind1 + j * ( size + 2 );
		ind3 = ind2 + k;
		f000 = buff[ind3];

		phe = ( i ) * M_PI / bw;
		phc = ( j ) * M_PI / bw;
		ohm = ( k ) * M_PI / bw;
		psi = -phe;
		psi = psi - 2.0 * M_PI * floor( psi / 2.0 / M_PI );
		th = M_PI - phc;
		//th=th-2.0*M_PI*floor(th/2.0/M_PI);
		phi = M_PI - ohm;
		phi = phi - 2.0 * M_PI * floor( phi / 2.0 / M_PI );

		corr[0] [0] = f000 / norm;
		corr[1] [0] = psi;
		corr[2] [0] = th;
		corr[3] [0] = phi;
		corr[4] [0] = i;
		corr[5] [0] = j;
		corr[6] [0] = k;
		return;
	}

}

/******************************************/
float distance_eulers( float psi, float th, float phi, unsigned long j, float * corr[] )
{
	/* returns the distance between the rotations given by the Euler angles in corr[1,2,3][i] and corr[1,2,3][j] */

	float matrix1[3] [3], matrix2[3] [3];
	int k, l;
	float temp, trace;

	get_rot_matrix( matrix1, psi, th, phi );
	get_rot_matrix( matrix2, corr[1] [j], corr[2] [j], corr[3] [j] );


	trace = 0.0;
	/* trace(matrix1*transpose(matrix2)) */
	for ( k = 0; k < 3; k++ )
		for ( l = 0; l < 3; l++ )
			trace += matrix1[k] [l] * matrix2[k] [l];

	temp = 0.5 * ( trace - 1.0 );
	if ( temp >= 1.0 )
		return 0.0;
	if ( temp <= -1.0 )
		return M_PI;
	return acos( temp );
}
/**********************************************/
float distance_eulers( float matrix_sol[3][3], unsigned long j, float ***matrix )
{
	/* returns the distance between the rotations given by the Euler angles in corr[1,2,3][i] and corr[1,2,3][j] */

	int k, l;
	float temp, trace;



	trace = 0.0;
	/* trace(matrix1*transpose(matrix2)) */
	for ( k = 0; k < 3; k++ )
		for ( l = 0; l < 3; l++ )
			trace += matrix_sol[k] [l] * matrix[j][k] [l];

	temp = 0.5 * ( trace - 1.0 );
	if ( temp >= 1.0 )
		return 0.0;
	if ( temp <= -1.0 )
		return M_PI;
	return acos( temp );
}
/**********************************************/
float distance_eulers( unsigned long i, unsigned long j, float * corr[] )
{
	/* returns the distance between the rotations given by the Euler angles in corr[1,2,3][i] and corr[1,2,3][j] */

	float matrix1[3] [3], matrix2[3] [3];
	int k, l;
	float temp, trace;

	get_rot_matrix( matrix1, corr[1] [i], corr[2] [i], corr[3] [i] );
	get_rot_matrix( matrix2, corr[1] [j], corr[2] [j], corr[3] [j] );


	trace = 0.0;
	/* trace(matrix1*transpose(matrix2)) */
	for ( k = 0; k < 3; k++ )
		for ( l = 0; l < 3; l++ )
			trace += matrix1[k] [l] * matrix2[k] [l];

	temp = 0.5 * ( trace - 1.0 );
	if ( temp >= 1.0 )
		return 0.0;
	if ( temp <= -1.0 )
		return M_PI;
	return acos( temp );
}

/**  */

void get_rot_matrix( float dump[3] [3], float psi, float theta, float phi )
{
	/* computes rotation matrix based on Euler angles psi, theta, phi in radians */

	float sin_psi = sin( psi );
	float cos_psi = cos( psi );
	float sin_theta = sin( theta );
	double cos_theta = cos( theta );
	double sin_phi = sin( phi );
	double cos_phi = cos( phi );

	/* use Goldstein convention */
	dump[0] [0] = cos_psi * cos_phi - cos_theta * sin_phi * sin_psi;
	dump[0] [1] = cos_psi * sin_phi + cos_theta * cos_phi * sin_psi;
	dump[0] [2] = sin_psi * sin_theta;
	dump[1] [0] = -sin_psi * cos_phi - cos_theta * sin_phi * cos_psi;
	dump[1] [1] = -sin_psi * sin_phi + cos_theta * cos_phi * cos_psi;
	dump[1] [2] = cos_psi * sin_theta;
	dump[2] [0] = sin_theta * sin_phi;
	dump[2] [1] = -sin_theta * cos_phi;
	dump[2] [2] = cos_theta;
}

bool distance_motions_tr( float * buf1[], float * buf2[], int a,
		int b, float x, float y, float z, float limit_angle, float limit_trans )
{
	/* returns the distance between the rotations given by the Euler angles in corr[1,2,3][i] and corr[1,2,3][j] */

	float matrix1[3] [3], matrix2[3] [3];
	int k, l;
	float temp, trace, norm_ang, norm_tran;

	norm_tran = 0;

	norm_tran += pow( ( float )( x - buf2[4] [b] ), 2 );
	norm_tran += pow( ( float )( y - buf2[5] [b] ), 2 );
	norm_tran += pow( ( float )( z - buf2[6] [b] ), 2 );

	// fprintf(stderr,"dist %f  %f %f %f  %f %f %f\n", norm_tran, x, y, z, buf2[4] [b], buf2[5] [b],buf2[6] [b]);

	if ( sqrt(norm_tran) >= limit_trans )  return false;

	else {

		get_rot_matrix( matrix1, buf1[1] [a], buf1[2] [a], buf1[3] [a] );
		get_rot_matrix( matrix2, buf2[1] [b], buf2[2] [b], buf2[3] [b] );


		trace = 0.0;
		/* trace(matrix1*transpose(matrix2)) */
		for ( k = 0; k < 3; k++ )
			for ( l = 0; l < 3; l++ )
				trace += matrix1[k] [l] * matrix2[k] [l];

		temp = 0.5 * ( trace - 1.0 );
		if ( temp >= 1.0 )
			norm_ang = 0.0;
		else if ( temp <= -1.0 )
			norm_ang = M_PI;
		else norm_ang = acos( temp );

	}

	// fprintf(stderr,"dist %f  %f %f %f  %f %f %f\n", norm_ang, buf1[1] [a], buf1[2] [a], buf1[3] [a], buf2[1] [b], buf2[2] [b],buf2[3] [b]);

	if (norm_ang >= limit_angle* M_PI / 180.0)  return false;
	return true;

}

bool distance_motions_trc( float * buf1[], float * buf2[], int a,
		int b, float limit_angle, float limit_trans )
{
	/* returns the distance between the rotations given by the Euler angles in corr[1,2,3][i] and corr[1,2,3][j] */

	float matrix1[3] [3], matrix2[3] [3];
	int k, l;
	float temp, trace, norm_ang, norm_tran;

	norm_tran = 0;

	norm_tran += pow( ( float )( buf2[4] [a] - buf2[4] [b] ), 2 );
	norm_tran += pow( ( float )( buf2[5] [a] - buf2[5] [b] ), 2 );
	norm_tran += pow( ( float )( buf2[6] [a] - buf2[6] [b] ), 2 );

	/*
   fprintf(stderr,"dist %f  %f %f %f  %f %f %f\n", norm_tran,
  buf2[4] [a], buf2[a] [b],buf2[6] [a],
  buf2[4] [b], buf2[5] [b],buf2[6] [b]);
	 */
	if ( sqrt(norm_tran) >= limit_trans )  return false;

	else {

		get_rot_matrix( matrix1, buf1[1] [a], buf1[2] [a], buf1[3] [a] );
		get_rot_matrix( matrix2, buf2[1] [b], buf2[2] [b], buf2[3] [b] );


		trace = 0.0;
		/* trace(matrix1*transpose(matrix2)) */
		for ( k = 0; k < 3; k++ )
			for ( l = 0; l < 3; l++ )
				trace += matrix1[k] [l] * matrix2[k] [l];

		temp = 0.5 * ( trace - 1.0 );

		//fprintf(stderr,"temp %f  %f %f %f  %f %f %f\n", temp,
		//buf1[1] [a]* M_PI / 180.0, buf1[2] [a]* M_PI / 180.0, buf1[3] [a]* M_PI / 180.0,
		//buf2[1] [b]* M_PI / 180.0, buf2[2] [b]* M_PI / 180.0, buf2[3] [b]* M_PI / 180.0);


		if ( temp >= 1.00 )
			norm_ang = 0.0;
		else if ( temp <= -1.00 )
			norm_ang = M_PI;
		else norm_ang = acos( temp );

		// fprintf(stderr,"ang %f temp %f  %f %f %f\n", norm_ang, temp);

	}

	if (norm_ang >= limit_angle* M_PI / 180.0)  return false;
	return true;

}







int best_solutions( float * corr[], int npeaks, float * corr_max[], int nsolut, float ii, float jj, float kk,
		float unit, float dist_cut_rot,float  dist_cut_trans)
{
	int indexS = 0;
	int indexP = 0;
	int i, p, pos,m;
	bool saltar;



	// only compare values > that the minumium max stored
	for ( pos = npeaks-1; pos >= 0; pos-- )
		if ( corr_max[0] [nsolut-1] < corr[0] [pos] ) break;

	npeaks=pos+1;
	// if (npeaks==0) return nsolut;


	while ( indexS < nsolut && indexP < npeaks )
	{
		saltar = false;
		for ( p = 0; p < nsolut && !saltar; p++ )
		{
			if (distance_motions_tr( corr, corr_max, indexP, p, ii, jj, kk, dist_cut_rot, dist_cut_trans))
			{


				if ( corr_max[0] [p] > corr[0] [indexP] ) {
					saltar = true;
				}
				else
				{

					// is duplicate but is better
					saltar = true;
					// sort
					for ( pos = 0; pos < p; pos++ )
						if ( corr[0] [indexP] > corr_max[0] [pos] ) break;

					// pos is the position to include the new peak
					// move the list down till n (that will overwrote)

					for ( m = 0; m < p-pos; m++ )
						for ( i = 0; i < 10; i++ )
							corr_max[i] [p-m] = corr_max[i] [p-m-1];


					// copy on pos...
					for ( i = 0; i < 4; i++ )
						corr_max[i] [pos] = corr[i] [indexP];
					corr_max[7] [pos] = corr[4] [indexP];
					corr_max[8] [pos] = corr[5] [indexP];
					corr_max[9] [pos] = corr[6] [indexP];
					corr_max[4] [pos] = ii;
					corr_max[5] [pos] = jj;
					corr_max[6] [pos] = kk;




				}

				indexP++;
			}
		}


		if ( !saltar ) // add solution
		{

			if ( corr_max[0] [indexS] >= corr[0] [indexP] )
				indexS++;
			else
			{

				for ( pos = 0; pos < nsolut; pos++ )
					if ( corr[0] [indexP] > corr_max[0] [pos]) break;


				for ( m = nsolut-1; m > pos; m-- )
					for ( i = 0; i < 10; i++ )
						corr_max[i] [m] = corr_max[i] [m - 1];

				// copy on pos...
				for ( i = 0; i < 4; i++ )
					corr_max[i] [pos] = corr[i] [indexP];
				corr_max[7] [pos] = corr[4] [indexP];
				corr_max[8] [pos] = corr[5] [indexP];
				corr_max[9] [pos] = corr[6] [indexP];
				corr_max[4] [pos] = ii;
				corr_max[5] [pos] = jj;
				corr_max[6] [pos] = kk;


				indexP++;
				indexS++;

			}
		}
	}


	for ( i = 0; i < nsolut; i++ )
	{
		if ( corr_max[0] [i] == 0 )
			return i;
	}

	return i;
}




void shp2cart( float rad, float alpha, float betha, float * posx, float * posy, float * posz, float cx, float cy, float cz )
{
	* posx = cx + rad * sin( alpha ) * cos( betha );
	* posy = cy + rad * sin( alpha ) * sin( betha );
	* posz = cz + rad * cos( alpha );

}





