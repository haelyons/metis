#include <stdlib.h>
#include <string.h>

#ifdef MPI_RELEASE
#include "mpi.h"
#endif

#include "SCollection.h"


#include <libfrm/include/Correlation.h>

#define INFINITY_PP 100000000000000.0



SCollection::SCollection(int in_point, int in_total, float in_rcut, float in_tcut,int in_bw, float in_voxsize, vlPoint3f in_origin)
{
  int i,j;
  n_point=in_point;
  n_solutions=in_total;
  rcut=in_rcut;
  tcut=in_tcut;
  bw=in_bw;
  voxsize=in_voxsize;
  origin[0]=in_origin.x();
  origin[1]=in_origin.y();
  origin[2]=in_origin.z();


  totalPeaks=0;

  for ( i = 0; i < 4; i++ )
  	solutions_in_point[i] = ( float * ) malloc( sizeof( float ) * n_point );

  matrix=(float***)malloc(sizeof(float**)*n_point);
  for(i=0;i<n_point;i++)
  {
	  matrix[i]=(float**)malloc(sizeof(float*)*3);
	  for(j=0;j<3;j++)
	  {
	  	matrix[i][j]=(float*)malloc(sizeof(float)*3);
	  }
  }

  for ( i = 0; i < 7; i++ )
  {
    best_solutions_found[i] = ( float * ) malloc( sizeof( float ) * n_solutions );
    memset( best_solutions_found[i], 0, sizeof( float ) * n_solutions );
  }
}

SCollection::~SCollection()
{
	int i,j;

  for ( i = 0; i < 4; i++ )
   {
	  free( solutions_in_point[i]);
   }

  for(i=0;i<n_point;i++)
    {
  	  for(j=0;j<3;j++)
  	  {
  	  	free(matrix[i][j]);
  	  }
  	  free(matrix[i]);
    }
  free(matrix);

  for ( i = 0; i < 7; i++ )
   free(best_solutions_found[i]);

}

bool SCollection::insert(float * correlation,Tcoor point)
{
	int npeaks_found,i;

	npeaks_found = best_angles_lI( correlation, matrix, bw, 2 * bw, rcut * 1.0,
                     solutions_in_point, 1, n_point );



	//Seleccion de soluciones en la capa
  if ( npeaks_found > 0 && solutions_in_point[0] [0] > 0 )
  {
    //fprintf( density2, "ATOM%7d  N   GLY A 735    %8.2f%8.2f%8.2f  1.00 %6.3f           N\n", cont_density,
    //Xpoint_voxels * voxSize + origin_receptor.x(), Ypoint_voxels * voxSize + origin_receptor.y(),
    //Zpoint_voxels * voxSize + origin_receptor.z(), solutions_in_point[0] [0] );

	//if (solutions_in_point[0] [0]>best_solutions_found[0][0])
	// fprintf(stderr,"npeaks=%d %f\n",npeaks_found,solutions_in_point[0] [0]);

    best_solutions( solutions_in_point, npeaks_found, best_solutions_found, n_solutions, point[0],
                   point[1], point[2], 1.0, rcut, tcut );

    totalPeaks += npeaks_found;
    if ( totalPeaks > n_solutions )
    	totalPeaks = n_solutions;

  	totalPeaks=0;
  	for(i=0;i<n_solutions;i++)
  	{
  		if(best_solutions_found[0] [i]>0)
  			totalPeaks++;
  		else
  			return true;
  	}

  	return true;
  }


	return false;
}


//bool SCollection::insert_all2(float * sp[],Tcoor point, int npeaks_found, float threshold)
bool SCollection::insert_all2(float * sp[],Tcoor point, int npeaks_found, float threshold)
{
	int i,j;

	/*for(i=0;i<n_point;i++)

		{

			fprintf(stderr,"-->%d %7.3f  %7.3f %7.3f %7.3f  \n",
			    						i, sp[0][i],
			    						sp[1][i]*180/3.1415297,
			    						sp[2][i]*180/3.1415297,
			    						sp[3][i]*180/3.1415297);
		}*/



	  if ( npeaks_found > 0 && sp[0] [0] > threshold )
	  {
	    for(j=0;j<npeaks_found;j++)
	    {
				if(sp[0][j] >threshold)
				{
					if(totalPeaks>n_solutions)
					{
						fprintf(stderr,"There is no space for more solutions\n");
						return false;
					}
	    		for ( i = 0; i < 4; i++ )
				best_solutions_found[i] [totalPeaks] = sp[i] [j];
			  	best_solutions_found[4] [totalPeaks] = point[0];
			  	best_solutions_found[5] [totalPeaks] = point[1];
			  	best_solutions_found[6] [totalPeaks] = point[2];
			  	totalPeaks++;
				}
	    }
	  }




   	return true;
  }


bool SCollection::insert_all(float * correlation,Tcoor point, float threshold)
{
	int npeaks_found,i,j;


	npeaks_found = best_angles_lI( correlation, matrix,bw, 2 * bw, rcut * 1.0,
                     solutions_in_point, 1, n_point );
   // fprintf(stderr,"npeaks=%d %f\n",npeaks_found,solutions_in_point[0] [0]);
	//Seleccion de soluciones en la capa
  if ( npeaks_found > 0 && solutions_in_point[0] [0] > threshold )
  {
    for(j=0;j<npeaks_found;j++)
    {
			if(solutions_in_point[0][j] >threshold)
			{
				if(totalPeaks>n_solutions)
				{
					fprintf(stderr,"There is no space for more solutions\n");
					return false;
				}
    		for ( i = 0; i < 4; i++ )
					best_solutions_found[i] [totalPeaks] = solutions_in_point[i] [j];
		  	best_solutions_found[4] [totalPeaks] = point[0];
		  	best_solutions_found[5] [totalPeaks] = point[1];
		  	best_solutions_found[6] [totalPeaks] = point[2];
		  					totalPeaks++;
			}
    }

   	return true;
  }


	return false;
}



void SCollection::show_solutions(int option,Macromolecule * ligand,char *in_ref)
{
	int i,j;
	float min_distance,min_distance10,min_distance5,min_distance100, min_distance1000,min_distance2000,min_distance5000;
	int solution,solution10,solution5,solution100,solution1000,solution2000,solution5000;
	float min_distances[10];
	int min_pos[10];
	Tcoor dzpl;
	float rmsd_distance;
	char out_string[20];
	Macromolecule * ligand2;
  EulerRot * rot;
  //calculo del desplazamiento que hay que realizar para centrar sobre el centro
  //de masas del volumen en baja resolucion el origen de coordenad as
  min_distance = INFINITY_PP;
  min_distance10 = INFINITY_PP;
  min_distance5 = INFINITY_PP;
  min_distance100 = INFINITY_PP;
  min_distance1000 = INFINITY_PP;
  min_distance2000 = INFINITY_PP;
  Macromolecule * ligand_ref = new Macromolecule();

	//Fichero para representar la distribucion de soluciones
	//FILE *solution_distribution=fopen("solution_distribution.txt","wt");


  if ( in_ref!=NULL )
  {
    ligand_ref->readPDB( in_ref );
    //mol3->eraseAllH();
  }

  //FILE * density;
  int npeaksTotal = 0;
  for ( i = 0; i < 10; i++ ) min_distances[i] = 10000;

  for ( i = 0; i < totalPeaks && best_solutions_found[0] [i] > 0.0; i++ )
  {
    npeaksTotal++;
    //calculo del desplazamiento que hay que realizar para centrar en el origen
    //el centro de masas seleccionado en la solucion
     dzpl[0] = best_solutions_found[4] [i] * voxsize + origin[0];
     dzpl[1] = best_solutions_found[5] [i] * voxsize + origin[1];
     dzpl[2] = best_solutions_found[6] [i] * voxsize + origin[2];
    //dzpl[0] = best_solutions_found[4] [i] * voxsize + origin[0] + voxsize/2.0;
    //dzpl[1] = best_solutions_found[5] [i] * voxsize + origin[1] + voxsize/2.0;
    //dzpl[2] = best_solutions_found[6] [i] * voxsize + origin[2] + voxsize/2.0;
    best_solutions_found[4] [i] = dzpl[0];
    best_solutions_found[5] [i] = dzpl[1];
    best_solutions_found[6] [i] = dzpl[2];

		if(ligand!=NULL)
		{
		//copia de estructura PDB original
    	ligand2 = new Macromolecule( ligand );
    	//rotacion del pdb segun la solucion
    	rot = new EulerRot( best_solutions_found[1] [i], best_solutions_found[2] [i], best_solutions_found[3] [i] );
    	ligand2->applyAtoms( rot );
    	//movimiento del pdb de forma que el centro de masas del pdb (que estaba en el
    	//origen) pasa a estar sobre el centro de masas del volumen en baja resolucion
    	ligand2->moveAll( dzpl );
		}

    if ( in_ref!=NULL )
    {
     rmsd_distance = ligand2->rmsd( ligand_ref );


     fprintf( stdout, "%3d  %6.2f  %6.2f   %6.2f  %6.2f  %6.2f  %6.2f    %9.6f     %9.6f %9.6f(%d)\n", i + 1,
         best_solutions_found[1] [i] * 180 / M_PI,
         best_solutions_found[2] [i] * 180 / M_PI,
         best_solutions_found[3] [i] * 180 / M_PI,  best_solutions_found[4] [i],
         best_solutions_found[5] [i], best_solutions_found[6] [i], best_solutions_found[0] [i], rmsd_distance,min_distance,solution);


    }
    else
    {
			fprintf( stdout, "%3d  %6.2f  %6.2f   %6.2f  %6.2f  %6.2f  %6.2f    %9.6f\n", i + 1,
         best_solutions_found[1] [i] * 180 / M_PI,
         best_solutions_found[2] [i] * 180 / M_PI,
         best_solutions_found[3] [i] * 180 / M_PI,  best_solutions_found[4] [i],
         best_solutions_found[5] [i], best_solutions_found[6] [i], best_solutions_found[0] [i]);

    }

    //Escritura de distribucion de soluciones
    //fprintf( solution_distribution, "ATOM%7d  N   GLY A 735    %8.2f%8.2f%8.2f  1.00 %6.3f           N\n", i, dzpl[0], dzpl[1], dzpl[2],
        // best_solutions_found[0] [i] );


    if ( in_ref!=NULL )
    {
      //Mejor solucion entre 10 1ªs
      if ( rmsd_distance < min_distance10 && i<10 )
    	{
      	min_distance10 = rmsd_distance;
      	solution10 = i + 1;
    	}

    	//Mejor solucion entre 100 1ªs
      if ( rmsd_distance < min_distance100 && i<100 )
    	{
      	min_distance100 = rmsd_distance;
      	solution100 = i + 1;
    	}

      //Mejor solucion entre 1000 1ªs
      if ( rmsd_distance < min_distance1000 && i<1000 )
    	{
      	min_distance1000 = rmsd_distance;
      	solution1000 = i + 1;
    	}

    	//Mejor solucion entre 2000 1ªs
      if ( rmsd_distance < min_distance2000 && i<2000 )
    	{
      	min_distance2000 = rmsd_distance;
      	solution2000 = i + 1;
    	}

      //1ª Mejor solucion menor que 5
      if ( (rmsd_distance < 5.0) &&  (min_distance5>(INFINITY_PP-1)))
    	{
      	min_distance5 = rmsd_distance;
      	solution5 = i + 1;
    	}


      //mejor solucion
      if ( rmsd_distance < min_distance )
    	{
      	min_distance = rmsd_distance;
      	solution = i + 1;
    	}

      for ( j = 0; j < 10; j++ )
      {
        if ( min_distances[j] > rmsd_distance )
        {
          for ( int k = 9; k > j; k-- )
          {
            min_distances[k] = min_distances[k - 1];
            min_pos[k] = min_pos[k - 1];
          }
          min_distances[j] = rmsd_distance;
          min_pos[j] = i;
          j = 20;
        }
      }
    }
    else
    {
      if(i<10 && ligand!=NULL)
      {
      	sprintf( out_string, "adp_ppe_best%d.pdb", i + 1 );
      	ligand2->writePDB( out_string );
      }
    }
	 /*if(ligand!=NULL)
	 {
    delete ligand2;
    delete rot;
	 }*/
  }



  //Escritura del fichero
  if ( in_ref!=NULL )
    for ( i = 0; i < 10 && i < totalPeaks; i++ )
    {

      Macromolecule * ligand2 = new Macromolecule( ligand );

      dzpl[0] = best_solutions_found[4] [min_pos[i]];
      dzpl[1] = best_solutions_found[5] [min_pos[i]];
      dzpl[2] = best_solutions_found[6] [min_pos[i]];
      //rotacion del pdb segun la solucion

      EulerRot * rot = new EulerRot( best_solutions_found[1] [min_pos[i]], best_solutions_found[2] [min_pos[i]],
           best_solutions_found[3] [min_pos[i]] );

      ligand2->applyAtoms( rot );
      ligand2->moveAll( dzpl );

      sprintf( out_string, "adp_ppe_best%d.pdb", min_pos[i] + 1 );
      ligand2->writePDB( out_string );

      delete ligand2;
      delete rot;
    }

	if(min_distance5>(INFINITY_PP-1))
		min_distance5=-1;
if(min_distance100>(INFINITY_PP-1))
		min_distance100=-1;
if(min_distance1000>(INFINITY_PP-1))
		min_distance1000=-1;
if(min_distance2000>(INFINITY_PP-1))
		min_distance2000=-1;

  if ( in_ref!=NULL )
	{
		if(option==0)
		  fprintf( stdout, "%10d | %5d %8.3f | %5d %8.3f | %5d %8.3f \n", npeaksTotal, solution, min_distance,solution10, min_distance10,solution5, min_distance5 );
		else
		  fprintf( stdout, "%10d | %5d %8.3f | %5d %8.3f | %5d %8.3f | %5d %8.3f \n", npeaksTotal, solution100, min_distance100,solution1000, min_distance1000,solution2000, min_distance2000, solution, min_distance);
	}
	//fclose(solution_distribution);
//END STEP 9
}

void SCollection::write_solutions(char *output,bool append)
{
	int i;
	Tcoor dzpl;
  int npeaksTotal = 0;
  float buffer[7];
	FILE *f;


	if(!append)
  	f=fopen(output,"wb");
  else
  	f=fopen(output,"rb+");




	if(append)
	{
		fseek ( f, 0, SEEK_SET );
		fread(&npeaksTotal,  sizeof(int),  1, f);
		fread(&Lorigin,  sizeof(float),  3, f);
		npeaksTotal+=totalPeaks;
		fseek ( f, 0, SEEK_SET );
		fwrite(&npeaksTotal,  sizeof(int),  1, f);
		fwrite(&Lorigin,  sizeof(float),  3, f);
		fseek ( f, 0, SEEK_SET );
		npeaksTotal=0;
		fread(&npeaksTotal,  sizeof(int),  1, f);
		fread(&Lorigin,  sizeof(float),  3, f);
		fseek ( f, 0, SEEK_END );
	}
 	else
 	{
 		npeaksTotal=totalPeaks;
		fwrite(&npeaksTotal,  sizeof(int),  1, f);
		fwrite(&Lorigin[0],  sizeof(float),  3, f);

 	}


  // fprintf(stderr,"dzpl: %f %f %f %f\n",voxsize*1.0, Lorigin[0],Lorigin[1],Lorigin[2]);

  for ( i = 0; i < totalPeaks; i++ )
  {
    //calculo del desplazamiento que hay que realizar para centrar en el origen
    //el centro de masas seleccionado en la solucion
    dzpl[0] = best_solutions_found[4] [i] * voxsize + origin[0]; // + voxsize/2.0;
    dzpl[1] = best_solutions_found[5] [i] * voxsize + origin[1]; // + voxsize/2.0;
    dzpl[2] = best_solutions_found[6] [i] * voxsize + origin[2]; // + voxsize/2.0;

    //best_solutions_found[4] [i] = dzpl[0];
    //best_solutions_found[5] [i] = dzpl[1];
    //best_solutions_found[6] [i] = dzpl[2];

		buffer[0]=best_solutions_found[1] [i] * 180 / M_PI;
		buffer[1]=best_solutions_found[2] [i] * 180 / M_PI;
		buffer[2]=best_solutions_found[3] [i] * 180 / M_PI;
		buffer[3]=dzpl[0];//best_solutions_found[4] [i];
		buffer[4]=dzpl[1];//best_solutions_found[5] [i];
		buffer[5]=dzpl[2];//best_solutions_found[6] [i];
		buffer[6]=best_solutions_found[0] [i];

		fwrite(buffer,sizeof(float),7,f);

  }
	fclose(f);
}

void SCollection::write_solutions_buffer(float **output)
{
	int i;
	Tcoor dzpl;

  *output=(float*)malloc(sizeof(float)*7*totalPeaks);

  for ( i = 0; i < totalPeaks; i++ )
  {
    //calculo del desplazamiento que hay que realizar para centrar en el origen
    //el centro de masas seleccionado en la solucion
    dzpl[0] = best_solutions_found[4] [i] * voxsize + origin[0]; // + voxsize/2.0;
    dzpl[1] = best_solutions_found[5] [i] * voxsize + origin[1]; // + voxsize/2.0;
    dzpl[2] = best_solutions_found[6] [i] * voxsize + origin[2]; // + voxsize/2.0;
    //fprintf(stderr,"dzpl: %f %f %f\n",dzpl[0],dzpl[1],dzpl[2]);
    //best_solutions_found[4] [i] = dzpl[0];
    //best_solutions_found[5] [i] = dzpl[1];
    //best_solutions_found[6] [i] = dzpl[2];

    (*output)[i*7]=best_solutions_found[1] [i] * 180 / M_PI;
    (*output)[i*7+1]=best_solutions_found[2] [i] * 180 / M_PI;
    (*output)[i*7+2]=best_solutions_found[3] [i] * 180 / M_PI;
    (*output)[i*7+3]=dzpl[0];//best_solutions_found[4] [i];
    (*output)[i*7+4]=dzpl[1];//best_solutions_found[5] [i];
    (*output)[i*7+5]=dzpl[2];//best_solutions_found[6] [i];
    (*output)[i*7+6]=best_solutions_found[0] [i];

  }
}
  void SCollection::write_solutions_frodrug(int prnumber, float *output)
  {
  	int i; int p5;



    for ( i = 0; i < totalPeaks; i++ )
    {  p5=i*9;
      *(output +p5)=    best_solutions_found[0] [i];
      *(output +p5+1)=  best_solutions_found[1] [i] * 180 / M_PI;
      *(output +p5+2)=  best_solutions_found[2] [i] * 180 / M_PI;
      *(output +p5+3)=  best_solutions_found[3] [i] * 180 / M_PI;
      *(output +p5+4) = best_solutions_found[4] [i] * voxsize + origin[0]; // + voxsize/2.0;
      *(output +p5+5) = best_solutions_found[5] [i] * voxsize + origin[1]; // + voxsize/2.0;
      *(output +p5+6) = best_solutions_found[6] [i] * voxsize + origin[2]; // + voxsize/2.0;
      *(output +p5+7) = prnumber;


      // best_solutions_found[0] [i]=-999;
    }

}
  void SCollection::clear_solutions()
   {

     for (int i = 0; i < totalPeaks; i++ )
     {
      best_solutions_found[0] [i]=-999;
     }
     totalPeaks=0;
 }
void SCollection::convert_solutions(float *position)
{
	int i;
	float new_dzpl[3];
	float matrix[3] [3];
	for ( i = 0; i < totalPeaks; i++ )
	{
		get_rot_matrix( matrix, best_solutions_found[1][i], best_solutions_found[2][i], best_solutions_found[3][i] );


		new_dzpl[0]= best_solutions_found[4][i] *matrix[0][0] + best_solutions_found[5][i]*matrix[0][1] + best_solutions_found[6][i]*matrix[0][2];
		new_dzpl[1]= best_solutions_found[4][i] *matrix[1][0] + best_solutions_found[5][i]*matrix[1][1] + best_solutions_found[6][i]*matrix[1][2];
		new_dzpl[2]= best_solutions_found[4][i] *matrix[2][0] + best_solutions_found[5][i]*matrix[2][1] + best_solutions_found[6][i]*matrix[2][2];

		//new_dzpl[0]= best_solutions_found[4][i];
		//new_dzpl[1]= best_solutions_found[5][i];
		//new_dzpl[2]= best_solutions_found[6][i];

		best_solutions_found[4][i]=position[0]-new_dzpl[0];
		best_solutions_found[5][i]=position[1]-new_dzpl[1];
		best_solutions_found[6][i]=position[2]-new_dzpl[2];
		//fprintf(stderr,"best_solution_found: %f %f %f\n",best_solutions_found[4][i],best_solutions_found[5][i],best_solutions_found[6][i]);

	}


}

/*

void SCollection::read(char *name)
{
	FILE *f;
	int i;
	f=fopen(name,"wb");

	fread(&n_point, sizeof(int),  1, f);
	fread(&n_solutions, sizeof(int),  1, f);
	fread(&rcut, sizeof(float),  1, f);
	fread(&tcut, sizeof(float),  1, f);
	fread(&bw, sizeof(int),  1, f);
	fread(&totalPeaks, sizeof(int),  1, f);

	for(i=0;i<7;i++)
	{
			solutions_in_point[i] = ( float * ) realloc(solutions_in_point[i], sizeof( float ) * n_point );
			fread(solutions_in_point[i], sizeof(float),  n_point, f);
	}
	for(i=0;i<10;i++)
	{
				best_solutions_found[i] = ( float * ) realloc(best_solutions_found[i], sizeof( float ) * n_solutions );
				fwrite(best_solutions_found[i], sizeof(float),  n_point, f);
	}

	fclose(f);
}
void SCollection::write(char *name)
{
	FILE *f;
	int i;
	f=fopen(name,"wb");

	fwrite(&n_point, sizeof(int),  1, f);
	fwrite(&n_solutions, sizeof(int),  1, f);
	fwrite(&rcut, sizeof(float),  1, f);
	fwrite(&tcut, sizeof(float),  1, f);
	fwrite(&bw, sizeof(int),  1, f);
	fwrite(&totalPeaks, sizeof(int),  1, f);

	for(i=0;i<7;i++)
			fwrite(solutions_in_point[i], sizeof(float),  n_point, f);
	for(i=0;i<10;i++)
			fwrite(best_solutions_found[i], sizeof(float),  n_point, f);


	fclose(f);

}*/

#ifdef MPI_RELEASE



void SCollection::send_mpi(int id_r )
{
	int i;
	float *buffer,*buffer2;
	buffer = ( float * ) malloc( sizeof( float ) * totalPeaks * 7 );


	for(i=0;i<7;i++)
	{
		buffer2=buffer+(i*totalPeaks);
		memcpy(buffer2, best_solutions_found[i], totalPeaks*sizeof(float));
	}

	MPI_Send(&totalPeaks,1,MPI_INT,id_r,0,MPI_COMM_WORLD);

	MPI_Send(buffer,totalPeaks * 7,MPI_FLOAT,id_r,1,MPI_COMM_WORLD);

	free(buffer);
}

void SCollection::recv_mpi(int id_s)
{
	MPI_Status status;
	int i,count;
	float *buffer,*buffer2;


	buffer = ( float * ) malloc( sizeof( float ) *  n_solutions * 7 );

	MPI_Recv(&count,1,MPI_INT,id_s,0,MPI_COMM_WORLD,&status);


	MPI_Recv(buffer,count * 7,MPI_FLOAT,id_s,1,MPI_COMM_WORLD,&status);


	insert_solutions(buffer,count);

	free(buffer);
}

void SCollection::insert_solutions(float *buffer,int count)
{
	int i,j,k,l;
	bool inserted;

	for(i=0;i<count;i++)
	{

				if(totalPeaks<n_solutions)
				{
					for(l=0;l<7;l++)
				  {
						best_solutions_found[l][totalPeaks]=buffer[i+l*count];
				  }
					totalPeaks++;
				}


	}
}

#endif
