#include "PointVoxel.h"

PointVoxel::PointVoxel(float *p,float vC, float vF)
{
	point[0] = p[0];
	point[1] = p[1];
	point[2] = p[2];
	valueClose = vC;
	valueFar = vF;
	SHRe = 0;
	SHIm = 0;
}

PointVoxel::~PointVoxel(void)
{
}

bool PointVoxel::operator<(PointVoxel& p)
{
	return valueClose < p.valueClose;
}

void PointVoxel::setSH(float** SHR, float** SHI)
{
	SHRe = SHR;
	SHIm = SHI;
}

float PointVoxel::getX()
{
	return point[0];
}

float PointVoxel::getY()
{
	return point[1];
}

float PointVoxel::getZ()
{
	return point[2];
}

float PointVoxel::getValueClose()
{
	return valueClose;
}

float PointVoxel::getValueFar()
{
	return valueFar;
}

float** PointVoxel::getSHRe()
{
	return SHRe;
}

float** PointVoxel::getSHIm()
{
	return SHIm;
}

ostream& operator<<(ostream& os, const PointVoxel& pv)
{
	std::streamsize old = os.precision();
	os.precision(2);
	cout.setf(ios::fixed);
	os << "[" << pv.point[0] << ","<< pv.point[1] << ","<< pv.point[2] << "]\tClose: " << pv.valueClose << "\tFar: " << pv.valueFar;
	cout.unsetf(ios::fixed);
	os.precision(old);
	return os;
}