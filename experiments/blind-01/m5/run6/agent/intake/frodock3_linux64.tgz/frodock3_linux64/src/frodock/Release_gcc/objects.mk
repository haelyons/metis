################################################################################
# Automatically-generated file. Do not edit!
################################################################################

USER_OBJS :=

LIBS := -lfrodock_gcc -lprotprot_gcc -lfrm_gcc -lbessel_gcc -lpdb_gcc -lvolume_gcc -ltools_gcc -lfftw3f

