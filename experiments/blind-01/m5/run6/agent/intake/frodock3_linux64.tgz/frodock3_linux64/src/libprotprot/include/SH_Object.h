#ifndef SH_OBJECT_H_
#define SH_OBJECT_H_

#ifndef NUM_POT
#define NUM_POT 50
#endif

#include <libpdb/include/Macromolecule.h>
///Creates a pdb representing a property from a spherical harminic representation
void writeSH(vlVolume *vol,float **SH_layerr,float **SH_layeri,float *radius,float steprho,int rmax,int bw,float *associatedC);

/**
 * Class to represent different properties of a macromolecule by spherical harmonics
 */
class SH_Object{
public:
	///bandwidth
	int bw;
	/// higher layer
	int radius_max;
	/// Distance between layers
	float rho_amstrongs;
	///d precomputable coefficients
	float *associatedC;
	///Energy Potentials represented
	bool eval[NUM_POT];
public:
	/**
	 *Spherical harmonics coefficients
	 */
	float * * * SH_layerr, * * * SH_layeri; //coeficientes de los esfericos harmonicos
	/**
	 * Radius of the layers
	 */
	float * * radius_layer; //Radios de las capas de los coeficientes harmonicos

	/**
	 * Constructor
	 *@param ligand: Macromolecule to represent
	 *@param in_bw: Bandwidth. Grade of the spherical harmonic base
	 *@param in_radius_max: maximun number of layer
	 *@param in_rho_amstrongs: layer width
	 *@param in_eval: Indicates which representations must be done
	 *@param vol_sol: Tridimensional volume that contains the solvatation representation of the Macromolecule (needed if the spherical solvatation representation is required)
	 *@param vol_acc: Tridimensional volume that contains the accessibility representation of the Macromolecule (needed if the spherical accessibility representation is required)
	 *@param vol_ele: Tridimensional volume that contains the electrostatic representation of the Macromolecule (needed if the spherical electrostatic representation is required)
	 */
	SH_Object(Macromolecule *ligand, int in_bw, int in_radius_max, float in_rho_amstrongs, bool *in_eval,vlVolume *vol_sol=NULL,vlVolume *vol_acc=NULL,vlVolume *vol_ele=NULL,int *extra_type=NULL);
	///Simple constructor
	SH_Object();
	///Destructor
	~SH_Object();

	/**
	 * Returns the buffer with the real part of the spherical coefficient that represents a given property
	 * @param i: indicates the property buffer
	 */
	float ** return_shr(int i);
	/**
	 * Returns the buffer with the imaginary part of the spherical coefficient that represents a given property
	 * @param i: indicates the property buffer
	 */
	float ** return_shi(int i);
	/**
	 * Returns the radius list for the spherical coefficient that represents a given property
	 * @param i: indicates the property buffer
	 */
	float * return_sh_Radius(int i);
	/**
	 * writes all the information about the spherical harmonics representations in a file
	 * @param name: Name of the file
	 */
	void write(char *name);
	/**
	 * reads all the information about the spherical harmonics representations in a file
	 * @param name: Name of the file
	 */
	void read(char *name);

};

#endif /*SH_OBJECT_H_*/
